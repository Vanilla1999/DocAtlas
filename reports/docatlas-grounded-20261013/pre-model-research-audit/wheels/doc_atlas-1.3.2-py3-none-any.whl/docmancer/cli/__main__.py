import click

from docmancer import __version__
from docmancer.cli.commands import (
    add_cmd,
    agent_contract_cmd,
    clear_cmd,
    clear_index_cmd,
    context_cmd,
    docs_impact_cmd,
    doctor_cmd,
    eval_cmd,
    fetch_cmd,
    ingest_cmd,
    ingest_uspto_cmd,
    init_cmd,
    inspect_cmd,
    install_cmd,
    list_cmd,
    patch_review_cmd,
    query_cmd,
    remove_cmd,
    setup_cmd,
    update_cmd,
)
from docmancer.cli.help import DocmancerGroup, HELP_CONTEXT_SETTINGS, format_examples
from docmancer.cli.mcp_commands import (
    install_pack_cmd,
    mcp_group,
    uninstall_pack_cmd,
)
from docmancer.cli.qdrant_commands import qdrant_group
from docmancer.support_policy import label_cli_commands
from docmancer.docs.application.query_trace import query_trace


def _show_version(ctx: click.Context, param: click.Parameter, value: bool) -> None:
    if not value or ctx.resilient_parsing:
        return
    click.echo(f"doc-atlas {__version__}")
    ctx.exit()


@click.group(
    cls=DocmancerGroup,
    context_settings=HELP_CONTEXT_SETTINGS,
    epilog=format_examples(
        "doc-atlas setup",
        "doc-atlas ingest ./docs",
        "doc-atlas add https://docs.example.com",
        "doc-atlas update",
        'doc-atlas query "How do I authenticate?"',
        "doc-atlas install claude-code",
        "doc-atlas install github-copilot --project",
    ) + "\n\nCurrent support tiers: docs/support-surface-policy.md",
)
@click.option(
    "--version",
    "--v",
    "-v",
    is_flag=True,
    is_eager=True,
    expose_value=False,
    callback=_show_version,
    help="Show the version and exit.",
)
@click.option("--config", "config_path", default=None, hidden=True, help="Path to docatlas.yaml.")
@click.option("--trace/--no-trace", default=None, help="Enable/disable host trace logs on stderr; overrides DOCATLAS_TRACE for this invocation.")
@click.pass_context
def cli(ctx, config_path: str | None, trace: bool | None = None):
    """Compress documentation context so agents spend tokens on code."""
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config_path
    if trace is not None:
        ctx.with_resource(query_trace(trace))


cli.add_command(setup_cmd, "setup")
cli.add_command(add_cmd, "add")
cli.add_command(update_cmd, "update")
cli.add_command(query_cmd, "query")
cli.add_command(context_cmd, "context")
cli.add_command(patch_review_cmd, "patch-review")
cli.add_command(eval_cmd, "eval")
cli.add_command(docs_impact_cmd, "docs-impact")
cli.add_command(agent_contract_cmd, "agent-contract")
cli.add_command(inspect_cmd, "inspect")
cli.add_command(list_cmd, "list")
cli.add_command(remove_cmd, "remove")
cli.add_command(clear_cmd, "clear")
cli.add_command(clear_index_cmd, "clear-index")
cli.add_command(doctor_cmd, "doctor")
cli.add_command(init_cmd, "init")
cli.add_command(fetch_cmd, "fetch")
cli.add_command(install_cmd, "install")
cli.add_command(ingest_cmd, "ingest")
cli.add_command(ingest_uspto_cmd, "ingest-uspto")
cli.add_command(mcp_group, "mcp")
cli.add_command(install_pack_cmd, "install-pack")
cli.add_command(uninstall_pack_cmd, "uninstall")
cli.add_command(qdrant_group, "qdrant")
label_cli_commands(cli)


if __name__ == "__main__":
    cli()
