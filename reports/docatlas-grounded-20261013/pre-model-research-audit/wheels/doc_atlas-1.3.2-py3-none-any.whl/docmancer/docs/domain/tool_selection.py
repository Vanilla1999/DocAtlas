from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


PUBLIC_DOCS_TOOLS = ("get_docs_context", "prepare_docs", "docs_status")
_PREPARE_ACTION_BY_TOOL = {
    "sync_project_docs": "sync_project_docs",
    "ingest_project_docs": "sync_project_docs",
    "bootstrap_project_docs": "sync_project_docs",
    "prefetch_project_dependency_docs": "prefetch_project_dependency_docs",
    "prefetch_library_docs": "prefetch_library_docs",
    "prefetch_docs_targets": "prefetch_docs_targets",
    "prefetch_docs_manifest": "prefetch_docs_manifest",
    "validate_docs_manifest": "validate_docs_manifest",
    "refresh_library_docs": "refresh_library_docs",
    "prune_library_docs": "prune_library_docs",
    "remove_library_docs": "remove_library_docs",
    "cancel_docs_job": "cancel_docs_job",
}
_CONTEXT_ACTION_TOOLS = {
    "get_project_docs",
    "get_library_docs",
}
_STATUS_ACTION_BY_TOOL = {
    "inspect_project_docs": "project",
    "get_docs_job_status": "job",
    "list_docs_jobs": "jobs",
}
_HIDDEN_DOCS_ACTION_TOOLS = {
    "docs_job",
    "get_code_context",
    "get_patch_plan_context",
    "get_patch_constraints",
    "validate_patch_against_constraints",
    "resolve_library_id",
    "inspect_library_docs",
    "list_library_docs",
    "list_docs_sources",
    "prune_library_docs",
    "remove_library_docs",
}

@dataclass(frozen=True)
class ToolSelectionDecision:
    tool: str
    reason_code: str
    confidence: float
    allowed_tools: tuple[str, ...] = PUBLIC_DOCS_TOOLS

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def normalize_public_docs_action(action: Any) -> dict[str, Any] | None:
    """Map DocAtlas-internal next actions onto the public three-tool surface.

    Host actions such as code_search remain untouched. Hidden DocAtlas actions
    are removed unless they have an equivalent prepare_docs lifecycle action.
    """

    if not isinstance(action, dict):
        return None
    normalized = dict(action)
    confirmed = normalized.get("after_confirmation")
    confirmed_tool = normalized.get("tool_after_confirmation")
    confirmed_arguments = normalized.get("arguments_patch_after_confirmation")
    if isinstance(confirmed, dict):
        confirmed_tool = confirmed.get("tool") or confirmed_tool
        confirmed_arguments = confirmed.get("arguments_patch") or confirmed_arguments
    prepare_action = _PREPARE_ACTION_BY_TOOL.get(str(confirmed_tool or "").strip())
    if prepare_action:
        arguments = dict(confirmed_arguments or {})
        arguments["action"] = prepare_action
        return {
            **normalized,
            "type": "prepare_docs",
            "tool": "prepare_docs",
            "arguments_patch": arguments,
        }
    tool = str(normalized.get("tool") or "").strip()
    if not tool or tool in PUBLIC_DOCS_TOOLS:
        return normalized
    if tool in _CONTEXT_ACTION_TOOLS:
        arguments = dict(normalized.get("arguments_patch") or {})
        if "query" in arguments and "question" not in arguments:
            arguments["question"] = arguments.pop("query")
        normalized.update({
            "type": "get_docs_context",
            "tool": "get_docs_context",
            "arguments_patch": arguments,
        })
        return normalized
    status_action = _STATUS_ACTION_BY_TOOL.get(tool)
    if status_action:
        arguments = dict(normalized.get("arguments_patch") or {})
        arguments["action"] = status_action
        normalized.update({
            "type": "docs_status",
            "tool": "docs_status",
            "arguments_patch": arguments,
        })
        return normalized
    prepare_action = _PREPARE_ACTION_BY_TOOL.get(tool)
    if prepare_action:
        arguments = dict(normalized.get("arguments_patch") or {})
        arguments["action"] = prepare_action
        normalized.update({
            "type": "prepare_docs",
            "tool": "prepare_docs",
            "arguments_patch": arguments,
        })
        return normalized
    if tool in _HIDDEN_DOCS_ACTION_TOOLS:
        return None
    return normalized


def normalize_public_docs_actions(payload: dict[str, Any]) -> dict[str, Any]:
    """Ensure top-level DocAtlas next actions are callable on the public surface."""

    normalized = dict(payload)
    primary = normalize_public_docs_action(normalized.get("next_action"))
    actions: list[dict[str, Any]] = []
    for action in normalized.get("next_actions") or []:
        candidate = normalize_public_docs_action(action)
        if candidate is not None and candidate not in actions:
            actions.append(candidate)
    if primary is not None and primary not in actions:
        actions.insert(0, primary)
    if primary is None and actions:
        primary = actions[0]
    normalized["next_action"] = primary
    normalized["next_actions"] = actions
    return normalized


def select_public_docs_tool(
    user_text: str,
    *,
    next_action_tool: str | None = None,
) -> ToolSelectionDecision:
    """Use explicit protocol next actions; prose never selects a mutation."""

    if next_action_tool in PUBLIC_DOCS_TOOLS:
        return ToolSelectionDecision(
            tool=next_action_tool,
            reason_code="returned_next_action",
            confidence=1.0,
        )

    return ToolSelectionDecision(
        tool="get_docs_context",
        reason_code="default_question_entrypoint",
        confidence=0.99,
    )
