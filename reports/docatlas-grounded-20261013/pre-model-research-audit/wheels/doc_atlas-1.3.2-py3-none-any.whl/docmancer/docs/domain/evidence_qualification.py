"""Pure qualification rules for model-visible project documentation evidence."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import re
from typing import Any, Literal, Mapping

from docmancer.docs.domain.technical_tokens import technical_term_pattern
from docmancer.docs.domain.lifecycle_policy import lifecycle_allows
from docmancer.docs.domain.project_answer_contract import LifecycleIntent

CoverageKind = Literal["direct", "derived"]


def source_only_admission_active() -> bool:
    """Compatibility predicate for the unconditional source-only admission policy."""
    return True




def _clean_relation_line(value: str) -> str:
    value = re.sub(r"!?\[[^\]]*\](?:\([^)]*\)|\[[^\]]*\])", "", value)
    value = re.sub(r"https?://\S+", "", value)
    return " ".join(value.split()).strip()


def _relation_units(body: str) -> tuple[str, ...]:
    """Build relation-local units while preserving Markdown structural boundaries."""
    lines = body.splitlines()
    units: list[str] = []
    buffer: list[str] = []
    buffer_kind = ""
    fence = ""

    def flush() -> None:
        nonlocal buffer, buffer_kind
        value = _clean_relation_line(" ".join(buffer))
        if value:
            units.append(value)
        buffer = []
        buffer_kind = ""

    index = 0
    while index < len(lines):
        line = lines[index]
        stripped = line.strip()
        fence_match = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if fence:
            if (
                fence_match
                and fence_match[1][0] == fence[0]
                and len(fence_match[1]) >= len(fence)
                and not fence_match[2].strip()
            ):
                flush()
                fence = ""
            elif stripped:
                buffer.append(line)
            index += 1
            continue
        if fence_match:
            flush()
            fence = fence_match[1]
            buffer_kind = "code"
            index += 1
            continue
        if not stripped:
            flush()
            index += 1
            continue
        if line.lstrip().startswith("#"):
            flush()
            index += 1
            continue
        next_line = lines[index + 1].strip() if index + 1 < len(lines) else ""
        if next_line and re.fullmatch(r"[=-]{3,}", next_line):
            flush()
            index += 2
            continue
        if re.fullmatch(r"\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)*\|?", stripped):
            flush()
            index += 1
            continue
        if line.count("|") >= 2:
            flush()
            for cell in re.split(r"(?<!\\)\|", line.strip().strip("|")):
                value = _clean_relation_line(cell)
                if value and not re.fullmatch(r":?-{3,}:?", value):
                    units.append(value)
            index += 1
            continue
        list_match = re.match(r"^\s*(?:[-*+] |\d+[.)]\s+)(.*)$", line)
        if list_match:
            flush()
            buffer = [list_match.group(1)]
            buffer_kind = "list"
            index += 1
            continue
        if buffer_kind == "list" and not line[:1].isspace():
            flush()
        buffer.append(line)
        if not buffer_kind:
            buffer_kind = "prose"
        index += 1
    flush()
    return tuple(units)


def _comparison_relation_probe(query_id: str, query_text: str) -> bool:
    return False


def _relation_term_count(text: str, terms: tuple[str, ...]) -> int:
    return sum(_visible_term_present(term, text, exact=False) for term in terms)


def _proof_relation_is_locally_bound(
    clause: str, match: re.Match[str], terms: tuple[str, ...],
) -> bool:
    """Legacy relation binding cannot establish entailment."""
    return False


def _general_relation_is_locally_bound(
    clause: str, match: re.Match[str], terms: tuple[str, ...],
) -> bool:
    """Legacy comparison wording cannot bind a semantic relation."""
    return False


def _visible_comparison_relation(text: str, terms: tuple[str, ...]) -> bool:
    """Literal matching cannot establish comparison entailment."""
    return False


@dataclass(frozen=True, slots=True)
class EvidenceQualification:
    qualified: bool
    covered_query_ids: tuple[str, ...]
    coverage_kind: CoverageKind | None
    reason: str
    trace: Mapping[str, Any]


def evidence_policy_rejection_reason(
    probe: Mapping[str, Any], *, visible_text: str, catalog_role: str = "",
    forbidden_catalog_roles: tuple[str, ...] = (),
    forbidden_evidence_terms: tuple[str, ...] = (),
    candidate: Mapping[str, Any] | None = None,
    expected_project_identity: str | None = None,
    lifecycle_intent: LifecycleIntent = "current",
) -> str | None:
    """Return the source/policy rejection independently of lexical matching."""
    if candidate is not None or expected_project_identity:
        candidate = candidate or {}
        identity = str(candidate.get("project_identity") or "").strip()
        if (expected_project_identity or candidate.get("source_class") == "project_doc") and not identity:
            return "missing_project_identity"
        if expected_project_identity and identity != expected_project_identity:
            return "wrong_project_identity"
        if candidate.get("stale") or str(candidate.get("freshness") or "current") != "current":
            return "stale_evidence"
        if str(candidate.get("index_freshness") or "synchronized") != "synchronized":
            return "unsynchronized_index"
        if not lifecycle_allows(candidate, lifecycle_intent):
            return "lifecycle_not_allowed"
    normalized_visible = visible_text.casefold()
    forbidden_terms = tuple(dict.fromkeys((
        *(str(value) for value in probe.get("forbidden_evidence_terms") or ()),
        *forbidden_evidence_terms,
    )))
    forbidden_roles = set(str(value) for value in (
        *(probe.get("forbidden_catalog_roles") or ()),
        *forbidden_catalog_roles,
    ))
    if any(str(term).casefold() in normalized_visible for term in forbidden_terms):
        return "forbidden_evidence_term"
    if catalog_role and catalog_role in forbidden_roles:
        return "forbidden_catalog_role"
    return None



def _substantive_markdown_line(line: str) -> str:
    """Keep visible inline-link labels only when the line carries a real statement."""
    if re.match(r"^\s*\[[^\]]+\]:\s*\S+", line):
        return ""

    code_parts: list[str] = []

    def protect_code(match: re.Match[str]) -> str:
        code_parts.append(match.group(2))
        return f"\x00CODE{len(code_parts) - 1}\x00"

    protected = re.sub(r"(`+)(.+?)\1", protect_code, line)
    protected = re.sub(r"!\[[^\]]*\](?:\([^)]*\)|\[[^\]]*\])", "", protected)
    link_re = re.compile(r"(?<!!)\[([^\]]+)\](?:\([^)]*\)|\[[^\]]*\])")
    without_links = link_re.sub("", protected)
    without_links = re.sub(r"https?://\S+", "", without_links)

    probe = without_links
    for index, code in enumerate(code_parts):
        probe = probe.replace(f"\x00CODE{index}\x00", code)
    has_statement = bool(probe.strip(" \t-*+0123456789.)|:<>_=`"))

    rendered = link_re.sub(lambda m: m.group(1) if has_statement else "", protected)
    rendered = re.sub(r"https?://\S+", "", rendered)
    for index, code in enumerate(code_parts):
        rendered = rendered.replace(f"\x00CODE{index}\x00", code)
    return rendered

def qualify_evidence(
    probe: Mapping[str, Any], *, query_id: str, visible_text: str,
    evidence_text: str | None = None,
    catalog_role: str = "", forbidden_catalog_roles: tuple[str, ...] = (),
    forbidden_evidence_terms: tuple[str, ...] = (),
    candidate: Mapping[str, Any] | None = None,
    expected_project_identity: str | None = None,
    lifecycle_intent: LifecycleIntent = "current",
    authoritative_query: Mapping[str, Any] | None = None,
) -> EvidenceQualification:
    """Qualify one retrieval probe against evidence visible to the model."""
    # Body-bound decisions belong to the current bytes, never the incoming trace.
    probe = {key: value for key, value in probe.items() if key not in {
        "need_local_witness", "admission_route", "matched_need_ids",
        "need_witness_spans", "need_witness_source_key", "_admission_demands",
        "context_eligible", "context_need_ids", "_need_context",
    }}
    result = dict(probe)
    policy_reason = evidence_policy_rejection_reason(
        probe, visible_text=visible_text, catalog_role=catalog_role,
        forbidden_catalog_roles=forbidden_catalog_roles,
        forbidden_evidence_terms=forbidden_evidence_terms, candidate=candidate,
        expected_project_identity=expected_project_identity, lifecycle_intent=lifecycle_intent,
    )
    if policy_reason is not None:
        return _rejected(result, policy_reason)
    expected_origin = (
        "original" if query_id == "query-original" else
        "host_lookup" if re.fullmatch(r"query-lookup-[1-5]", query_id) else None
    )
    expected_relation = "direct" if expected_origin == "original" else "host_lookup"
    if (query_id.startswith("query-need-") or
        (probe.get("query_origin") in ("original", "host_lookup") and
         (expected_origin != probe.get("query_origin") or
          probe.get("relation") != expected_relation))):
        return _rejected(result, "query_contract_mismatch")
    if authoritative_query is not None and (
        authoritative_query.get("query_id") != query_id
        or authoritative_query.get("origin") != expected_origin
        or authoritative_query.get("relation") != expected_relation
        or authoritative_query.get("text") != probe.get("query_text")
        or authoritative_query.get("public_parent_query_id")
        or probe.get("query_origin") != expected_origin
        or probe.get("relation") != expected_relation
    ):
        return _rejected(result, "query_contract_mismatch")
    public_credit = bool(expected_origin and authoritative_query is not None and not probe.get("admission_only"))
    if not public_credit:
        # Helper matches can still inform diagnostics/local formatting, but an
        # anonymous trace cannot stand in for a public request contract.
        result["admission_only"] = True
    if (
        probe.get("query_origin") not in (None, "", "original", "host_lookup")
        or probe.get("relation") not in (None, "", "direct", "host_lookup")
        or probe.get("public_parent_query_id")
        or probe.get("derived_from_query_id")
        or probe.get("derived_from_query_ids")
    ):
        return _rejected(result, "nonliteral_retrieval_lane")
    body = evidence_text if evidence_text is not None else visible_text
    from .query_reference_binding import prepare_reference_probe
    probe, reference_reason = prepare_reference_probe(probe, candidate=candidate, evidence_text=body)
    result = dict(probe)
    if not public_credit:
        result["admission_only"] = True
    if reference_reason is not None:
        return _rejected(result, reference_reason)
    if (source_only_admission_active() and expected_origin in {"original", "host_lookup"}
        and isinstance((candidate or {}).get("_reference_root_plan"), Mapping)):
        # Canonical source/locator checks above do not establish query relevance.
        # Admission separately requires the live original-discovery receipt and
        # raw window. Never promote source validity into lexical query credit.
        for key in (
            "matched_terms", "body_matched_terms", "heading_context_used",
            "table_context_used", "missing_exact_terms", "missing_parent_exact_terms",
            "missing_bound_subjects", "matched_term_count", "match_ratio",
            "covered_query_ids", "coverage_kind", "literal_context_admission",
            "query_terms", "exact_terms", "parent_exact_terms", "bound_subjects",
            "retrieval_anchors",
        ):
            result.pop(key, None)
        result.update(
            qualified=False, qualification_reason="source_valid_relevance_unassessed",
            relevance_unassessed=True, context_only=True, coverage_credit=False,
            admission_only=True,
            admission_contract="source_only_heuristic_removal_v1",
        )
        return EvidenceQualification(False, (), None, "source_valid_relevance_unassessed", result)
    lines = body.splitlines()
    substantive_lines = []
    heading_lines = []
    table_rows: list[tuple[str, str]] = []
    fence = ""
    for index, line in enumerate(lines):
        fence_match = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if fence:
            if (
                fence_match and fence_match[1][0] == fence[0]
                and len(fence_match[1]) >= len(fence) and not fence_match[2].strip()
            ):
                fence = ""
            elif line.strip():
                substantive_lines.append(line)
            continue
        if fence_match:
            fence = fence_match[1]
            continue
        if line.lstrip().startswith("#"):
            heading_lines.append(line.lstrip().lstrip("#").strip())
            continue
        next_line = lines[index + 1].strip() if index + 1 < len(lines) else ""
        if re.fullmatch(r"[=-]{3,}", next_line):
            heading_lines.append(line.strip())
            continue
        if (
            "|" in line and re.fullmatch(
                r"\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)*\|?", next_line,
            )
        ):
            for row in lines[index + 2:]:
                if not row.strip() or "|" not in row:
                    break
                table_rows.append((line, row))
            continue
        line = _substantive_markdown_line(line)
        if line.strip(" \t-*+0123456789.)|:<>_="):
            substantive_lines.append(line)
    if not substantive_lines:
        return _rejected(result, "metadata_only_evidence")
    # A heading may identify the subject of an already relevant body, but cannot
    # turn unrelated prose or a single generic match into factual evidence.
    normalized_evidence = "\n".join(substantive_lines).casefold()
    normalized_headings = "\n".join(heading_lines).casefold()

    if query_id.startswith("query-relation-"):
        return _rejected(result, "unsupported_relation_qualification")

    if str(probe.get("mode") or "") == "exact_path":
        query_text = str(probe.get("query_text") or "").replace("\\", "/").casefold()
        normalized_visible = visible_text.replace("\\", "/").casefold()
        qualified = bool(query_text and query_text in normalized_visible)
        result.update(
            qualified=qualified,
            qualification_reason="visible_exact_path" if qualified else "missing_visible_exact_path",
        )
        return EvidenceQualification(
            qualified,
            (query_id,) if qualified and public_credit else (),
            _coverage_kind(probe) if qualified and public_credit else None,
            str(result["qualification_reason"]),
            result,
        )

    terms = tuple(
        str(value).casefold() for value in probe.get("query_terms") or () if value
    )
    if not terms:
        terms = tuple(dict.fromkeys(
            token.casefold()
            for token in re.findall(
                r"[A-Za-zА-Яа-яЁё0-9_.-]{4,}", str(probe.get("query_text") or ""),
            )
        ))
    if not terms:
        return _rejected(result, "missing_visible_query_terms")

    exact_terms = tuple(
        str(value).casefold() for value in probe.get("exact_terms") or () if value
    )
    body_matched = tuple(
        term for term in terms
        if _visible_term_present(
            term, normalized_evidence, exact=term in exact_terms,
        )
    )
    heading_context_allowed = len(body_matched) >= 2
    bound_subjects = tuple(
        str(value).casefold() for value in probe.get("bound_subjects") or () if value
    )
    bound_subject_context = str(probe.get("bound_subject_context") or "").casefold()
    missing_bound_subjects = tuple(
        subject for subject in bound_subjects
        if not _visible_term_present(subject, normalized_evidence, exact=True)
        and not (
            heading_context_allowed
            and _visible_term_present(subject, bound_subject_context, exact=True)
        )
    )
    if missing_bound_subjects:
        result.update(
            bound_subjects=list(bound_subjects),
            missing_bound_subjects=list(missing_bound_subjects),
            qualified=False,
            qualification_reason="missing_bound_subject",
        )
        return EvidenceQualification(
            False, (), None, "missing_bound_subject", result,
        )
    # Column labels describe a substantive row, not standalone evidence. Only
    # bind them when that table's key cell contains every requested exact term.
    # They may recover a relation term, but never supply a missing identifier.
    table_context = _bound_table_context(table_rows, exact_terms)
    table_matched = tuple(
        term for term in terms if term not in exact_terms
        and _visible_term_present(term, table_context, exact=False)
    )
    matched = tuple(dict.fromkeys((
        *body_matched,
        *table_matched,
        *(
            term for term in terms
            if heading_context_allowed
            and (_visible_term_present(term, normalized_headings, exact=term in exact_terms)
                 or (term in bound_subjects and _visible_term_present(term, bound_subject_context, exact=True)))
        ),
    )))
    exact_evidence = (
        f"{normalized_evidence}\n{normalized_headings}"
        if heading_context_allowed else normalized_evidence
    )
    missing_exact = tuple(
        term for term in exact_terms
        if not _visible_term_present(term, exact_evidence, exact=True)
    )
    missing_parent_exact = tuple(
        str(value).casefold()
        for value in probe.get("parent_exact_terms") or ()
        if not _visible_term_present(str(value).casefold(), exact_evidence, exact=True)
    )
    ratio = len(matched) / len(terms)
    required_ratio = (
        1.0 if len(terms) == 1
        else 0.4 if exact_terms
        else 0.5
    )
    qualified = bool(matched) and ratio >= required_ratio and not missing_exact
    reason = "visible_fields" if qualified else "insufficient_visible_match"
    result.update({
        "matched_terms": list(matched),
        "body_matched_terms": list(body_matched),
        "heading_context_used": heading_context_allowed and any(
            term not in body_matched and term not in table_matched for term in matched
        ),
        "table_context_used": any(term not in body_matched for term in table_matched),
        "missing_exact_terms": list(missing_exact),
        "missing_parent_exact_terms": list(missing_parent_exact),
        "matched_term_count": len(matched),
        "match_ratio": round(ratio, 4),
        "qualified": qualified,
        "qualification_reason": reason,
    })
    # Honest crop-local lexical retrieval attribution only. Do not compile the
    # question into semantic needs or upgrade a quote to typed answer proof.
    result["context_only"] = True
    return EvidenceQualification(
        qualified,
        (query_id,) if qualified and public_credit else (),
        _coverage_kind(probe) if qualified and public_credit else None,
        reason,
        result,
    )


def qualify_visible_trace(
    trace: Mapping[str, Any], *, visible_text: str, catalog_role: str = "",
) -> dict[str, Any]:
    """Compatibility wrapper for callers that qualify one anonymous trace."""
    return dict(qualify_evidence(
        trace,
        query_id=str(trace.get("query_id") or "query"),
        visible_text=visible_text,
        evidence_text=visible_text,
        catalog_role=catalog_role,
    ).trace)


def derived_parent_trace(
    trace: Mapping[str, Any], *, source_query_id: str, parent_query_id: str,
) -> dict[str, Any] | None:
    """Independent lookups never confer coverage on another query lane."""
    return None


def _bound_table_context(rows: list[tuple[str, str]], exact_terms: tuple[str, ...]) -> str:
    if not exact_terms:
        return ""
    headers = []
    for header, row in rows:
        cells = row.strip().strip("|").split("|")
        if len(cells) < 2 or len(cells) != len(header.strip().strip("|").split("|")):
            continue
        cells = [re.sub(r"!?\[[^\]]*\](?:\([^)]*\)|\[[^\]]*\])", "", cell) for cell in cells]
        cells = [re.sub(r"https?://\S+", "", cell).casefold() for cell in cells]
        if not all(_visible_term_present(term, cells[0], exact=True) for term in exact_terms):
            continue
        if any(cell.strip(" \t-*+0123456789.)|:<>_=`") for cell in cells[1:]):
            headers.append(header)
    return "\n".join(headers).casefold()


def _coverage_kind(probe: Mapping[str, Any]) -> CoverageKind:
    return "derived" if probe.get("coverage_kind") == "derived" else "direct"


@lru_cache(maxsize=4096)
def _visible_term_present(term: str, text: str, *, exact: bool) -> bool:
    return re.search(technical_term_pattern(term, exact=exact), text) is not None


def _rejected(trace: dict[str, Any], reason: str) -> EvidenceQualification:
    trace.update(qualified=False, qualification_reason=reason)
    return EvidenceQualification(False, (), None, reason, trace)


__all__ = [
    "CoverageKind",
    "EvidenceQualification",
    "derived_parent_trace",
    "evidence_policy_rejection_reason",
    "qualify_evidence",
    "qualify_visible_trace",
    "source_only_admission_active",
]
