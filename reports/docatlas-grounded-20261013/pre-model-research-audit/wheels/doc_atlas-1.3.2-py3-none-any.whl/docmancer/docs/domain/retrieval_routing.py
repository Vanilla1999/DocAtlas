"""Versioned deterministic routing for bounded project retrieval stages."""

from __future__ import annotations

import json
from dataclasses import dataclass, fields, is_dataclass
from typing import Any, Iterable, Mapping

RETRIEVAL_ROUTING_SCHEMA_VERSION = 2
STAGE_ITEM_LIMITS = {
    "project_docs": 20,
    "dependency_docs": 20,
    "source_evidence": 12,
    "repo_map": 8,
    "code_graph": 8,
}
STAGE_BYTE_LIMITS = {
    "project_docs": 64 * 1024,
    "dependency_docs": 64 * 1024,
    "source_evidence": 48 * 1024,
    "repo_map": 32 * 1024,
    "code_graph": 32 * 1024,
}

@dataclass(frozen=True)
class RetrievalRoute:
    schema_version: int
    intent: str
    project_mode: bool
    dependency_requested: bool
    use_source_evidence: bool
    source_reason: str


@dataclass(frozen=True)
class GapRecoveryRoute:
    use_repo_map: bool
    repo_map_reason: str
    use_code_graph: bool
    code_graph_reason: str


def route_initial_stages(
    *, question: str, mode: str, dependency_requested: bool, project_doc_items: Iterable[Any]
) -> RetrievalRoute:
    project_mode = mode in {"auto", "project-only"}
    intent = ("mixed" if project_mode else "api") if dependency_requested else "docs"
    return RetrievalRoute(
        RETRIEVAL_ROUTING_SCHEMA_VERSION, intent, project_mode,
        dependency_requested, False, "source stages require explicit source-bound targets; prose is not authorization",
    )


def should_run_repo_map(route: RetrievalRoute, source_items: Iterable[dict[str, Any]]) -> tuple[bool, str]:
    items = list(source_items)
    if not route.project_mode:
        return False, "project repository map is outside the selected mode"
    if route.intent == "source_navigation":
        return True, "explicit source navigation requires bounded repository paths"
    if route.intent not in {"patch", "mixed"}:
        return False, "documentation/API evidence does not require repository cartography"
    if _proven_source_paths(items):
        return False, "bounded source evidence already proves a target path"
    if any(item.get("evidence_class") == "absent_in_source" for item in items):
        return True, "required target terms remain unresolved after source evidence"
    if route.use_source_evidence:
        return True, "required patch target remains unresolved after source evidence"
    return False, "no deterministic source signal authorizes repository scanning"


def should_run_code_graph(
    route: RetrievalRoute,
    *, question: str,
    source_items: Iterable[dict[str, Any]],
    repo_map_items: Iterable[dict[str, Any]],
) -> tuple[bool, str]:
    source = list(source_items)
    repo = list(repo_map_items)
    if not route.project_mode or route.intent in {"docs", "api"}:
        return False, "documentation/API intent does not require connectivity evidence"
    if route.intent == "source_navigation":
        return False, "path discovery alone does not require connectivity evidence"
    modules = {_top_module(path) for path in _proven_source_paths([*source, *repo]) if _top_module(path)}
    if len(modules) > 1:
        return True, "earlier evidence supports multiple target modules"
    unresolved = (
        not _proven_source_paths(source)
        and any(item.get("evidence_class") == "absent_in_source" for item in source)
    )
    if unresolved and route.intent in {"patch", "source_navigation", "mixed"}:
        return True, "target resolution remains incomplete after bounded source retrieval"
    return False, "one bounded source target is already resolved"


def route_gap_recovery_stages(
    *, has_documentation_gap: bool, repo_map_attempted: bool, code_graph_attempted: bool
) -> GapRecoveryRoute:
    """Own the exceptional authoring-evidence decision without repeating a stage."""

    use_repo_map = has_documentation_gap and not repo_map_attempted
    use_code_graph = has_documentation_gap and not code_graph_attempted
    return GapRecoveryRoute(
        use_repo_map=use_repo_map,
        repo_map_reason=(
            "missing project documentation requires bounded authoring evidence"
            if use_repo_map else
            "no documentation gap requires repository authoring evidence"
            if not has_documentation_gap else
            "repository-map stage was already attempted"
        ),
        use_code_graph=use_code_graph,
        code_graph_reason=(
            "missing project documentation requires bounded module evidence"
            if use_code_graph else
            "no documentation gap requires module authoring evidence"
            if not has_documentation_gap else
            "code-graph stage was already attempted"
        ),
    )


def new_routing_record(route: RetrievalRoute, *, project_docs_used: bool, dependency_docs_used: bool) -> dict[str, Any]:
    return {
        "schema_version": route.schema_version,
        "intent": route.intent,
        "stages": {
            "project_docs": _stage("used" if project_docs_used else "skipped", "selected project documentation mode" if project_docs_used else "project documentation not selected"),
            "dependency_docs": _stage("used" if dependency_docs_used else "skipped", "selected exact-version dependency documentation" if dependency_docs_used else "dependency documentation not selected or not available"),
            "source_evidence": _stage("skipped", route.source_reason),
            "repo_map": _stage("skipped", "not evaluated"),
            "code_graph": _stage("skipped", "not evaluated"),
        },
        "budget_projection_bytes": 0,
        "model_visible_bytes": 0,
    }


def record_stage(
    record: dict[str, Any], stage: str, *, status: str, reason: str,
    items: Iterable[dict[str, Any]] = (), error: str | None = None,
) -> None:
    observed_items = list(items)
    bounded_items, budget = fit_stage_items(stage, observed_items)
    row = _stage(status, reason)
    row["item_count"] = len(bounded_items)
    row["budget_projection_bytes"] = sum(len(_canonical_bytes(item)) for item in bounded_items)
    row["estimated_tokens"] = (row["budget_projection_bytes"] + 3) // 4
    row["observed_item_count"] = len(observed_items)
    row["observed_budget_projection_bytes"] = sum(len(_canonical_bytes(item)) for item in observed_items)
    row["budget_exceeded"] = bool(budget)
    if budget:
        row["status"] = "insufficient"
        row["reason"] = f"{reason}; {budget}"
    if error:
        row["error_type"] = str(error)[:80]
    record["stages"][stage] = row
    record["budget_projection_bytes"] = sum(
        int(value.get("budget_projection_bytes") or 0) for value in record["stages"].values()
    )


def fit_stage_items(stage: str, items: Iterable[Any]) -> tuple[list[Any], str | None]:
    """Fit whole stage items under both item and serialized-byte ceilings."""

    item_limit = STAGE_ITEM_LIMITS[stage]
    byte_limit = STAGE_BYTE_LIMITS[stage]
    values = list(items)
    bounded: list[Any] = []
    used = 0
    for item in values:
        encoded = len(_canonical_bytes(item))
        if len(bounded) >= item_limit:
            break
        if used + encoded > byte_limit:
            continue
        bounded.append(item)
        used += encoded
    if len(bounded) == len(values):
        return bounded, None
    return bounded, (
        f"stage budget exceeded (observed_items={len(values)}, retained_items={len(bounded)}, "
        f"item_limit={item_limit}, byte_limit={byte_limit})"
    )


def validate_routing_record(record: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(record, dict) or record.get("schema_version") != RETRIEVAL_ROUTING_SCHEMA_VERSION:
        return ["invalid retrieval routing record"]
    if set(record) != {"schema_version", "intent", "stages", "budget_projection_bytes", "model_visible_bytes"}:
        errors.append("unexpected routing record fields")
    stages = record.get("stages")
    if not isinstance(stages, dict) or set(stages) != set(STAGE_ITEM_LIMITS):
        errors.append("routing record must contain every stage")
        return errors
    for name, row in stages.items():
        if not isinstance(row, dict):
            errors.append(f"{name}: stage must be an object")
            continue
        allowed_fields = {
            "status", "reason", "item_count", "budget_projection_bytes", "estimated_tokens",
            "observed_item_count", "observed_budget_projection_bytes", "budget_exceeded", "error_type",
        }
        if set(row) - allowed_fields:
            errors.append(f"{name}: unexpected stage fields")
        if row.get("status") not in {"used", "skipped", "failed", "insufficient"}:
            errors.append(f"{name}: invalid stage status")
        if not isinstance(row.get("reason"), str) or not row["reason"]:
            errors.append(f"{name}: missing deterministic reason")
        if any(key in row for key in ("content", "snippet", "context_pack", "source")):
            errors.append(f"{name}: raw evidence leaked into routing diagnostics")
        numeric_fields = (
            "item_count", "budget_projection_bytes", "estimated_tokens",
            "observed_item_count", "observed_budget_projection_bytes",
        )
        invalid_numeric = [
            key for key in numeric_fields
            if not isinstance(row.get(key), int) or isinstance(row.get(key), bool) or row[key] < 0
        ]
        if invalid_numeric:
            errors.append(f"{name}: invalid non-negative integer fields: {', '.join(invalid_numeric)}")
            continue
        if row["item_count"] > STAGE_ITEM_LIMITS[name]:
            errors.append(f"{name}: item budget exceeded")
        if row["budget_projection_bytes"] > STAGE_BYTE_LIMITS[name]:
            errors.append(f"{name}: byte budget exceeded")
        if row["observed_item_count"] < row["item_count"]:
            errors.append(f"{name}: observed item count is below retained count")
        if row["observed_budget_projection_bytes"] < row["budget_projection_bytes"]:
            errors.append(f"{name}: observed bytes are below retained bytes")
        if row["estimated_tokens"] != (row["budget_projection_bytes"] + 3) // 4:
            errors.append(f"{name}: estimated token budget is inconsistent")
        budget_exceeded = row.get("budget_exceeded")
        if not isinstance(budget_exceeded, bool):
            errors.append(f"{name}: missing budget status")
        elif budget_exceeded and row.get("status") not in {"insufficient", "failed"}:
            errors.append(f"{name}: exceeded budget must fail closed")
    for key in ("budget_projection_bytes", "model_visible_bytes"):
        value = record.get(key)
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            errors.append(f"{key}: must be a non-negative integer")
    if isinstance(record.get("budget_projection_bytes"), int) and not isinstance(record.get("budget_projection_bytes"), bool):
        expected = sum(
            row.get("budget_projection_bytes", 0)
            for row in stages.values() if isinstance(row, dict) and isinstance(row.get("budget_projection_bytes"), int)
        )
        if record["budget_projection_bytes"] != expected:
            errors.append("budget_projection_bytes: inconsistent stage total")
    return errors


def _stage(status: str, reason: str) -> dict[str, Any]:
    return {
        "status": status,
        "reason": reason,
        "item_count": 0,
        "budget_projection_bytes": 0,
        "estimated_tokens": 0,
        "observed_item_count": 0,
        "observed_budget_projection_bytes": 0,
        "budget_exceeded": False,
    }


def _doc_has_target_hint(item: Any) -> bool:
    # Compatibility hook; source prose is not an explicit target binding.
    return False


def _proven_source_paths(items: Iterable[dict[str, Any]]) -> list[str]:
    return [
        str(item.get("path")) for item in items
        if item.get("path") and item.get("evidence_class") != "absent_in_source"
    ]


def _top_module(path: str) -> str:
    parts = [part for part in str(path).replace("\\", "/").split("/") if part]
    return "/".join(parts[:2]) if len(parts) > 1 else (parts[0] if parts else "")


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        _stage_budget_projection(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _stage_budget_projection(value: Any) -> dict[str, Any]:
    """Project only routing-relevant fields into deterministic byte accounting."""

    if isinstance(value, Mapping):
        item = value
    elif is_dataclass(value) and not isinstance(value, type):
        item = {field.name: getattr(value, field.name) for field in fields(value)}
    else:
        item = {"content": str(value)}
    metadata = item.get("metadata") if isinstance(item.get("metadata"), Mapping) else {}

    def first(*names: str) -> Any:
        for name in names:
            candidate = item.get(name)
            if candidate is None:
                candidate = metadata.get(name)
            if candidate is not None and candidate != "":
                return candidate
        return None

    content = first("content", "display_text", "text", "snippet", "code")
    if isinstance(content, Mapping):
        content = content.get("content") or content.get("text") or content.get("code")
    return {
        "stable_id": str(first("stable_chunk_id", "stable_child_id", "stable_id", "evidence_id") or ""),
        "path": str(first("path", "project_doc_path", "source_path", "source", "url") or ""),
        "heading": str(first("heading_path", "title", "section") or ""),
        "authority": str(first("authority", "project_doc_authority") or ""),
        "content": str(content or ""),
        "token_estimate": int(first("token_estimate") or 0),
    }
