from __future__ import annotations

from copy import deepcopy
import json
from typing import Any

DEFAULT_MCP_COMPACT_OUTPUT_MAX_BYTES = 32_000
_TEXT_KEYS = {"content", "snippet", "text", "primary_snippet", "surrounding_context"}
_SUMMARY_KEYS = (
    "path",
    "title",
    "heading_path",
    "source_class",
    "freshness",
    "token_estimate",
    "why_selected",
    "line_start",
    "line_end",
    "score",
    "ranking",
)
_SUPPORT_DECISION_KEYS = {
    "status", "tool", "schema_version", "kind", "answer_supported", "answer_available",
    "support_status", "decision", "reason_code", "edit_ready", "operational",
    "operational_status", "context_available", "disposition", "missing",
    "missing_requirement_ids", "satisfied_requirement_ids", "mandatory_requirement_ids",
    "mandatory_coverage", "evidence_coverage", "selected_evidence_ids", "requirements_hash",
    "selector_config_hash", "eligibility_contract_hash", "candidate_trace_hash", "selection_hash",
    "assignment_hash", "decision_hash", "hard_stop", "next_action", "next_actions",
    "arguments_patch", "requires_confirmation", "confirmation_reason", "document_content_policy",
    "mutation_authorized", "policy_coverage", "packet_available",
}
def json_bytes(payload: Any) -> int:
    return len(json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"))


def paginate_context_items(items: list[Any], *, page: int | None, page_size: int | None) -> dict[str, Any]:
    safe_page = max(1, int(page or 1))
    safe_page_size = max(1, min(20, int(page_size or 8)))
    start = (safe_page - 1) * safe_page_size
    end = start + safe_page_size
    total = len(items)
    return {
        "items": items[start:end],
        "page": safe_page,
        "page_size": safe_page_size,
        "total_items": total,
        "next_page": safe_page + 1 if end < total else None,
    }


def _truncate_text(value: str, limit: int) -> tuple[str, bool]:
    if len(value) <= limit:
        return value, False
    suffix = f" … [truncated {len(value) - limit} chars]"
    return value[: max(0, limit - len(suffix))].rstrip() + suffix, True


def _compact_context_item(item: Any) -> Any:
    if not isinstance(item, dict):
        return item
    compact = {key: item.get(key) for key in _SUMMARY_KEYS if item.get(key) not in (None, [], {})}
    source = item.get("source")
    if isinstance(source, dict):
        for key in ("path", "title", "source_class", "freshness"):
            compact.setdefault(key, source.get(key))
    section = item.get("section")
    if isinstance(section, dict):
        compact.setdefault("heading_path", section.get("heading_path"))
        compact.setdefault("line_start", section.get("line_start"))
        compact.setdefault("line_end", section.get("line_end"))
    for text_key in ("snippet", "primary_snippet"):
        if isinstance(item.get(text_key), str):
            compact[text_key], _ = _truncate_text(item[text_key], 320)
            break
    if any(key in item for key in _TEXT_KEYS):
        compact["content_omitted"] = True
    return {key: value for key, value in compact.items() if value not in (None, [], {})}


def _compact_value(value: Any, *, text_limit: int, list_limit: int, key: str | None, stats: dict[str, int]) -> Any:
    if isinstance(value, str):
        limit = text_limit if key in _TEXT_KEYS else max(text_limit * 2, text_limit)
        compact, truncated = _truncate_text(value, limit)
        if truncated:
            stats["truncated_strings"] += 1
            stats["truncated_chars"] += len(value) - len(compact)
        return compact
    if isinstance(value, list):
        items = value[:list_limit]
        omitted = max(0, len(value) - len(items))
        if omitted:
            stats["omitted_item_count"] += omitted
        return [_compact_value(item, text_limit=text_limit, list_limit=list_limit, key=None, stats=stats) for item in items]
    if isinstance(value, dict):
        return {
            str(k): _compact_value(v, text_limit=text_limit, list_limit=list_limit, key=str(k), stats=stats)
            for k, v in value.items()
        }
    return value


def _warning(code: str, message: str) -> dict[str, str]:
    return {"code": code, "message": message}


def _append_warning(payload: dict[str, Any], warning: dict[str, str]) -> None:
    warnings = list(payload.get("warnings") or [])
    if warning not in warnings:
        warnings.append(warning)
    payload["warnings"] = warnings


def _section_summary(value: Any) -> dict[str, Any]:
    if isinstance(value, list):
        return {"omitted": True, "type": "array", "item_count": len(value)}
    if isinstance(value, dict):
        return {"omitted": True, "type": "object", "key_count": len(value), "keys": list(value)[:12]}
    if isinstance(value, str):
        return {"omitted": True, "type": "string", "char_count": len(value)}
    return {"omitted": True, "type": type(value).__name__}


def _fit_payload(payload: dict[str, Any], *, max_bytes: int) -> dict[str, Any]:
    if json_bytes(payload) <= max_bytes:
        return payload
    compact = deepcopy(payload)
    compaction = dict(compact.get("mcp_compaction") or {})
    omitted_sections: list[str] = list(compaction.get("omitted_sections") or [])
    for section in ("diagnostics", "metrics", "snippet_metrics", "project_docs", "dependency_docs", "answer_outline", "trust_contract"):
        if json_bytes(compact) <= max_bytes:
            break
        if compact.get(section) not in (None, [], {}):
            compact[section] = _section_summary(compact[section])
            omitted_sections.append(section)
            compact["mcp_compaction"] = {**compaction, "hard_cap_enforced": True, "omitted_sections": omitted_sections}
    if json_bytes(compact) <= max_bytes:
        return compact
    keep_keys = {
        "status", "tool", "schema_version", "kind", "answer_supported", "answer_available",
        "support_status", "decision", "reason_code", "answer_type", "answer_completeness",
        "edit_ready", "operational", "operational_status", "context_available", "disposition",
        "missing", "missing_requirement_ids", "satisfied_requirement_ids", "mandatory_requirement_ids",
        "mandatory_coverage", "evidence_coverage", "selected_evidence_ids", "requirements_hash",
        "selector_config_hash", "eligibility_contract_hash", "candidate_trace_hash", "selection_hash",
        "assignment_hash", "decision_hash", "hard_stop",
        "mode", "reason", "message", "response_style", "primary_snippet", "context_pack", "supporting_snippets",
        "next_actions", "next_action", "arguments_patch", "warnings", "mcp_compaction",
        "requires_confirmation", "confirmation_reason", "document_content_policy",
        "mutation_authorized", "policy_coverage", "packet_available",
    }
    omitted = [key for key in compact if key not in keep_keys]
    compact = {key: value for key, value in compact.items() if key in keep_keys}
    compact["mcp_compaction"] = {**dict(compact.get("mcp_compaction") or {}), "hard_cap_enforced": True, "omitted_sections": omitted_sections, "omitted_fields": omitted[:40]}
    if json_bytes(compact) <= max_bytes:
        return compact
    if "answer_supported" in payload:
        minimal = {key: deepcopy(value) for key, value in payload.items() if key in _SUPPORT_DECISION_KEYS}
        minimal["mcp_compaction"] = {
            "hard_cap_enforced": True,
            "omitted_fields": [key for key in payload if key not in _SUPPORT_DECISION_KEYS][:40],
        }
        if json_bytes(minimal) <= max_bytes:
            return minimal
    return {
        "status": "failed",
        "reason_code": "transport_size_limit",
        "message": "MCP payload exceeded the transport size limit.",
    }


def is_v4_patch_projection(payload: dict[str, Any]) -> bool:
    """Recognize a validated v4 projection, not a transport-cap escape flag.

    Binding validation belongs to the upstream projector and its snapshot.
    This boundary rechecks the packet schema and final serialization estimate.
    """
    if (payload.get("kind") != "patch_context"
        or type(payload.get("schema_version")) is not int
        or payload.get("schema_version") != 4
        or payload.get("edit_ready") is not False
        or payload.get("result") not in ("data", "failure")
        or payload.get("completeness") not in ("complete", "partial", "unavailable")):
        return False
    from docmancer.docs.application.action_packet import (
        ACTION_PACKET_OUTPUT_SCHEMA, refresh_action_packet_estimate,
    )
    from jsonschema import Draft202012Validator, validators
    estimated = deepcopy(payload)
    refresh_action_packet_estimate(estimated)
    if payload.get("estimated_tokens") != estimated["estimated_tokens"]:
        return False
    core = {key: deepcopy(value) for key, value in payload.items()
            if key not in {"kind", "recommended_next_action", "source_search_status"}}
    refresh_action_packet_estimate(core)
    # Do not recreate selector identities from inline text at this terminal
    # boundary: attribution/proof-role metadata lives in the upstream snapshot.
    strict_validator = validators.extend(
        Draft202012Validator,
        type_checker=Draft202012Validator.TYPE_CHECKER.redefine(
            "integer", lambda checker, value: type(value) is int,
        ),
    )
    if not strict_validator(ACTION_PACKET_OUTPUT_SCHEMA).is_valid(core):
        return False
    from docmancer.docs.application.model_visible_projection import _patch_recovery_errors
    return not _patch_recovery_errors(payload, core)


def compact_mcp_payload(
    payload: dict[str, Any],
    *,
    max_bytes: int = DEFAULT_MCP_COMPACT_OUTPUT_MAX_BYTES,
    tool: str | None = None,
    page: int | None = None,
    page_size: int | None = None,
    include_sections: list[str] | None = None,
) -> dict[str, Any]:
    # This is an internal representation limit, not a negotiated external
    # transport capacity. V4 patch evidence is deliberately indivisible.
    if is_v4_patch_projection(payload):
        return payload
    if payload.get("kind") in {"docs_context", "docs_answer"}:
        return payload
    if json_bytes(payload) <= max_bytes:
        return payload

    # Canonical projections bind citations, coordinates and support decisions.
    # Once finalized, the entire projection is indivisible: terminal transport
    # must not shorten text or lists while retaining the original source claims.
    # Invalid patch projections do not inherit the valid-v4 exemption.
    if payload.get("kind") == "patch_context":
        failure = {
            "status": "failed",
            "reason_code": "transport_size_limit",
            "message": "MCP payload exceeded the transport size limit.",
        }
        if json_bytes(failure) > max_bytes:
            raise ValueError("transport limit cannot fit the minimal error payload")
        return failure

    original_bytes = json_bytes(payload)
    compact = deepcopy(payload)
    if include_sections:
        allowed = {"status", "tool", "schema_version", "answer_available", "answer_type", "warnings", "document_content_policy", "mcp_compaction", *_SUPPORT_DECISION_KEYS, *include_sections}
        compact = {key: value for key, value in compact.items() if key in allowed}

    has_context_pack = "context_pack" in compact
    has_supporting_snippets = "supporting_snippets" in compact
    context_items = list(compact.get("context_pack") or [])
    supporting_items = list(compact.get("supporting_snippets") or [])
    selected_page = paginate_context_items(context_items, page=page, page_size=page_size)
    if has_context_pack:
        compact["context_pack"] = [_compact_context_item(item) for item in selected_page["items"]]
    if has_supporting_snippets:
        compact["supporting_snippets"] = [_compact_context_item(item) for item in supporting_items[: max(1, min(3, int(page_size or 3)))] ]

    stats = {"truncated_strings": 0, "truncated_chars": 0, "omitted_item_count": 0}
    compact = _compact_value(compact, text_limit=900, list_limit=8, key=None, stats=stats)
    compact["mcp_compaction"] = {
        "truncated": True,
        "max_bytes": max_bytes,
        "original_bytes_estimate": original_bytes,
        "returned_bytes": json_bytes(compact),
        "omitted_sections": [],
        "omitted_item_count": stats["omitted_item_count"],
        "truncated_strings": stats["truncated_strings"],
        "truncated_chars": stats["truncated_chars"],
        "page": selected_page["page"],
        "page_size": selected_page["page_size"],
        "total_items": selected_page["total_items"],
        "next_page": selected_page["next_page"],
        "guidance": f"Retry with page={selected_page['next_page']}/page_size={selected_page['page_size']} or include_sections=[...]" if selected_page["next_page"] else "Retry with lower page_size/tokens/limit or include_sections=[...]",
    }
    _append_warning(compact, _warning("mcp_compact_output_truncated", f"Compact MCP response was truncated to stay under {max_bytes} bytes."))
    compact = _fit_payload(compact, max_bytes=max_bytes)
    if isinstance(compact.get("mcp_compaction"), dict):
        for _ in range(3):
            returned_bytes = json_bytes(compact)
            if compact["mcp_compaction"].get("returned_bytes") == returned_bytes:
                break
            compact["mcp_compaction"]["returned_bytes"] = returned_bytes
    return _fit_payload(compact, max_bytes=max_bytes)


def strip_debug_noise(payload: dict[str, Any]) -> dict[str, Any]:
    payload = deepcopy(payload)
    payload.pop("diagnostics", None)
    payload.pop("metrics", None)
    payload.pop("snippet_metrics", None)
    return payload
