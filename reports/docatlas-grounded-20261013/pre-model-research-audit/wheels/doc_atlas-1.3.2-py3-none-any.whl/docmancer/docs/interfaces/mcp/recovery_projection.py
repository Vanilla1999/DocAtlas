"""MCP projection helpers for bounded documentation-failure recovery.

This module only explains failed canonical support. It never grants support and
never replaces a concrete lifecycle/status/user-confirmation recovery with a
semantic rephrase.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from docmancer.docs.application.model_visible_projection import (
    INSUFFICIENT_EVIDENCE_MAX_TOKENS,
    SUPPORT_ENVELOPE_KEYS,
    bound_insufficient_projection,
    estimate_projection_tokens,
)
from docmancer.docs.application.recovery import build_recovery_diagnosis, recovery_action
from docmancer.docs.domain.recovery_handoff import is_safe_local_source_handoff

_RECOVERY_SUMMARY_KEYS = (
    "documentation_supported", "investigation_allowed", "hard_stop",
    "recovery_origin", "recovery_reason_code", "recovery_disposition",
)

_MODULE_RECOVERY_REASON_CODES = frozenset({
    "module_ambiguous", "module_not_found", "no_module_docs",
})
_MODULE_RECOVERY_MISSING = "Select an exact module_path and retry."
_MODULE_RECOVERY_SUPPORT_SUMMARY_KEYS = frozenset({
    "answer_supported", "answer_available", "support_status", "reason_code",
    "decision_hash",
})


def is_operational_recovery_action(value: Any) -> bool:
    if not isinstance(value, dict):
        return False
    return bool(
        value.get("tool") in {"prepare_docs", "docs_status"}
        or value.get("type") == "ask_user_for_library_docs_source"
        or value.get("requires_confirmation")
    )


def bind_module_recovery_selector(
    action: dict[str, Any] | None,
    payload: dict[str, Any],
) -> dict[str, Any] | None:
    """Keep the ambiguous module selector in the returned status action."""

    if not isinstance(action, dict) or action.get("tool") != "docs_status":
        return action
    lanes = payload.get("lanes") if isinstance(payload.get("lanes"), dict) else {}
    project = lanes.get("project") if isinstance(lanes.get("project"), dict) else {}
    selector = str(project.get("module_selector") or "").strip()
    if not selector or project.get("reason_code") != "module_ambiguous":
        return action
    updated = deepcopy(action)
    arguments = (
        deepcopy(updated.get("arguments_patch"))
        if isinstance(updated.get("arguments_patch"), dict) else {}
    )
    arguments["module"] = selector
    updated["arguments_patch"] = arguments
    return updated


def _first_operational_action(payload: dict[str, Any]) -> dict[str, Any] | None:
    candidates = [payload.get("next_action"), *(payload.get("next_actions") or [])]
    return next(
        (item for item in candidates if is_operational_recovery_action(item)),
        None,
    )


def _clean_string(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def _refresh_estimate(payload: dict[str, Any]) -> None:
    payload["estimated_tokens"] = 0
    for _ in range(3):
        actual = estimate_projection_tokens(payload)
        if payload["estimated_tokens"] == actual:
            break
        payload["estimated_tokens"] = actual


def _bound_module_recovery_projection(
    payload: dict[str, Any],
    *,
    max_tokens: int,
) -> None:
    """Keep an executable recovery action and complete exact module locators."""

    reason = str(payload.get("operational_reason_code") or "")
    if reason not in _MODULE_RECOVERY_REASON_CODES:
        return
    rows = payload.get("module_candidates")
    candidates = [
        deepcopy(row)
        for row in rows or []
        if isinstance(row, dict) and str(row.get("module_path") or "").strip()
    ]
    if not candidates:
        return

    payload["module_candidates"] = candidates
    _refresh_estimate(payload)


def _bound_recoverable_insufficient_projection(
    payload: dict[str, Any],
    *,
    max_tokens: int,
) -> None:
    """Make module-aware recovery the final step after generic compaction."""

    reason = str(payload.get("operational_reason_code") or "")
    rows = payload.get("module_candidates")
    candidates = [
        deepcopy(row)
        for row in rows or []
        if isinstance(row, dict) and str(row.get("module_path") or "").strip()
    ]
    action = payload.get("recommended_next_action")
    operational_action = (
        deepcopy(action)
        if is_operational_recovery_action(action)
        else None
    )

    # Generic projection compaction owns ordinary support and failure metadata.
    # Module ambiguity is an MCP recovery extension, so restore its immutable
    # snapshot afterwards and make the module-aware budget pass authoritative.
    bound_insufficient_projection(payload, max_tokens=max_tokens)
    if reason not in _MODULE_RECOVERY_REASON_CODES or not candidates:
        return

    payload["operational_reason_code"] = reason
    payload["module_candidates"] = candidates
    if operational_action is not None:
        payload["recommended_next_action"] = operational_action
    _bound_module_recovery_projection(payload, max_tokens=max_tokens)


def _attach_recovery_diagnosis(
    payload: dict[str, Any],
    *,
    question: str,
    request: dict[str, Any],
    canonical_selection: Any,
    operational_reason_code: Any = None,
) -> dict[str, Any]:
    if canonical_selection is None:
        return payload
    support = getattr(canonical_selection, "support_decision", None)
    if support is not None and bool(getattr(support, "answer_supported", False)):
        return payload
    diagnosis = build_recovery_diagnosis(
        question,
        canonical_selection,
        operational_reason_code=(
            payload.get("operational_reason_code")
            or operational_reason_code
            or payload.get("reason_code")
        ),
    )
    if not diagnosis:
        return payload

    updated = dict(payload)
    updated.update({
        "documentation_supported": bool(diagnosis.get("documentation_supported")),
        "investigation_allowed": bool(diagnosis.get("investigation_allowed", True)),
        "hard_stop": bool(diagnosis.get("hard_stop")),
        "recovery_origin": str(diagnosis.get("origin") or "selection"),
        "recovery_reason_code": str(
            diagnosis.get("reason_code") or "support_not_provable"
        ),
        "recovery_disposition": str(
            diagnosis.get("disposition") or "search_local_source"
        ),
    })

    # A concrete lifecycle/status/user-confirmation action describes a known
    # operational state and is more precise than changing the wording. Preserve
    # it unless canonical evidence reports an authoritative hard stop.
    if bool(diagnosis.get("hard_stop")):
        updated["next_action"] = None
        updated["next_actions"] = []
        updated.pop("recommended_next_action", None)
        return updated
    operational = _first_operational_action(updated)
    if operational is not None and not bool(diagnosis.get("hard_stop")):
        updated.update({
            "recovery_origin": "operational",
            "recovery_reason_code": str(
                updated.get("operational_reason_code")
                or "operational_recovery_precedence"
            ),
            "recovery_disposition": "use_operational_recovery",
        })
        return updated

    action = recovery_action(
        diagnosis,
        project_path=_clean_string(request.get("project_path")),
        scope=_clean_string(request.get("scope")),
        mode=_clean_string(request.get("mode")),
    )
    if action:
        existing = [
            item
            for item in updated.get("next_actions") or []
            if isinstance(item, dict) and item != action
        ]
        updated["next_action"] = action
        updated["next_actions"] = [action, *existing]
    return updated


def _recovery_summary(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        key: deepcopy(payload[key])
        for key in _RECOVERY_SUMMARY_KEYS
        if key in payload
    }


def _annotate_recovery_handoff(
    projection: dict[str, Any],
    recovery: dict[str, Any] | None,
    *,
    edit_authorized: bool = False,
) -> None:
    if bool(projection.get("hard_stop")):
        projection.update({
            "disposition": "resolve_authoritative_conflict",
            "edit_ready": False,
            "source_search_status": "blocked",
        })
        _refresh_estimate(projection)
        return
    if not isinstance(recovery, dict):
        return
    if recovery.get("type") == "rephrase_question":
        projection.update({
            "disposition": "rephrase_question",
            "edit_ready": False,
            "source_search_status": "not_required",
            "requires_confirmation": False,
        })
    elif is_safe_local_source_handoff(recovery):
        # Source investigation and edit authorization are separate decisions.
        # Only the host-owned request classifier may authorize continuation of
        # an explicit mutation workflow; the recovery action cannot self-grant it.
        projection.update({
            "disposition": "search_local_source",
            "edit_ready": bool(edit_authorized),
            "investigation_allowed": True,
            "source_search_status": "required",
            "requires_confirmation": False,
        })
    _refresh_estimate(projection)


__all__ = [
    "_MODULE_RECOVERY_REASON_CODES",
    "_annotate_recovery_handoff",
    "_attach_recovery_diagnosis",
    "_bound_module_recovery_projection",
    "_bound_recoverable_insufficient_projection",
    "_recovery_summary",
    "bind_module_recovery_selector",
    "is_operational_recovery_action",
]

def cross_module_proof_missing(packet: dict[str, Any]) -> bool:
    mutation = packet.get("mutation_intent")
    mutation = mutation if isinstance(mutation, dict) else {}
    plan = mutation.get("request_plan")
    plan = plan if isinstance(plan, dict) else {}
    return bool(
        packet.get("status") == "insufficient_evidence"
        and len(plan.get("mutation_targets") or []) > 1
        and plan.get("behavioral_requirements")
        and any(
            "cross_module_invariant" in str(item)
            for item in packet.get("missing_evidence") or []
        )
    )
