from __future__ import annotations

from dataclasses import asdict
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import urlparse

from docmancer.docs.service import LibraryDocsService
from docmancer.docs.application.docs_job_service import bound_job_diagnostics, project_job_diagnostic
from docmancer.docs.interfaces.mcp.project_tools import _bounded_int_arg, _compact_mcp_payload, handle_project_tool


PREFETCH_TOOL_NAMES = {
    "prepare_docs",
    "docs_status",
    "docs_job",
    "validate_docs_manifest",
    "prefetch_docs_manifest",
    "prefetch_docs_targets",
    "get_docs_job_status",
    "list_docs_jobs",
    "cancel_docs_job",
}

_PREPARE_ACTION_FIELDS = {
    "sync_project_docs": {
        "action", "project_path", "with_vectors", "changed_paths", "deleted_paths", "renamed_paths",
        "plan_digest",
        "mutation",
    },
    "prefetch_project_dependency_docs": {"action", "project_path", "include_flutter", "include_dart", "include_rust", "include_go", "include_packages", "force_refresh", "continue_on_error", "async"},
    "prefetch_library_docs": {"action", "library", "ecosystem", "version", "source_type", "docs_url", "docs_url_template", "force_refresh", "continue_on_error", "async", "question"},
    "discover_library_docs": {"action", "library", "ecosystem", "version"},
    "prefetch_docs_targets": {"action", "targets", "force_refresh", "continue_on_error", "async"},
    "inspect_docs_target": {"action", "target", "max_pages"},
    "validate_docs_manifest": {"action", "manifest_path", "project_path", "targets"},
    "prefetch_docs_manifest": {"action", "manifest_path", "project_path", "targets", "force_refresh", "continue_on_error", "async"},
    "refresh_library_docs": {"action", "library", "ecosystem", "version", "source_type", "docs_url", "force"},
    "prune_library_docs": {"action", "library", "keep_versions", "older_than_days", "dry_run"},
    "remove_library_docs": {"action", "canonical_id", "project_path"},
    "clear_index": {"action", "scope", "project_path", "confirm", "plan_digest", "allow_incomplete"},
    "cancel_docs_job": {"action", "job_id", "project_path"},
}
_PREPARE_REQUIRED_FIELDS = {
    "sync_project_docs": {"project_path"},
    "prefetch_project_dependency_docs": {"project_path"},
    "prefetch_library_docs": {"library"},
    "discover_library_docs": {"library", "ecosystem"},
    "prefetch_docs_targets": {"targets"},
    "inspect_docs_target": {"target"},
    "validate_docs_manifest": {"manifest_path"},
    "prefetch_docs_manifest": {"manifest_path"},
    "refresh_library_docs": {"library"},
    "remove_library_docs": {"canonical_id", "project_path"},
    "clear_index": {"scope", "project_path"},
    "cancel_docs_job": {"job_id"},
}
_REMOTE_PREPARE_ACTIONS = {
    "prefetch_project_dependency_docs",
    "prefetch_library_docs",
    "prefetch_docs_targets",
    "prefetch_docs_manifest",
    "refresh_library_docs",
}
_DOCS_STATUS_MODULE_LIMIT = 8
_DOCS_STATUS_WARNING_LIMIT = 4


def _job_summary(job: Any) -> dict[str, Any]:
    return project_job_diagnostic(job)


def _compact_project_sync(result: Any) -> dict[str, Any]:
    """Expose counts and bounded diagnostics, not the full project inventory."""
    raw = asdict(result)
    diagnostics = dict(raw.get("diagnostics") or {})
    return {
        "status": raw.get("status"),
        "project_path": (raw.get("project") or {}).get("project_path"),
        "candidate_count": raw.get("candidate_count"),
        "summary": {
            key: raw.get(key)
            for key in (
                "current_count", "new_count", "changed_count", "orphaned_count",
                "orphaned_removed", "dedup_removed", "stale_removed", "sections_indexed",
            )
        },
        "metrics": diagnostics.get("metrics") or {},
        "vector_sync": diagnostics.get("vector_sync") or {"status": "not_requested"},
        "unmatched_changed_paths": diagnostics.get("unmatched_changed_paths") or [],
        "unmatched_deleted_paths": diagnostics.get("unmatched_deleted_paths") or [],
        "remaining_deleted_sources": diagnostics.get("remaining_deleted_sources") or 0,
        "tombstones": raw.get("tombstones") or [],
        "tombstones_omitted": diagnostics.get("tombstones_omitted") or 0,
        "warnings": raw.get("warnings") or [],
        "message": raw.get("message"),
    }


def _bounded_project_status(
    project: Any,
    *,
    details: bool,
    module: str | None = None,
) -> dict[str, Any]:
    """Project status for agents: preserve exact module identity without dumping inspect state."""
    if not isinstance(project, dict):
        return {}
    project_docs = project.get("project_docs")
    if not isinstance(project_docs, dict):
        project_docs = {}
    raw_modules = project_docs.get("modules")
    modules = raw_modules if isinstance(raw_modules, list) else []
    selector = str(module or "").strip()
    matching_modules = [
        row for row in modules
        if isinstance(row, dict)
        and (
            not selector
            or selector in {
                str(row.get("module_id") or "").strip(),
                str(row.get("module_name") or "").strip(),
                str(row.get("module_path") or "").strip(),
            }
        )
    ]
    visible_modules: list[dict[str, Any]] = []
    if details:
        seen_paths: set[str] = set()
        for row in matching_modules:
            module_path = str(row.get("module_path") or "").strip()
            if not module_path or module_path in seen_paths:
                continue
            seen_paths.add(module_path)
            visible_modules.append({
                key: row.get(key)
                for key in (
                    "module_id", "module_name", "module_path", "module_type", "doc_count",
                )
                if row.get(key) not in (None, "")
            })
            if len(visible_modules) >= _DOCS_STATUS_MODULE_LIMIT:
                break
    module_count = len(matching_modules)
    raw_diagnostics = project.get("diagnostics")
    diagnostics = raw_diagnostics if isinstance(raw_diagnostics, dict) else {}
    raw_active_index = diagnostics.get("active_index")
    active_index = raw_active_index if isinstance(raw_active_index, dict) else {}
    active_db_path = active_index.get("db_path")
    compact: dict[str, Any] = {
        "project_path": project.get("project_path"),
        "project_detected": project.get("project_detected"),
        "reason_code": project.get("reason_code"),
        "next_action": project.get("next_action") or {},
        "arguments_patch": project.get("arguments_patch") or {},
        "source_summary": {
            "candidates": len(project.get("candidate_sources") or []),
            "indexed": len(project.get("indexed_sources") or []),
            "stale": len(project.get("stale_sources") or []),
            "ignored": len(project.get("ignored_sources") or []),
        },
        "project_docs": {
            "module_count": module_count,
            "modules": visible_modules,
            "modules_omitted": max(0, module_count - len(visible_modules)) if details else module_count,
        },
        "diagnostics": (
            {
                "active_index": {
                    key: active_index.get(key)
                    for key in ("db_path", "config_source", "config_path", "retrieval_mode")
                    if active_index.get(key) not in (None, "")
                }
            }
            if active_db_path not in (None, "") else {}
        ),
        "warnings": list(project.get("warnings") or [])[:_DOCS_STATUS_WARNING_LIMIT],
    }
    if project.get("requires_confirmation"):
        compact["requires_confirmation"] = project.get("requires_confirmation")
        compact["confirmation_reason"] = project.get("confirmation_reason")
    return {
        key: value
        for key, value in compact.items()
        if value not in (None, {}, [])
    }


def _prepare_validation_error(action: str, message: str) -> dict[str, Any]:
    return {
        "tool": "prepare_docs",
        "action": action or None,
        "status": "error",
        "reason_code": "validation_error",
        "message": message,
    }


def validate_prepare_docs_arguments(args: dict[str, Any]) -> dict[str, Any] | None:
    """Validate the public action union before a service can be called."""
    action = str(args.get("action") or "").strip()
    if action not in _PREPARE_ACTION_FIELDS:
        return _prepare_validation_error(action, f"unsupported action: {action or '<missing>'}")
    irrelevant = sorted(set(args) - _PREPARE_ACTION_FIELDS[action])
    if irrelevant:
        return _prepare_validation_error(action, f"field(s) not allowed for action '{action}': {', '.join(irrelevant)}")
    missing = sorted(
        field for field in _PREPARE_REQUIRED_FIELDS.get(action, set())
        if args.get(field) in (None, "", [])
    )
    if missing:
        return _prepare_validation_error(action, f"missing required field(s) for action '{action}': {', '.join(missing)}")
    if action in _REMOTE_PREPARE_ACTIONS and args.get("async") is False:
        return _prepare_validation_error(action, f"action '{action}' always runs asynchronously; omit async or set it to true")
    if action == "clear_index" and args.get("scope") != "project-local":
        return _prepare_validation_error(action, "only scope='project-local' is supported in this release")
    if action == "sync_project_docs":
        if "mutation" in args:
            if set(args) != {"action", "project_path", "mutation"}:
                return _prepare_validation_error(action, "member mutation accepts only action, project_path and mutation")
            from docmancer.docs.application.project_docs_member_transaction import MemberTransaction
            try:
                MemberTransaction.parse(args["mutation"], operation=action)
            except (ValueError, PermissionError) as exc:
                return _prepare_validation_error(action, str(exc))
        plan_digest = args.get("plan_digest")
        if plan_digest is not None and (
            not isinstance(plan_digest, str)
            or len(plan_digest) != 64
            or any(character not in "0123456789abcdefABCDEF" for character in plan_digest)
        ):
            return _prepare_validation_error(action, "plan_digest must be a 64-character hexadecimal digest")
        for field in ("changed_paths", "deleted_paths", "renamed_paths"):
            value = args.get(field)
            if value is not None and not isinstance(value, list):
                return _prepare_validation_error(action, f"{field} must be an array")
            if isinstance(value, list) and len(value) > 500:
                return _prepare_validation_error(action, f"{field} accepts at most 500 entries")
        for field in ("changed_paths", "deleted_paths"):
            for index, value in enumerate(args.get(field) or []):
                if not isinstance(value, str) or not value.strip():
                    return _prepare_validation_error(action, f"{field}[{index}] must be a non-empty string")
        for index, value in enumerate(args.get("renamed_paths") or []):
            if not isinstance(value, dict) or set(value) != {"old_path", "new_path"}:
                return _prepare_validation_error(
                    action,
                    f"renamed_paths[{index}] must contain exactly old_path and new_path",
                )
            if any(not isinstance(value[key], str) or not value[key].strip() for key in value):
                return _prepare_validation_error(
                    action, f"renamed_paths[{index}] paths must be non-empty strings"
                )
    targets = args.get("targets")
    if targets is not None:
        for index, target in enumerate(targets):
            max_pages = target.get("max_pages")
            if max_pages is not None and (isinstance(max_pages, bool) or not isinstance(max_pages, int)):
                return _prepare_validation_error(action, f"targets[{index}].max_pages must be an integer")
            if isinstance(max_pages, int) and max_pages <= 0:
                return _prepare_validation_error(action, f"targets[{index}].max_pages must be positive")
    if action == "inspect_docs_target":
        target = args.get("target")
        if not isinstance(target, dict):
            return _prepare_validation_error(action, "target must be an object")
        if not target.get("library"):
            return _prepare_validation_error(action, "target.library is required")
        target_max_pages = target.get("max_pages")
        if target_max_pages is not None and (
            isinstance(target_max_pages, bool)
            or not isinstance(target_max_pages, int)
            or not 1 <= target_max_pages <= 500
        ):
            return _prepare_validation_error(
                action, "target.max_pages must be an integer between 1 and 500"
            )
        max_pages = args.get("max_pages")
        if max_pages is not None and (
            isinstance(max_pages, bool) or not isinstance(max_pages, int) or not 1 <= max_pages <= 5
        ):
            return _prepare_validation_error(action, "max_pages must be an integer between 1 and 5")
    return None


def _bounded_targets(targets: Any) -> Any:
    if not isinstance(targets, list):
        return []
    bounded = []
    for target in targets:
        if not isinstance(target, dict):
            continue
        item = dict(target)
        if not item.get("allowed_domains"):
            inferred = _infer_allowed_domains(item)
            if inferred:
                item["allowed_domains"] = inferred
        if item.get("max_pages") is not None:
            item["max_pages"] = max(1, min(500, int(item["max_pages"])))
        bounded.append(item)
    return bounded


def _infer_allowed_domains(target: dict[str, Any]) -> list[str]:
    domains: list[str] = []
    urls: list[str] = [*(target.get("seed_urls") or [])]
    if target.get("docs_url"):
        urls.insert(0, target["docs_url"])
    for url in urls:
        parsed = urlparse(str(url))
        if parsed.scheme in {"http", "https"} and parsed.hostname and parsed.hostname not in domains:
            domains.append(parsed.hostname)
    return domains


def _bounded_inspection_target(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    target = dict(value)
    if not target.get("allowed_domains"):
        target["allowed_domains"] = _infer_allowed_domains(target)
    if not target.get("path_prefixes"):
        prefixes: list[str] = []
        urls = [target.get("docs_url"), *(target.get("seed_urls") or [])]
        for raw_url in urls:
            parsed = urlparse(str(raw_url or ""))
            if parsed.scheme not in {"http", "https"} or not parsed.hostname:
                continue
            path = parsed.path or "/"
            parent = str(PurePosixPath(path).parent)
            prefix = path if path.endswith("/") else (parent.rstrip("/") + "/" or "/")
            if prefix not in prefixes:
                prefixes.append(prefix)
        if prefixes:
            target["path_prefixes"] = prefixes[:5]
    # This is the proposed future prefetch limit. The separate action-level
    # max_pages bounds inspection itself to at most five landing pages.
    target["max_pages"] = max(1, min(500, int(target.get("max_pages") or 50)))
    return target


def prefetch_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [tool for tool in tools if tool["name"] in PREFETCH_TOOL_NAMES]


def handle_prefetch_tool(name: str, args: dict[str, Any], service: LibraryDocsService) -> dict[str, Any] | None:
    # Member preparation must not instantiate unrelated registry/job services on
    # a cold store. Complete schema/intent validation precedes even their lookup.
    if name == "prepare_docs" and args.get("action") == "sync_project_docs":
        error = validate_prepare_docs_arguments(args)
        if error:
            return error
        if "mutation" not in args:
            raise PermissionError("explicit complete member mutation grant required")
        from docmancer.core.member_storage_policy import MemberCommitUnknown
        from docmancer.docs.application.project_docs_member_transaction import UnsafeSQLitePathMutation
        try:
            app = getattr(service, "project_docs", service)
            result = _compact_project_sync(app.sync_project_docs(args["project_path"], mutation=args["mutation"]))
            return {"tool": name, "action": "sync_project_docs", **result}
        except UnsafeSQLitePathMutation:
            return {"status": "blocked", "reason_code": "unsafe_sqlite_path_mutation",
                    "retryable": False, "mutation_performed": False,
                    "message": "A trusted host-selected member store is required."}
        except MemberCommitUnknown:
            return {"status": "blocked", "reason_code": "member_commit_outcome_unknown",
                    "retryable": False, "mutation_performed": None,
                    "message": "Commit outcome is unknown; inspect the trusted store before retrying."}
    docs_manifest_app = getattr(service, "docs_manifest", service)
    docs_prefetch_app = getattr(service, "docs_prefetch", service)
    library_docs_app = getattr(service, "library_docs", service)
    project_docs_app = getattr(service, "project_docs", service)
    dependency_docs_app = getattr(service, "dependency_docs", service)
    if name == "docs_status":
        action = str(args.get("action") or "").strip()
        if action == "project":
            project_path = str(args.get("project_path") or "").strip()
            if not project_path:
                return {
                    "tool": "docs_status",
                    "status": "error",
                    "reason_code": "project_path_required",
                    "message": "project_path is required for action='project'",
                }
            project = asdict(project_docs_app.inspect_project_docs(project_path))
            details = args.get("details")
            return {
                "tool": "docs_status",
                "action": action,
                "project": _bounded_project_status(
                    project,
                    details=True if details is None else bool(details),
                    module=str(args.get("module") or "").strip() or None,
                ),
            }
        if action == "library":
            canonical_id = str(args.get("canonical_id") or "").strip()
            if not canonical_id:
                return {
                    "tool": "docs_status",
                    "status": "error",
                    "reason_code": "canonical_id_required",
                    "message": "canonical_id is required for action='library'",
                }
            return {
                "tool": "docs_status",
                "action": action,
                "library": asdict(service.inspect_library_docs(canonical_id)),
            }
        if action == "jobs":
            jobs = service.list_docs_jobs(
                status=args.get("status"),
                limit=_bounded_int_arg(args, "limit", default=50, max_value=200),
                project_path=args.get("project_path"),
            )
            return {
                "tool": "docs_status",
                "action": action,
                "jobs": bound_job_diagnostics(jobs),
            }
        if action == "job":
            job_id = str(args.get("job_id") or "").strip()
            if not job_id:
                return {
                    "tool": "docs_status",
                    "status": "error",
                    "reason_code": "job_id_required",
                    "message": "job_id is required for action='job'",
                }
            job = service.get_docs_job_status(job_id)
            if job is None:
                return {
                    "tool": "docs_status",
                    "action": action,
                    "job_id": job_id,
                    "status": "not_found",
                }
            return {"tool": "docs_status", "action": action, **project_job_diagnostic(job)}
        return {
            "tool": "docs_status",
            "status": "error",
            "reason_code": "unknown_docs_status_action",
            "message": f"unknown docs_status action: {action}",
            "supported_actions": ["project", "library", "jobs", "job"],
        }
    if name == "prepare_docs":
        action = str(args.get("action") or "").strip()
        validation_error = validate_prepare_docs_arguments(args)
        if validation_error:
            return validation_error
        if action == "validate_docs_manifest":
            payload = asdict(docs_manifest_app.validate_docs_manifest(args["manifest_path"], project_path=args.get("project_path"), targets=args.get("targets")))
        elif action == "prefetch_docs_manifest":
            payload = asdict(docs_manifest_app.prefetch_docs_manifest(args["manifest_path"], project_path=args.get("project_path"), targets=args.get("targets"), force_refresh=bool(args.get("force_refresh") or False), continue_on_error=bool(args.get("continue_on_error") if args.get("continue_on_error") is not None else True), async_=True))
        elif action == "prefetch_docs_targets":
            payload = asdict(docs_prefetch_app.prefetch_docs_targets(_bounded_targets(args.get("targets")), force_refresh=bool(args.get("force_refresh") or False), continue_on_error=bool(args.get("continue_on_error") if args.get("continue_on_error") is not None else True), async_=True))
        elif action == "inspect_docs_target":
            target = _bounded_inspection_target(args["target"])
            payload = asdict(service.inspect_docs_target(target, max_pages=int(args.get("max_pages") or 3)))
        elif action == "prefetch_project_dependency_docs":
            payload = asdict(dependency_docs_app.prefetch_project_dependency_docs(args["project_path"], include_flutter=bool(args.get("include_flutter") if args.get("include_flutter") is not None else True), include_dart=bool(args.get("include_dart") or False), include_rust=bool(args.get("include_rust") if args.get("include_rust") is not None else True), include_go=bool(args.get("include_go") if args.get("include_go") is not None else True), include_packages=args.get("include_packages") or [], force_refresh=bool(args.get("force_refresh") or False), continue_on_error=bool(args.get("continue_on_error") if args.get("continue_on_error") is not None else True), async_=True))
        elif action == "prefetch_library_docs":
            # Public MCP calls must not block the server while a remote source is crawled.
            versions = [args["version"]] if args.get("version") else None
            payload = asdict(library_docs_app.prefetch_docs(args["library"], ecosystem=args.get("ecosystem"), versions=versions, docs_url=args.get("docs_url"), docs_url_template=args.get("docs_url_template"), source_type=args.get("source_type"), force_refresh=bool(args.get("force_refresh") or False), continue_on_error=bool(args.get("continue_on_error") if args.get("continue_on_error") is not None else True), async_=True, query=args.get("question")))
        elif action == "discover_library_docs":
            from docmancer.docs.application.library_source_discovery import discover_library_docs_sources

            payload = discover_library_docs_sources(
                args["library"], args.get("ecosystem"), args.get("version")
            )
        elif action == "refresh_library_docs":
            versions = [args["version"]] if args.get("version") else None
            payload = asdict(library_docs_app.prefetch_docs(args["library"], ecosystem=args.get("ecosystem"), versions=versions, docs_url=args.get("docs_url"), docs_url_template=args.get("docs_url_template"), source_type=args.get("source_type"), force_refresh=bool(args.get("force") if args.get("force") is not None else True), continue_on_error=True, async_=True))
        elif action == "remove_library_docs":
            payload = asdict(library_docs_app.remove_library_docs(args["canonical_id"]))
        elif action == "clear_index":
            from docmancer.docs.application.index_storage_cleanup import IndexStorageCleanup

            cleanup = IndexStorageCleanup()
            plan = cleanup.preview(scope="project-local", project_path=args["project_path"])
            if args.get("confirm") is True:
                payload = cleanup.apply(
                    plan,
                    expected_plan_digest=args.get("plan_digest"),
                    allow_incomplete=bool(args.get("allow_incomplete") or False),
                )
            else:
                payload = {
                    **cleanup.payload(plan, status="confirmation_required"),
                    "requires_confirmation": True,
                    "arguments_patch": {
                        "action": "clear_index",
                        "scope": "project-local",
                        "project_path": str(Path(args["project_path"]).resolve()),
                        "plan_digest": plan.plan_digest,
                        "confirm": True,
                    },
                }
        elif action == "prune_library_docs":
            payload = asdict(library_docs_app.prune_library_docs(library=args.get("library"), keep_versions=args.get("keep_versions") or [], older_than_days=int(args.get("older_than_days") or 90), dry_run=bool(args.get("dry_run") if args.get("dry_run") is not None else True)))
        elif action == "cancel_docs_job":
            job_id = str(args.get("job_id") or "").strip()
            if not job_id:
                return {
                    "tool": "prepare_docs",
                    "action": action,
                    "status": "error",
                    "reason_code": "job_id_required",
                    "message": "job_id is required for action='cancel_docs_job'",
                }
            payload = asdict(service.cancel_docs_job(job_id))
        else:
            return {"status": "error", "reason_code": "unknown_prepare_action", "message": f"unknown prepare_docs action: {action}", "supported_actions": ["sync_project_docs", "prefetch_project_dependency_docs", "prefetch_library_docs", "discover_library_docs", "prefetch_docs_targets", "inspect_docs_target", "validate_docs_manifest", "prefetch_docs_manifest", "refresh_library_docs", "prune_library_docs", "remove_library_docs", "clear_index", "cancel_docs_job"]}
        if isinstance(payload, dict):
            payload.setdefault("action", action)
            payload.setdefault("tool", "prepare_docs")
            payload = _compact_mcp_payload(payload)
        return payload
    if name == "docs_job":
        action = str(args.get("action") or "").strip()
        if action == "status":
            job = service.get_docs_job_status(args["job_id"])
            return {"tool": "docs_job", "action": action, "job_id": args["job_id"], "status": "not_found"} if job is None else {"tool": "docs_job", "action": action, **project_job_diagnostic(job)}
        if action == "list":
            return {"tool": "docs_job", "action": action, "jobs": bound_job_diagnostics(service.list_docs_jobs(status=args.get("status"), limit=_bounded_int_arg(args, "limit", default=50, max_value=200), project_path=args.get("project_path")))}
        if action == "cancel":
            return {"tool": "docs_job", "action": action, **asdict(service.cancel_docs_job(args["job_id"]))}
        return {"status": "error", "reason_code": "unknown_docs_job_action", "message": f"unknown docs_job action: {action}", "supported_actions": ["list", "status", "cancel"]}
    if name == "validate_docs_manifest":
        return asdict(docs_manifest_app.validate_docs_manifest(args["manifest_path"], project_path=args.get("project_path"), targets=args.get("targets")))
    if name == "prefetch_docs_manifest":
        return asdict(docs_manifest_app.prefetch_docs_manifest(args["manifest_path"], project_path=args.get("project_path"), targets=args.get("targets"), force_refresh=bool(args.get("force_refresh") or False), continue_on_error=bool(args.get("continue_on_error") if args.get("continue_on_error") is not None else True), async_=bool(args.get("async") or False)))
    if name == "prefetch_docs_targets":
        return asdict(docs_prefetch_app.prefetch_docs_targets(_bounded_targets(args.get("targets")), force_refresh=bool(args.get("force_refresh") or False), continue_on_error=bool(args.get("continue_on_error") if args.get("continue_on_error") is not None else True), async_=bool(args.get("async") or False)))
    if name == "get_docs_job_status":
        job = service.get_docs_job_status(args["job_id"])
        return {"job_id": args["job_id"], "status": "not_found"} if job is None else project_job_diagnostic(job)
    if name == "list_docs_jobs":
        return {"jobs": bound_job_diagnostics(service.list_docs_jobs(status=args.get("status"), limit=_bounded_int_arg(args, "limit", default=50, max_value=200), project_path=args.get("project_path")))}
    if name == "cancel_docs_job":
        return asdict(service.cancel_docs_job(args["job_id"]))
    return None
