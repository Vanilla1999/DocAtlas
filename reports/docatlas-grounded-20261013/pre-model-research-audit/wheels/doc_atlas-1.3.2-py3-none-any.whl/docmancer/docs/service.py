from __future__ import annotations

from datetime import datetime, timezone
import os
from pathlib import Path
from typing import Any
import warnings
import threading
from collections import OrderedDict

from docmancer.core.config import DocmancerConfig
from docmancer.docs.application.docs_job_service import DocsJobService, DocsJobTracker
from docmancer.docs.application.docs_manifest_service import DocsManifestService
from docmancer.docs.application.docs_prefetch_service import DocsPrefetchService
from docmancer.docs.application.docs_target_service import DocsTargetService, target_result_summary
from docmancer.docs.application.dependency_docs_service import DependencyDocsService
from docmancer.docs.application.library_docs_service import LibraryDocsApplicationService
from docmancer.docs.application.project_context_service import ProjectContextService, context_pack_snippet, project_context_metrics, project_context_pack
from docmancer.docs.application.project_docs_service import ProjectDocsService
from docmancer.docs.application.patch_constraint_validation_service import PatchConstraintValidationService
from docmancer.docs.application.patch_constraints_service import PatchConstraintsService
from docmancer.docs.application.unified_context_service import UnifiedDocsContextService
from docmancer.docs.patch_plan_context import PatchPlanContextService
from docmancer.docs.domain.policies import is_stale
from docmancer.docs.domain.project_path_validation import validate_project_path
from docmancer.docs.domain.project_doc_ranking import _found_window_retention_producer, _invoke_found_window_retention
from docmancer.docs.domain.target_security import host_allowed, is_remote_url, path_allowed, url_security_error
from docmancer.docs.domain.trust_contract import build_project_context_trust_contract
from docmancer.docs.infrastructure.agent_index_gateway import AgentIndexGateway
from docmancer.docs.infrastructure.filesystem_locks import FilesystemLockGateway
from docmancer.docs.models import DocsChunk, DocsInspectResult, DocsJob, DocsJobCancelResult, DocsJobStartResult, DocsManifestValidationResult, DocsPruneResult, DocsRemoveResult, DocsResult, DocsSourceResolution, DocsTarget, DocsTargetInspectionResult, DocsTargetResult, DocsTargetsPrefetchResult, LibraryInfo, PatchConstraintPacket, PatchConstraintValidationPacket, ProjectContextResult, ProjectDocsBootstrapResult, ProjectDocsIngestResult, ProjectDocsInspectResult, ProjectDocsResult, ProjectDocsSyncResult, ProjectMetadata, ProjectPrefetchResult, RefreshResult, UnifiedDocsContextResult
from docmancer.docs.project import ProjectMetadataReader
from docmancer.docs.registry import LibraryRecord, LibraryRegistry

STALE_AFTER_DAYS = 30
DEFAULT_DOC_TOKENS = 4000


class LibraryDocsService:
    def __init__(self, *, config: DocmancerConfig | None = None, config_source: str | None = None, config_path: str | Path | None = None, registry: LibraryRegistry | None = None, agent: Any | None = None, agent_factory: Any | None = None, project_reader: ProjectMetadataReader | None = None, job_tracker: DocsJobTracker | None = None, stale_after_days: int = STALE_AFTER_DAYS, library_index_root: Path | None = None, member_storage_policy: Any | None = None, read_only_startup: bool = False, read_only_metadata: bool = False):
        if read_only_startup and (member_storage_policy is None or registry is not None or job_tracker is not None):
            raise PermissionError("read-only startup requires the selected member store and its own read dependencies")
        self.read_only_startup = read_only_startup
        self.config_source = config_source or ("provided" if config is not None else "defaults")
        self.config_path = str(Path(config_path).expanduser().resolve()) if config_path else None
        self.config = config or DocmancerConfig()
        self.member_storage_policy = member_storage_policy
        self._project_service_cache: OrderedDict[tuple[str, str, str], LibraryDocsService] = OrderedDict()
        self._project_service_cache_lock = threading.RLock()
        self.registry = registry if read_only_startup else registry or LibraryRegistry(
            self.config.index.db_path, read_only=read_only_metadata,
        )
        self.agent_gateway = AgentIndexGateway(
            self.config,
            default_agent=agent,
            agent_factory=agent_factory,
            library_index_root=library_index_root,
            member_storage_policy=member_storage_policy,
        )
        # CLI read commands may use a legacy index rather than a member store.
        # They still must not create ancillary ledgers or resume jobs at startup.
        read_dependencies = {"read_only": True} if read_only_metadata else {}
        if read_only_startup:
            # Reuse the owned member reader's current-generation SQL snapshot.
            # Ancillary lookups must not create/repair a ledger on a first read.
            read_connection = self.agent_gateway.read_agent_instance().store._connect
            read_dependencies = {"read_only": True, "read_connection": read_connection}
            self.registry = LibraryRegistry(self.config.index.db_path, **read_dependencies)
        from docmancer.docs.application.source_continuation import SourceContinuationReader
        from docmancer.docs.infrastructure.project_source_read_gateway import ProjectSourceReadGateway
        self.source_reader = SourceContinuationReader(
            ProjectSourceReadGateway(lambda: self._read_agent_instance().store),
        )
        self.lock_gateway = FilesystemLockGateway()
        self.project_reader = project_reader or ProjectMetadataReader()
        self.stale_after_days = stale_after_days
        self.jobs = (
            DocsJobService(job_tracker)
            if job_tracker is not None
            else DocsJobService(
                DocsJobTracker(
                    db_path=self.config.index.db_path,
                    max_history=self.config.docs_jobs.max_terminal_jobs,
                    retention_days=self.config.docs_jobs.retention_days,
                    max_events=self.config.docs_jobs.max_events,
                    **read_dependencies,
                )
            )
        )
        self.library_docs = LibraryDocsApplicationService(self)
        self.project_docs = ProjectDocsService(self)
        self.project_context = ProjectContextService(self)
        self.patch_plan_context = PatchPlanContextService(self)
        self.patch_constraints = PatchConstraintsService(self)
        self.patch_constraint_validation = PatchConstraintValidationService()
        self.dependency_docs = DependencyDocsService(self)
        self.unified_context = UnifiedDocsContextService(self)
        self.docs_targets = DocsTargetService(self._render_docs_url, self.jobs)
        self.docs_prefetch = DocsPrefetchService(self)
        self.docs_manifest = DocsManifestService(self)
        self.resumed_docs_job_ids = [] if read_only_startup or read_only_metadata else self.library_docs.resume_interrupted_jobs()

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def _is_stale(self, last_refreshed_at: str | None) -> bool:
        return is_stale(last_refreshed_at, stale_after_days=self.stale_after_days)

    def _index_config_for(self, record: LibraryRecord) -> DocmancerConfig:
        return self.agent_gateway.index_config_for(record)

    def _agent_instance(self, record: LibraryRecord | None = None) -> Any:
        if self.read_only_startup:
            raise PermissionError("member read facade cannot open a writer; explicit preparation required")
        return self.agent_gateway.agent_instance(record)

    def _read_agent_instance(self) -> Any:
        return self.agent_gateway.read_agent_instance()

    def active_index_diagnostics(self, project_path: str | None = None) -> dict[str, Any]:
        root = validate_project_path(project_path).path if project_path else None
        db_path = Path(self.config.index.db_path).expanduser().resolve()
        db_exists = db_path.exists()
        extracted_dir = (
            str(Path(self.config.index.extracted_dir).expanduser().resolve())
            if self.config.index.extracted_dir
            else None
        )
        diagnostic_warnings: list[dict[str, Any]] = []
        shared_index_counts = {"sources": 0, "sections": 0}
        project_index_counts = {"sources": 0, "sections": 0}
        index_ownership = "absent" if not db_exists else "shared_only"
        agent = None

        # Read-only diagnostics must not instantiate SQLite merely to report an
        # absent index.  Agent/store construction is allowed only after the
        # configured DB has been proven to exist.
        if db_exists:
            try:
                agent = self._read_agent_instance()
                stats = agent.store.collection_stats()
                shared_index_counts = {
                    "sources": int(stats.get("sources_count") or 0),
                    "sections": int(stats.get("sections_count") or stats.get("points_count") or 0),
                }
                extracted_dir = stats.get("extracted_dir") or extracted_dir
                if root and hasattr(agent.store, "project_scope_stats"):
                    scoped = agent.store.project_scope_stats(project_path=str(root))
                    project_index_counts = {
                        "sources": int(scoped.get("sources_count") or 0),
                        "sections": int(scoped.get("sections_count") or 0),
                    }
                    index_ownership = str(scoped.get("ownership") or "no_project_rows")
                elif root:
                    index_ownership = "scope_unknown"
                else:
                    index_ownership = "shared_service"
            except Exception as exc:
                from docmancer.docs.application.library_refresh_policy import bounded_exception_diagnostics
                safe = bounded_exception_diagnostics(exc, failure_phase="diagnostics", failure_operation="active_index_stats")
                diagnostic_warnings.append({
                    "code": "index_stats_unavailable",
                    "blocking": False,
                    "message": safe["exception_message"],
                })
                index_ownership = "unavailable"

        index_counts = project_index_counts if root else shared_index_counts
        diagnostics: dict[str, Any] = {
            "project_path": str(root) if root else None,
            "db_path": str(db_path),
            "db_exists": db_exists,
            "index_state": "available" if db_exists else "absent",
            "index_ownership": index_ownership,
            "extracted_dir": extracted_dir,
            "config_source": self.config_source,
            "config_path": self.config_path,
            "retrieval_mode": self.config.retrieval.default_mode,
            "docatlas_home": os.environ.get("DOCATLAS_HOME"),
            "index_counts": index_counts,
            "project_index_counts": project_index_counts if root else None,
            "shared_index_counts": shared_index_counts,
            "warnings": diagnostic_warnings,
        }
        retrieval_mode = str(self.config.retrieval.default_mode or "lexical").lower()
        if retrieval_mode == "lexical":
            diagnostics["vector_readiness"] = {
                "status": "not_required", "mode": "lexical"
            }
        elif not db_exists:
            diagnostics["vector_readiness"] = {
                "status": "not_ready",
                "mode": retrieval_mode,
                "reason_code": "index_absent",
            }
        else:
            try:
                agent = agent or self._read_agent_instance()
                dispatcher = self.agent_gateway.dispatcher_for(
                    agent, mode=retrieval_mode
                )
                diagnostics["vector_readiness"] = dispatcher.vector_readiness(
                    retrieval_mode
                )
            except Exception as exc:
                diagnostics["vector_readiness"] = {
                    "status": "not_ready",
                    "mode": retrieval_mode,
                    "reason_code": "vector_readiness_unavailable",
                    "error_type": type(exc).__name__,
                }

        if root:
            local_config_path = root / "docatlas.yaml"
            local_config: dict[str, Any] = {"present": local_config_path.is_file()}
            if local_config_path.is_file():
                local_config["path"] = str(local_config_path.resolve())
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", DeprecationWarning)
                        project_config = DocmancerConfig.from_yaml(local_config_path)
                    project_db_path = Path(project_config.index.db_path).expanduser().resolve()
                    local_config["db_path"] = str(project_db_path)
                    if project_db_path != db_path:
                        diagnostic_warnings.append({
                            "code": "project_local_config_shadowed",
                            "blocking": False,
                            "message": (
                                "A repo-local docatlas.yaml exists, but this service is using "
                                "a different active SQLite index path."
                            ),
                            "active_db_path": str(db_path),
                            "project_config_db_path": str(project_db_path),
                        })
                except Exception as exc:
                    from docmancer.docs.application.library_refresh_policy import bounded_exception_diagnostics
                    safe = bounded_exception_diagnostics(
                        exc, failure_phase="configuration", failure_operation="project_config_parse"
                    )
                    diagnostic_warnings.append({
                        "code": "project_local_config_unreadable",
                        "blocking": False,
                        "message": safe["exception_message"],
                    })
            diagnostics["project_local_config"] = local_config
        return diagnostics

    def _lock_for(self, library_id: str):
        return self.lock_gateway.lock_for(library_id)

    @staticmethod
    def _render_docs_url(template: str, library: str, version: str) -> str:
        return template.format(library=library, version=version)

    def read_project_metadata(self, project_path: str) -> ProjectMetadata:
        return self.project_reader.read(project_path)

    def get_docs_job_status(self, job_id: str) -> DocsJob | None:
        return self.jobs.get_docs_job_status(job_id)

    def list_docs_jobs(self, status: str | None = None, limit: int | None = None, project_path: str | None = None) -> list[DocsJob]:
        return self.jobs.list_docs_jobs(status=status, limit=limit, project_path=project_path)

    def cancel_docs_job(self, job_id: str) -> DocsJobCancelResult:
        return self.jobs.cancel_docs_job(job_id)

    def resolve_library(self, *args: Any, **kwargs: Any):
        return self.library_docs.resolve_library(*args, **kwargs)

    def _candidate_payload(self, *args: Any, **kwargs: Any):
        return self.library_docs._candidate_payload(*args, **kwargs)

    def _docs_policy(self, *args: Any, **kwargs: Any):
        return self.library_docs._docs_policy(*args, **kwargs)

    def _docs_identity(self, *args: Any, **kwargs: Any):
        return self.library_docs._docs_identity(*args, **kwargs)

    def _docs_request(self, *args: Any, **kwargs: Any):
        return self.library_docs._docs_request(*args, **kwargs)

    def _record_from_info(self, *args: Any, **kwargs: Any):
        return self.library_docs._record_from_info(*args, **kwargs)

    def _resolve_docs_source(self, *args: Any, **kwargs: Any):
        return self.library_docs.resolve_docs_source(*args, **kwargs)

    def _docs_exactness(self, *args: Any, **kwargs: Any):
        return self.library_docs._docs_exactness(*args, **kwargs)

    def _join_warnings(self, *args: Any, **kwargs: Any):
        return self.library_docs._join_warnings(*args, **kwargs)

    def _refresh_record(self, *args: Any, **kwargs: Any):
        return self.library_docs._refresh_record(*args, **kwargs)

    def _refresh_record_unlocked(self, *args: Any, **kwargs: Any):
        return self.library_docs.refresh_ops.refresh_record(*args, **kwargs)

    def refresh_docs(self, *args: Any, **kwargs: Any):
        return self.library_docs.refresh_docs(*args, **kwargs)

    def prefetch_docs(self, *args: Any, **kwargs: Any):
        return self.library_docs.prefetch_docs(*args, **kwargs)

    def get_docs(self, *args: Any, **kwargs: Any):
        return self.library_docs.get_docs(*args, **kwargs)

    def inspect_library_docs(self, *args: Any, **kwargs: Any):
        return self.library_docs.inspect_library_docs(*args, **kwargs)

    def remove_library_docs(self, *args: Any, **kwargs: Any):
        return self.library_docs.remove_library_docs(*args, **kwargs)

    def prune_library_docs(self, *args: Any, **kwargs: Any):
        return self.library_docs.prune_library_docs(*args, **kwargs)

    def list_libraries(self, *args: Any, **kwargs: Any):
        return self.library_docs.list_libraries(*args, **kwargs)

    def _index_size_for(self, *args: Any, **kwargs: Any):
        return self.library_docs._index_size_for(*args, **kwargs)

    def _delete_index_for(self, *args: Any, **kwargs: Any):
        return self.library_docs._delete_index_for(*args, **kwargs)

    def _record_age_cutoff_value(self, *args: Any, **kwargs: Any):
        return self.library_docs._record_age_cutoff_value(*args, **kwargs)

    def inspect_project_docs(self, *args: Any, **kwargs: Any):
        return self.project_docs.inspect_project_docs(*args, **kwargs)

    def ingest_project_docs(self, *args: Any, **kwargs: Any):
        return self.project_docs.ingest_project_docs(*args, **kwargs)

    def sync_project_docs(self, *args: Any, **kwargs: Any):
        return self.project_docs.sync_project_docs(*args, **kwargs)

    def bootstrap_project_docs(self, *args: Any, **kwargs: Any):
        return self.project_docs.bootstrap_project_docs(*args, **kwargs)

    def query_project_docs(self, *args: Any, **kwargs: Any):
        return self.project_docs.query_project_docs(*args, **kwargs)

    @_found_window_retention_producer
    def get_project_docs(self, *args: Any, **kwargs: Any):
        return _invoke_found_window_retention(self.project_docs.get_project_docs, *args, **kwargs)

    def _indexed_project_doc_sources(self, *args: Any, **kwargs: Any):
        return self.project_docs._indexed_project_doc_sources(*args, **kwargs)

    def _source_state_guidance(self, *args: Any, **kwargs: Any):
        return self.project_docs._source_state_guidance(*args, **kwargs)

    def _partition_project_doc_state(self, *args: Any, **kwargs: Any):
        return self.project_docs._partition_project_doc_state(*args, **kwargs)

    def _has_high_level_project_overview(self, *args: Any, **kwargs: Any):
        return self.project_docs._has_high_level_project_overview(*args, **kwargs)

    def _project_dependency_docs_state(self, *args: Any, **kwargs: Any):
        return self.project_docs._project_dependency_docs_state(*args, **kwargs)

    def _create_project_docs_next_action(self, *args: Any, **kwargs: Any):
        return self.project_docs._create_project_docs_next_action(*args, **kwargs)

    def _project_docs_structured_next_action(self, *args: Any, **kwargs: Any):
        return self.project_docs._project_docs_structured_next_action(*args, **kwargs)

    @_found_window_retention_producer
    def get_project_context(self, *args: Any, **kwargs: Any):
        return _invoke_found_window_retention(self.project_context.get_project_context, *args, **kwargs)

    def get_patch_plan_context(self, *args: Any, **kwargs: Any):
        return self.patch_plan_context.get_patch_plan_context(*args, **kwargs)

    def get_patch_constraints(self, *args: Any, **kwargs: Any) -> PatchConstraintPacket:
        return self.patch_constraints.get_patch_constraints(*args, **kwargs)

    def validate_patch_against_constraints(self, *args: Any, **kwargs: Any) -> PatchConstraintValidationPacket:
        return self.patch_constraint_validation.validate_patch_against_constraints(*args, **kwargs)

    def get_docs_context(self, *args: Any, **kwargs: Any):
        return self.unified_context.get_docs_context(*args, **kwargs)

    def _dependency_mentioned_in_question(self, *args: Any, **kwargs: Any):
        return self.project_context.dependency_mentioned_in_question(*args, **kwargs)

    def prefetch_project_dependency_docs(self, *args: Any, **kwargs: Any):
        return self.dependency_docs.prefetch_project_dependency_docs(*args, **kwargs)

    def _is_flutter_library(self, *args: Any, **kwargs: Any):
        return self.dependency_docs._is_flutter_library(*args, **kwargs)

    def _flutter_docs_url_for(self, *args: Any, **kwargs: Any):
        return self.dependency_docs._flutter_docs_url_for(*args, **kwargs)

    def _flutter_docs_version_for(self, *args: Any, **kwargs: Any):
        return self.dependency_docs._flutter_docs_version_for(*args, **kwargs)

    def _project_resolution_summary(self, *args: Any, **kwargs: Any):
        return self.dependency_docs._project_resolution_summary(*args, **kwargs)

    def _dependency_observation_for(self, *args: Any, **kwargs: Any):
        return self.dependency_docs._dependency_observation_for(*args, **kwargs)

    def _project_version_for(self, *args: Any, **kwargs: Any):
        return self.dependency_docs._project_version_for(*args, **kwargs)

    def _target_from_record(self, *args: Any, **kwargs: Any):
        return self.docs_targets.target_from_record(*args, **kwargs)

    def _record_urls(self, *args: Any, **kwargs: Any):
        return self.docs_targets.record_urls(*args, **kwargs)

    def _target_urls(self, *args: Any, **kwargs: Any):
        return self.docs_targets.target_urls(*args, **kwargs)

    def inspect_docs_target(self, *args: Any, **kwargs: Any) -> DocsTargetInspectionResult:
        return self.docs_targets.inspect_docs_target(*args, **kwargs)

    def _resolve_github_directory_target(self, *args: Any, **kwargs: Any):
        return self.docs_targets.resolve_github_directory_target(*args, **kwargs)

    def _discover_pub_dartdoc_target(self, *args: Any, **kwargs: Any):
        return self.docs_targets.discover_pub_dartdoc_target(*args, **kwargs)

    def _progress_callback_for(self, *args: Any, **kwargs: Any):
        return self.docs_prefetch.progress_callback_for(*args, **kwargs)

    def prefetch_docs_targets(self, *args: Any, **kwargs: Any):
        return self.docs_prefetch.prefetch_docs_targets(*args, **kwargs)

    def _prefetch_docs_targets_sync(self, *args: Any, **kwargs: Any):
        return self.docs_prefetch.prefetch_docs_targets_sync(*args, **kwargs)

    def _run_prefetch_docs_targets_job(self, *args: Any, **kwargs: Any):
        return self.docs_prefetch._run_prefetch_docs_targets_job(*args, **kwargs)

    def _resolve_manifest_project_version(self, *args: Any, **kwargs: Any):
        return self.docs_manifest.resolve_manifest_project_version(*args, **kwargs)

    def validate_docs_manifest(self, *args: Any, **kwargs: Any):
        return self.docs_manifest.validate_docs_manifest(*args, **kwargs)

    def prefetch_docs_manifest(self, *args: Any, **kwargs: Any):
        return self.docs_manifest.prefetch_docs_manifest(*args, **kwargs)

    @staticmethod
    def _target_from_dict(value: dict[str, Any] | DocsTarget) -> DocsTarget:
        return DocsTargetService.target_from_dict(value)

    @staticmethod
    def _target_to_spec(target: DocsTarget, urls: list[str] | None = None) -> dict[str, Any]:
        return DocsTargetService.target_to_spec(target, urls)

    @staticmethod
    def _is_remote_url(url: str) -> bool:
        return is_remote_url(url)

    @staticmethod
    def _url_security_error(url: str) -> str | None:
        return url_security_error(url)

    @staticmethod
    def _host_allowed(url: str, allowed_domains: list[str]) -> bool:
        return host_allowed(url, allowed_domains)

    @staticmethod
    def _path_allowed(url: str, path_prefixes: list[str]) -> bool:
        return path_allowed(url, path_prefixes)

    @staticmethod
    def _dependency_docs_url_guidance(target: DocsTarget) -> list[str]:
        return DocsTargetService.dependency_docs_url_guidance(target)

    @staticmethod
    def _merge_manifest_defaults(defaults: dict[str, Any], target: dict[str, Any]) -> dict[str, Any]:
        return DocsManifestService.merge_manifest_defaults(defaults, target)

    @staticmethod
    def _project_context_pack(*, project_docs: ProjectDocsResult | None, dependency_docs: DocsResult | None) -> list[dict[str, Any]]:
        return project_context_pack(project_docs=project_docs, dependency_docs=dependency_docs)

    @staticmethod
    def _context_pack_snippet(item: DocsChunk) -> dict[str, Any] | None:
        return context_pack_snippet(item)

    @staticmethod
    def _project_context_metrics(*, context_pack: list[dict[str, Any]], project_docs: ProjectDocsResult | None, dependency_docs: DocsResult | None) -> dict[str, Any]:
        return project_context_metrics(context_pack=context_pack, project_docs=project_docs, dependency_docs=dependency_docs)

    @staticmethod
    def _project_context_trust_contract(
        *,
        project_docs: ProjectDocsResult | None,
        dependency_docs: DocsResult | None,
        requested_library: str | None,
        mode: str,
        context_pack: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        return build_project_context_trust_contract(project_docs=project_docs, dependency_docs=dependency_docs, requested_library=requested_library, mode=mode, context_pack=context_pack)

    @staticmethod
    def _target_result_summary(result: DocsTargetResult) -> dict[str, Any]:
        return target_result_summary(result)
