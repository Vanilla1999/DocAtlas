from __future__ import annotations

from dataclasses import dataclass
import hashlib
import threading
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping, Sequence

from docmancer.core.config import DocmancerConfig
from docmancer.core.product_identity import ensure_owned_home, resolve_home
from docmancer.docs.application.evidence_selection import (
    EvidenceRequirementSet,
    requirement_probe_query,
)
from docmancer.docs.models import SOURCE_CLASS_PROJECT_FILE
from docmancer.docs.domain.lifecycle_policy import lifecycle_filters_for_intent
from docmancer.docs.registry import LibraryRecord
from docmancer.docs.resolver import normalize_library_name
from docmancer.retrieval.runtime import dispatcher_for_agent, effective_retrieval_mode
from docmancer.retrieval.contracts import canonical_hash


@dataclass(frozen=True, slots=True)
class LibraryWitnessProbe:
    """Bounded raw index evidence for classifying an insufficient answer."""

    status: str
    queried_requirement_ids: tuple[str, ...] = ()
    chunks: tuple[Any, ...] = ()
    failure_count: int = 0


@dataclass(frozen=True, slots=True)
class DocumentComponentCandidate:
    """A raw document-local hit with retrieval lineage, not a support claim."""

    component_id: str
    stable_identity: str
    project_doc_path: str
    chunk: Any
    provenance: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class DocumentComponentSearch:
    """Bounded infrastructure result for already-observed project documents."""

    status: str
    queried_component_ids: tuple[str, ...] = ()
    candidates: tuple[DocumentComponentCandidate, ...] = ()
    failure_count: int = 0


class AgentIndexGateway:
    def __init__(
        self,
        config: DocmancerConfig,
        *,
        default_agent: Any | None = None,
        agent_factory: Callable[..., Any] | None = None,
        library_index_root: Path | str | None = None,
        member_storage_policy: Any | None = None,
    ):
        if agent_factory is None:
            from docmancer.agent import DocmancerAgent

            agent_factory = DocmancerAgent
        self.config = config
        self._default_agent = default_agent
        self.member_storage_policy = member_storage_policy
        self._read_default_agent = None
        self._agents: dict[str, Any] = {}
        self._retrieval_dispatchers: dict[int, tuple[tuple[Any, ...], Any]] = {}
        self._cache_lock = threading.RLock()
        self._agent_factory = agent_factory
        self._library_index_root = Path(library_index_root).expanduser().resolve() if library_index_root else None

    def index_config_for(self, record: LibraryRecord) -> DocmancerConfig:
        config = self.config.model_copy(deep=True)
        if self._library_index_root is not None:
            root = self._library_index_root
        else:
            home_resolution = resolve_home()
            owned_home = ensure_owned_home(home_resolution.path)
            root = owned_home / "docs-indexes"
        root.mkdir(parents=True, exist_ok=True)
        safe = normalize_library_name(record.library_id) or "library"
        config.index.db_path = str(root / f"{safe}.db")
        config.index.extracted_dir = str(root / safe / "extracted")
        return config

    def agent_instance(self, record: LibraryRecord | None = None) -> Any:
        if record is not None:
            key = record.canonical_id or record.library_id
            with self._cache_lock:
                if key not in self._agents:
                    self._agents[key] = self._agent_factory(config=self.index_config_for(record))
                return self._agents[key]

        with self._cache_lock:
            if self._default_agent is None:
                self._default_agent = self._agent_factory(config=self.config)
            return self._default_agent

    def read_agent_instance(self) -> Any:
        """Read the selected owned member store without opening the writer."""
        policy = self.member_storage_policy
        if policy is None:
            return self.agent_instance()
        from docmancer.core.member_storage_policy import MemberStoragePolicy
        if not isinstance(policy, MemberStoragePolicy) or not policy.validate(storage_path=self.config.index.db_path):
            raise PermissionError("member store has not been explicitly initialized")
        if self.config.index.provider != "sqlite" or effective_retrieval_mode(self.config) != "lexical":
            raise PermissionError("member reads require the current SQLite lexical configuration")
        with self._cache_lock:
            if self._read_default_agent is None:
                from docmancer.agent import DocmancerAgent
                from docmancer.core.member_read_store import MemberReadStore
                agent = DocmancerAgent(config=self.config, _lazy_init=True)
                agent._store = MemberReadStore(policy, self.config.index.extracted_dir or None)
                self._read_default_agent = agent
            return self._read_default_agent

    def agent_for_config(self, config: DocmancerConfig) -> Any:
        """Create an uncached agent for an isolated staging index."""
        return self._agent_factory(config=config)

    def query_library(
        self,
        record: LibraryRecord,
        topic: str,
        *,
        budget: int | None = None,
        filters: dict[str, Any] | None = None,
        requirements: Any | None = None,
    ) -> Any:
        """Run the dispatcher against the isolated index for one library record."""
        agent = self.agent_instance(record)
        if not hasattr(agent, "store"):
            return agent.query(topic, budget=budget)
        mode = effective_retrieval_mode(agent.config)
        dispatch_args: dict[str, Any] = {
            "mode": mode,
            "budget": budget,
            "filters": filters,
        }
        if requirements is not None:
            dispatch_args["requirements"] = requirements
        return self.dispatcher_for(agent, mode=mode).run(topic, **dispatch_args)

    def dispatcher_for(self, agent: Any, *, mode: str | None = None) -> Any:
        """Return the mode-aware dispatcher used by public project-doc queries."""
        effective_mode = effective_retrieval_mode(agent.config, mode)
        collection_fn = getattr(agent, "_vector_collection_name", None)
        collection = collection_fn() if callable(collection_fn) else ""
        embeddings = getattr(agent.config, "embeddings", None)
        vector_store = getattr(agent.config, "vector_store", None)
        store = getattr(agent, "store", None)
        generation_info = store.generation_info() if callable(getattr(store, "generation_info", None)) else None
        cache_key = (
            id(store),
            effective_mode,
            collection,
            canonical_hash(agent.config.model_dump(mode="json")),
            canonical_hash(generation_info or {}),
        )
        with self._cache_lock:
            cached = self._retrieval_dispatchers.get(id(agent))
            if cached is not None and cached[0] == cache_key:
                return cached[1]
            dispatcher = dispatcher_for_agent(agent, mode=effective_mode)
            self._retrieval_dispatchers[id(agent)] = (cache_key, dispatcher)
            return dispatcher

    def _drop_dispatcher_for_agent(self, agent: Any | None) -> None:
        if agent is not None:
            with self._cache_lock:
                self._retrieval_dispatchers.pop(id(agent), None)

    def probe_library_requirements(
        self,
        record: LibraryRecord,
        requirements: EvidenceRequirementSet,
        *,
        missing_requirement_ids: Sequence[str],
        filters: dict[str, Any] | None = None,
        max_requirements: int = 4,
        max_results_per_requirement: int = 3,
        budget: int = 120,
    ) -> LibraryWitnessProbe:
        """Query the same isolated lexical index after a support miss.

        This deliberately bypasses dispatcher ranking only for diagnostics: it
        proves that a missing requirement exists in the bounded record index,
        never turns a witness into a user-facing answer.
        """

        agent = self.agent_instance(record)
        store = getattr(agent, "store", None)
        if store is None or not callable(getattr(store, "query", None)):
            return LibraryWitnessProbe(status="unavailable")
        missing = set(str(value) for value in missing_requirement_ids)
        ordered = [
            requirement for requirement in requirements
            if requirement.requirement_id in missing and requirement.mandatory
        ][:max(1, int(max_requirements))]
        queries = [
            (requirement.requirement_id, requirement_probe_query(requirement))
            for requirement in ordered
        ]
        queries = [(requirement_id, query) for requirement_id, query in queries if query]
        if not queries:
            return LibraryWitnessProbe(status="not_applicable")
        per_query_budget = max(1, int(budget) // len(queries))
        chunks: list[Any] = []
        seen: set[str] = set()
        failures = 0
        for _, query in queries:
            try:
                rows = store.query(
                    query,
                    limit=max(1, int(max_results_per_requirement)),
                    budget=per_query_budget,
                    filters=filters,
                )
            except Exception:
                failures += 1
                continue
            for chunk in rows or ():
                metadata = getattr(chunk, "metadata", None) or {}
                identity = str(
                    metadata.get("stable_chunk_id")
                    or metadata.get("section_id")
                    or hashlib.sha256(
                        f"{getattr(chunk, 'source', '')}\0{getattr(chunk, 'text', '')}".encode()
                    ).hexdigest()
                )
                if identity not in seen:
                    seen.add(identity)
                    chunks.append(chunk)
        status = (
            "ok" if chunks else
            "unavailable" if failures == len(queries) else
            "incomplete" if failures else
            "no_witness"
        )
        return LibraryWitnessProbe(
            status=status,
            queried_requirement_ids=tuple(requirement_id for requirement_id, _ in queries),
            chunks=tuple(chunks),
            failure_count=failures,
        )

    def search_document_components(
        self,
        project_identity: str,
        project_path: Path | str,
        project_doc_paths: Sequence[str],
        component_queries: Sequence[tuple[str, str]],
        *,
        max_components: int = 4,
        budget: int = 120,
        lifecycle_intent: str = "current",
    ) -> DocumentComponentSearch:
        """Return raw lexical candidates from at most two observed documents.

        The caller owns observation and semantic interpretation. This gateway
        only supplies production retrieval lineage and never qualifies a hit or
        claims that it supports a component.
        """

        identity = str(project_identity or "").strip()
        root = str(project_path or "").strip()
        try:
            component_limit = max(1, min(int(max_components), 4))
            total_budget = max(1, min(int(budget), 480))
        except (TypeError, ValueError):
            return DocumentComponentSearch(status="invalid_request")
        paths: list[str] = []
        for value in project_doc_paths or ():
            raw = str(value or "").strip().replace("\\", "/").removeprefix("./")
            pure = PurePosixPath(raw)
            if not raw or not pure.parts or pure.is_absolute() or ".." in pure.parts:
                return DocumentComponentSearch(status="invalid_request")
            canonical = pure.as_posix()
            if canonical not in paths:
                paths.append(canonical)
        queries: list[tuple[str, str]] = []
        for value in component_queries or ():
            if not isinstance(value, (tuple, list)) or len(value) != 2:
                return DocumentComponentSearch(status="invalid_request")
            component_id, query = (str(part or "").strip() for part in value)
            if not component_id or not query:
                return DocumentComponentSearch(status="invalid_request")
            if component_id not in {item[0] for item in queries}:
                queries.append((component_id, query))
        if (
            lifecycle_intent not in {"current", "historical", "either"}
            or not identity or not root or not paths or len(paths) > 2
            or not queries or len(queries) > component_limit
        ):
            return DocumentComponentSearch(status="invalid_request")

        try:
            agent = self.read_agent_instance()
            store = getattr(agent, "store", None)
        except Exception:
            return DocumentComponentSearch(status="unavailable", failure_count=1)
        if store is None or not callable(getattr(store, "query", None)):
            return DocumentComponentSearch(status="unavailable")
        filters = {
            "project_identity": identity,
            "project_path": root,
            "project_doc_path": {"in": paths},
            "source_class": SOURCE_CLASS_PROJECT_FILE,
            **lifecycle_filters_for_intent(lifecycle_intent),
        }
        per_query_budget = max(1, total_budget // len(queries))
        candidates: list[DocumentComponentCandidate] = []
        seen: set[tuple[str, str]] = set()
        queried_ids: list[str] = []
        try:
            dispatcher = self.dispatcher_for(agent, mode="lexical")
            for component_id, query in queries:
                queried_ids.append(component_id)
                result = dispatcher.run(
                    query,
                    mode="lexical",
                    limit=4,
                    budget=per_query_budget,
                    expand="none",
                    filters=filters,
                )
                for chunk in getattr(result, "chunks", ()) or ():
                    metadata = getattr(chunk, "metadata", None) or {}
                    candidate_path = str(metadata.get("project_doc_path") or "")
                    stable_identity = str(
                        metadata.get("stable_chunk_id")
                        or metadata.get("section_id")
                        or hashlib.sha256(
                            f"{getattr(chunk, 'source', '')}\0{getattr(chunk, 'chunk_index', '')}\0{getattr(chunk, 'text', '')}".encode()
                        ).hexdigest()
                    )
                    source_identity = (candidate_path, stable_identity)
                    if candidate_path not in paths or source_identity in seen:
                        continue
                    seen.add(source_identity)
                    candidates.append(DocumentComponentCandidate(
                        component_id=component_id,
                        stable_identity=stable_identity,
                        project_doc_path=candidate_path,
                        chunk=chunk,
                        provenance={
                            "producer": "retrieval_dispatcher",
                            "mode": getattr(result, "mode_used", "lexical"),
                            "query_plan_hash": getattr(result, "query_plan_hash", ""),
                            "fusion_config_hash": getattr(result, "fusion_config_hash", ""),
                            "retrieval_trace": dict(metadata.get("retrieval_trace") or {}),
                        },
                    ))
                    if len(candidates) == 4:
                        break
                if len(candidates) == 4:
                    break
        except Exception:
            return DocumentComponentSearch(
                status="unavailable",
                queried_component_ids=tuple(queried_ids),
                failure_count=1,
            )
        return DocumentComponentSearch(
            status="ok" if candidates else "no_candidates",
            queried_component_ids=tuple(queried_ids),
            candidates=tuple(candidates),
        )

    def drop_library_agent(self, record_or_library_id: LibraryRecord | str) -> None:
        if isinstance(record_or_library_id, LibraryRecord):
            first = self._agents.pop(
                record_or_library_id.canonical_id or record_or_library_id.library_id,
                None,
            )
            second = self._agents.pop(record_or_library_id.library_id, None)
            self._drop_dispatcher_for_agent(first)
            self._drop_dispatcher_for_agent(second)
            return

        self._drop_dispatcher_for_agent(self._agents.pop(record_or_library_id, None))
