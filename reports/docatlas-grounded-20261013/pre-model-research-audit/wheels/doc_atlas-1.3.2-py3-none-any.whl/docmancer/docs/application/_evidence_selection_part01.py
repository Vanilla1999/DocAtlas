"""Implementation shard 1 for evidence_selection."""
from __future__ import annotations

from ._evidence_selection_shared import *  # noqa: F401,F403

@dataclass(frozen=True, slots=True)
class SelectionDecision:
    status: Literal["ok", "insufficient_evidence"]
    selected_candidates: tuple[EvidenceCandidate, ...]
    omissions: tuple[Omission, ...]
    missing_requirements: tuple[str, ...]
    unresolved_conflicts: tuple[str, ...]
    metrics: Mapping[str, Any]
    selector_config_hash: str
    eligibility_contract_hash: str
    candidate_trace_hash: str
    selection_hash: str
    assignments: tuple[EvidenceAssignment, ...]
    support_decision: SupportDecision
    requirements: EvidenceRequirementSet = field(
        default_factory=EvidenceRequirementSet, compare=False, repr=False,
    )

    def __post_init__(self) -> None:
        if not isinstance(self.requirements, EvidenceRequirementSet):
            object.__setattr__(self, "requirements", EvidenceRequirementSet(tuple(self.requirements)))

    @property
    def selected_items(self) -> list[dict[str, Any]]:
        return [dict(candidate.original) for candidate in self.selected_candidates]

    def audit_manifest(self) -> dict[str, Any]:
        return {
            "schema_version": SELECTOR_SCHEMA_VERSION,
            "status": self.status,
            "selected_stable_ids": [item.stable_id for item in self.selected_candidates],
            "omissions": [
                {
                    "stable_id": item.stable_id,
                    "reason_code": item.reason_code,
                    "representative_stable_id": item.representative_stable_id,
                }
                for item in self.omissions
            ],
            "omission_counts": _count_reasons(self.omissions),
            "missing_requirements": list(self.missing_requirements),
            "unresolved_conflicts": list(self.unresolved_conflicts),
            "metrics": dict(self.metrics),
            "selector_config_hash": self.selector_config_hash,
            "eligibility_contract_hash": self.eligibility_contract_hash,
            "requirements_hash": self.requirements.requirements_hash,
            "candidate_trace_hash": self.candidate_trace_hash,
            "selection_hash": self.selection_hash,
            "assignments": [asdict(item) for item in self.assignments],
            "assignment_hash": self.support_decision.assignment_hash,
            "support_decision": self.support_decision.as_payload(),
        }


def resolve_assignment_unit(
    candidate: EvidenceCandidate,
    assignment: EvidenceAssignment,
) -> AnswerUnit | None:
    if not assignment.unit_id:
        return None
    return next(
        (item for item in candidate.answer_units if item.unit_id == assignment.unit_id),
        None,
    )


def validate_assignment_binding(
    requirement: EvidenceRequirement,
    candidate: EvidenceCandidate,
    assignment: EvidenceAssignment,
    *,
    requirements: Sequence[EvidenceRequirement] = (),
) -> bool:
    from ._evidence_selection_part02 import _legacy_requirement_matches_unit

    if (
        assignment.requirement_id != requirement.requirement_id
        or assignment.evidence_id != candidate.stable_id
        or assignment.path != candidate.path_or_url
        or assignment.proof_role != requirement.proof_role
        or requirement.qualifiers
        or not _candidate_window_valid(candidate)
        or not _candidate_lifecycle_valid(requirement, candidate)
        or not _proof_role_admitted(requirement, candidate, requirements)
    ):
        return False
    unit = resolve_assignment_unit(candidate, assignment)
    if unit is None:
        return (
            assignment.unit_id is None
            and _technical_requirement_matches(requirement, candidate)
            and assignment.char_start == candidate.char_start
            and assignment.char_end == candidate.char_end
            and assignment.line_start == candidate.line_start
            and assignment.line_end == (
                candidate.line_start + candidate.display_text.count("\n")
                if not candidate.answer_units_representation_bounded and candidate.line_start is not None
                else candidate.line_start
            )
            and assignment.projected_content_hash == hashlib.sha256(candidate.projected_text.encode("utf-8")).hexdigest()
            and all(value is None for value in (
                assignment.unit_kind, assignment.unit_char_start,
                assignment.unit_char_end, assignment.unit_content_hash,
            ))
        )
    if not _unit_matches_display(candidate, unit):
        return False
    absolute_start = (candidate.char_start or 0) + unit.char_start
    absolute_end = (candidate.char_start or 0) + unit.char_end
    line = (candidate.line_start or 0) + candidate.display_text[:unit.char_start].count("\n")
    if (
        assignment.unit_kind != unit.kind
        or assignment.unit_char_start != unit.char_start
        or assignment.unit_char_end != unit.char_end
        or assignment.unit_content_hash != unit.content_sha256
        or assignment.projected_content_hash != unit.content_sha256
        or assignment.char_start != absolute_start
        or assignment.char_end != absolute_end
        or assignment.line_start != line
        or assignment.line_end != (
            line + unit.text.count("\n") if not candidate.answer_units_representation_bounded else line
        )
    ):
        return False
    obligation = requirement.as_proof_obligation()
    if obligation is None:
        return _legacy_requirement_matches_unit(requirement, unit, candidate)
    return local_proof_for_obligation(
        obligation,
        unit,
        source=_candidate_source_view(candidate),
        representation_bounded=candidate.answer_units_representation_bounded,
    ).valid


def _candidate_window_valid(candidate: EvidenceCandidate) -> bool:
    """Bind local units to the normalized display, not authenticate a parent source."""
    from .evidence_candidates import _span, authority, source_path, version_binding, resolved_version
    from docmancer.docs.domain.answer_units import MAX_ANSWER_UNITS

    digest = hashlib.sha256(candidate.display_text.encode("utf-8")).hexdigest()
    supplied = candidate.original.get("display_content_hash")
    metadata = candidate.original.get("metadata")
    metadata = metadata if isinstance(metadata, Mapping) else {}
    stable = (
        candidate.original.get("stable_chunk_id") or candidate.original.get("stable_child_id")
        or metadata.get("stable_chunk_id") or candidate.original.get("stable_id")
    )
    return (
        digest == candidate.content_sha256
        and (not candidate.answer_units_representation_bounded or len(candidate.answer_units) <= MAX_ANSWER_UNITS)
        and _display_text(candidate.original) == candidate.display_text
        and source_path(candidate.original) == candidate.path_or_url
        and authority(candidate.original) == candidate.authority
        and (not stable or str(stable) == candidate.stable_id)
        and str(candidate.original.get("parent_logical_id") or metadata.get("parent_logical_id") or "") == candidate.parent_logical_id
        and str(candidate.original.get("project_identity") or "") == candidate.project_identity
        and str(candidate.original.get("module_id") or "") == candidate.module_id
        and version_binding(candidate.original) == candidate.version_binding
        and resolved_version(candidate.original) == candidate.resolved_version
        and (candidate.original.get("docs_snapshot_exact") if isinstance(candidate.original.get("docs_snapshot_exact"), bool) else None) == candidate.docs_snapshot_exact
        and _span(candidate.original, "char") == (candidate.char_start, candidate.char_end)
        and (
            candidate.answer_units_representation_bounded
            or candidate.char_start is None
            or candidate.char_end - candidate.char_start == len(candidate.display_text)
        )
        and _span(candidate.original, "line") == (candidate.line_start, candidate.line_end)
        and (not supplied or str(supplied).casefold() == digest)
        and not candidate.original.get("stale")
        and candidate.freshness == "current"
        and str(candidate.original.get("freshness") or "current") == candidate.freshness
        and str(candidate.original.get("index_freshness") or "synchronized") == "synchronized"
    )


def _candidate_lifecycle_valid(requirement: EvidenceRequirement, candidate: EvidenceCandidate) -> bool:
    lifecycle = str(_candidate_source_view(candidate).get("project_doc_lifecycle_status") or "active").casefold()
    current = lifecycle in {"active", "current", ""}
    historical = lifecycle in {"completed", "historical", "closed", "superseded", "deprecated"}
    return requirement.lifecycle_intent == "either" or (
        current if requirement.lifecycle_intent == "current" else historical
    )


def _proof_role_admitted(
    requirement: EvidenceRequirement,
    candidate: EvidenceCandidate,
    requirements: Sequence[EvidenceRequirement],
) -> bool:
    """Shared canonical role admission; a role label is never a proof grant."""
    if requirement.proof_role == "project_rule":
        return False
    if requirement.proof_role == "implementation_fact":
        return candidate.source_class in {"source_snippet", "test", "project_file"}
    if requirement.proof_role == "dependency_fact":
        return candidate.source_class not in {
            "repo_map", "code_graph", "absent_in_source", "project_file", "source_snippet", "test",
        } and _version_rank(candidate.version_binding) == 0
    if requirement.proof_role == "document_statement":
        scoped_paths = {
            _normalized_source(item.value) for item in requirements if item.kind == "evidence_path"
        }
        return bool(scoped_paths) and _normalized_source(candidate.path_or_url) in scoped_paths
    return True


def _unit_matches_display(candidate: EvidenceCandidate, unit: AnswerUnit) -> bool:
    if not _candidate_window_valid(candidate) or unit.source_field is not None:
        return False
    if unit.char_start is None or unit.char_end is None:
        return False
    # Re-extraction rejects forged kinds/IDs/windows; proposition is not authority.
    return any(
        (fresh.unit_id, fresh.kind, fresh.text, fresh.char_start, fresh.char_end, fresh.content_sha256)
        == (unit.unit_id, unit.kind, unit.text, unit.char_start, unit.char_end, unit.content_sha256)
        for fresh in extract_answer_units(
            candidate.display_text, include_soft_wrapped_prose=True,
            representation_bounded=candidate.answer_units_representation_bounded,
        )
    )


def _technical_requirement_matches(requirement: EvidenceRequirement, candidate: EvidenceCandidate) -> bool:
    """Only explicit non-content scope bindings may have unit-less assignments."""
    if not _candidate_window_valid(candidate) or not _candidate_lifecycle_valid(requirement, candidate):
        return False
    if requirement.qualifiers:
        return False
    kind, value = requirement.kind, requirement.value
    if kind in {"evidence_path", "target_path"}:
        source, wanted = _normalized_source(candidate.path_or_url), _normalized_source(value)
        return bool(wanted) and (source == wanted or source.endswith("/" + wanted))
    if kind == "project_identity":
        return bool(value) and candidate.project_identity == value
    if kind == "module_id":
        return bool(value) and candidate.module_id == value
    if kind == "exact_version":
        return bool(value) and candidate.resolved_version == value and _version_rank(candidate.version_binding) == 0
    if kind == "exact_snapshot":
        return value == "true" and candidate.docs_snapshot_exact is True
    return False


@dataclass(frozen=True, slots=True)
class MixedSelectionLane:
    lane: Literal["project", "library"]
    identity: str
    decision: SelectionDecision

    @property
    def qualifier(self) -> str:
        return f"{self.lane}:{self.identity}"


@dataclass(frozen=True, slots=True)
class AggregateMixedSelectionDecision:
    """Canonical mixed-lane decision with collision-safe child identities."""

    lanes: tuple[MixedSelectionLane, ...]
    selection_decision: SelectionDecision
    child_decision_hash: str
    child_assignment_hash: str

    @property
    def requirements(self) -> EvidenceRequirementSet:
        return self.selection_decision.requirements

    @property
    def selected_candidates(self) -> tuple[EvidenceCandidate, ...]:
        return self.selection_decision.selected_candidates

    @property
    def assignments(self) -> tuple[EvidenceAssignment, ...]:
        return self.selection_decision.assignments

    @property
    def support_decision(self) -> SupportDecision:
        return self.selection_decision.support_decision

    def audit_manifest(self) -> dict[str, Any]:
        return {
            **self.selection_decision.audit_manifest(),
            "mixed_lanes": [
                {
                    "lane": lane.lane,
                    "identity": lane.identity,
                    "decision_hash": lane.decision.support_decision.decision_hash,
                    "assignment_hash": lane.decision.support_decision.assignment_hash,
                }
                for lane in self.lanes
            ],
            "child_decision_hash": self.child_decision_hash,
            "child_assignment_hash": self.child_assignment_hash,
        }


def aggregate_mixed_selection(
    entries: Iterable[tuple[Literal["project", "library"], str, SelectionDecision]],
) -> AggregateMixedSelectionDecision:
    """Combine canonical lane decisions without allowing cross-lane ID aliasing."""

    lanes = tuple(sorted(
        (MixedSelectionLane(lane, str(identity), decision) for lane, identity, decision in entries),
        key=lambda item: (item.lane, item.identity),
    ))
    if len(lanes) < 2:
        raise ValueError("mixed selection requires at least two lane decisions")

    requirements: list[EvidenceRequirement] = []
    candidates: list[EvidenceCandidate] = []
    assignments: list[EvidenceAssignment] = []
    missing: list[str] = []
    conflicts: list[str] = []
    omissions: list[Omission] = []
    for lane in lanes:
        prefix = lane.qualifier + ":"
        requirements.extend(
            replace(requirement, requirement_id=prefix + requirement.requirement_id)
            for requirement in lane.decision.requirements
        )
        candidates.extend(
            replace(
                candidate,
                stable_id=prefix + candidate.stable_id,
                evidence_id=prefix + candidate.evidence_id,
                covered_requirement_ids=frozenset(
                    prefix + requirement_id
                    for requirement_id in candidate.covered_requirement_ids
                ),
            )
            for candidate in lane.decision.selected_candidates
        )
        assignments.extend(
            replace(
                assignment,
                requirement_id=prefix + assignment.requirement_id,
                evidence_id=prefix + assignment.evidence_id,
            )
            for assignment in lane.decision.assignments
        )
        missing.extend(prefix + value for value in lane.decision.missing_requirements)
        conflicts.extend(prefix + value for value in lane.decision.unresolved_conflicts)
        omissions.extend(
            replace(
                omission,
                stable_id=prefix + omission.stable_id,
                representative_stable_id=(
                    prefix + omission.representative_stable_id
                    if omission.representative_stable_id else None
                ),
            )
            for omission in lane.decision.omissions
        )

    requirement_set = EvidenceRequirementSet(tuple(requirements))
    mandatory_ids = tuple(item.requirement_id for item in requirement_set if item.mandatory)
    satisfied_ids = tuple(sorted({item.requirement_id for item in assignments}))
    missing_ids = tuple(sorted(set(mandatory_ids) - set(satisfied_ids)))
    selected_ids = tuple(sorted({item.evidence_id for item in assignments}))
    child_decision_hash = canonical_hash([
        (lane.lane, lane.identity, lane.decision.support_decision.decision_hash)
        for lane in lanes
    ])
    child_assignment_hash = canonical_hash([
        (lane.lane, lane.identity, lane.decision.support_decision.assignment_hash)
        for lane in lanes
    ])
    assignment_hash = canonical_hash({
        "assignments": [asdict(item) for item in assignments],
        "child_assignment_hash": child_assignment_hash,
    })
    selected_documents = {_normalized_source(item.source_identity) for item in candidates}
    selected_tokens = sum(item.token_estimate for item in candidates)
    supported = all(lane.decision.support_decision.answer_supported for lane in lanes)
    base = {
        "answer_supported": supported,
        "support_status": "supported" if supported else "insufficient_evidence",
        "reason_code": (
            None if supported else
            "mixed_support_incomplete"
        ),
        "missing_requirement_ids": missing_ids,
        "satisfied_requirement_ids": satisfied_ids,
        "mandatory_requirement_ids": mandatory_ids,
        "mandatory_coverage": (
            len(set(satisfied_ids) & set(mandatory_ids)) / len(mandatory_ids)
            if mandatory_ids else 1.0
        ),
        "selected_evidence_ids": selected_ids,
        "requirements_hash": requirement_set.requirements_hash,
        "selector_config_hash": canonical_hash([lane.decision.selector_config_hash for lane in lanes]),
        "eligibility_contract_hash": canonical_hash([lane.decision.eligibility_contract_hash for lane in lanes]),
        "candidate_trace_hash": canonical_hash([lane.decision.candidate_trace_hash for lane in lanes]),
        "selection_hash": canonical_hash({
            "children": child_decision_hash,
            "selected_evidence_ids": selected_ids,
        }),
        "assignment_hash": assignment_hash,
    }
    support = SupportDecision(
        **base,
        decision_hash=canonical_hash({**base, "child_decision_hash": child_decision_hash}),
        requirements=requirement_set,
    )
    decision = SelectionDecision(
        status="ok" if supported else "insufficient_evidence",
        selected_candidates=tuple(candidates), omissions=tuple(omissions),
        missing_requirements=tuple(missing), unresolved_conflicts=tuple(conflicts),
        metrics={
            "lane_count": len(lanes),
            "selected_documents": len(selected_documents),
            "selected_spans": len(candidates),
            "selected_tokens": selected_tokens,
            "projected_total_tokens": selected_tokens + MIXED_WRAPPER_RESERVE_TOKENS,
            "max_documents": None,
            "max_spans": None,
            "hard_tokens": None,
        },
        selector_config_hash=support.selector_config_hash,
        eligibility_contract_hash=support.eligibility_contract_hash,
        candidate_trace_hash=support.candidate_trace_hash,
        selection_hash=support.selection_hash, assignments=tuple(assignments),
        support_decision=support, requirements=requirement_set,
    )
    return AggregateMixedSelectionDecision(
        lanes=lanes, selection_decision=decision,
        child_decision_hash=child_decision_hash,
        child_assignment_hash=child_assignment_hash,
    )


def docs_selection_config(max_tokens: int) -> SelectionConfig:
    return SelectionConfig(
        result_kind="docs_answer", target_tokens=None, hard_tokens=None,
        marginal_utility_threshold=100,
    )


def library_docs_selection_config(max_tokens: int) -> SelectionConfig:
    return replace(docs_selection_config(max_tokens), profile="library_docs_answer")


def project_docs_selection_config(max_tokens: int) -> SelectionConfig:
    return replace(docs_selection_config(max_tokens), profile="project_docs_answer")


def patch_selection_config() -> SelectionConfig:
    return SelectionConfig(
        result_kind="patch_context", target_tokens=None, hard_tokens=None,
        max_candidates=None, max_sources=None, max_items_per_source=None,
        max_documents=None, max_spans=None, wrapper_reserve_tokens=None,
        marginal_utility_threshold=None,
    )


def _eligible_candidates(
    candidates: Sequence[EvidenceCandidate],
    trust_contract: Mapping[str, Any],
    requirements: Sequence[EvidenceRequirement],
    *,
    project_identity: str | None,
    module_id: str | None,
    result_kind: str,
    question: str,
) -> tuple[list[EvidenceCandidate], list[Omission], set[str]]:
    exact_versions = {item.value for item in requirements if item.kind == "exact_version" and item.mandatory}
    eligible: list[EvidenceCandidate] = []
    omissions: list[Omission] = []
    critical: set[str] = set()
    blocked_sources = _rejected_patch_source_keys(trust_contract) if result_kind == "patch_context" else set()
    for candidate in candidates:
        reason: OmissionReason | None = None
        if blocked_sources.intersection(candidate.identity_aliases):
            reason = "forbidden_source"
        elif candidate.freshness.casefold() == "stale":
            reason = "stale"
        elif project_identity and candidate.project_identity != project_identity:
            reason = "outside_scope"
        elif module_id and candidate.module_id != module_id:
            reason = "outside_scope"
        elif exact_versions and _version_rank(candidate.version_binding) == 2:
            reason = "unknown_version"
        elif exact_versions and candidate.resolved_version not in exact_versions:
            reason = "wrong_version"
        if reason:
            omissions.append(Omission(candidate.stable_id, reason))
        else:
            eligible.append(candidate)
    return eligible, omissions, critical


def _rejected_patch_source_keys(trust_contract: Mapping[str, Any]) -> set[str]:
    """Match explicit source identities only, independently of legacy rendering."""
    sources = trust_contract.get("sources")
    rejected = sources.get("rejected") if isinstance(sources, Mapping) else None
    rows = [rejected] if isinstance(rejected, (str, Mapping)) else rejected if isinstance(rejected, (list, tuple)) else ()
    keys: set[str] = set()
    for row in rows:
        if isinstance(row, str):
            values = [row]
        elif isinstance(row, Mapping):
            values = [row.get(name) for name in (
                "source_identity", "source", "path", "url", "source_url", "canonical_id", "library_id", "library",
            )]
            aliases = row.get("identity_aliases")
            values.extend(aliases if isinstance(aliases, (list, tuple)) else [aliases])
        else:
            continue
        for value in values:
            if isinstance(value, Mapping):
                value = _source_path(value)
            if isinstance(value, str) and (key := _normalized_source(value)):
                keys.add(key)
    return keys


def _query_identifier_conflict(
    candidate: EvidenceCandidate,
    query_identifiers: Sequence[str],
) -> bool:
    """Reject prefix lookalikes without excluding unrelated supporting evidence."""

    haystack = "\n".join((candidate.display_text, *candidate.symbols)).casefold()
    for value in query_identifiers:
        exact_match = False
        prefix_match = False
        start = haystack.find(value)
        while start >= 0:
            before = haystack[start - 1] if start else ""
            after_index = start + len(value)
            after = haystack[after_index] if after_index < len(haystack) else ""
            if not (before == "_" or before.isalnum()):
                if after == "_" or after.isalnum():
                    prefix_match = True
                else:
                    exact_match = True
                    break
            start = haystack.find(value, start + 1)
        if prefix_match and not exact_match:
            return True
    return False


def _query_identifier_values(
    requirements: Sequence[EvidenceRequirement],
) -> tuple[str, ...]:
    return tuple(
        requirement.value.casefold()
        for requirement in requirements
        if requirement.public_provenance == "query_exact_term"
        and (
            "_" in requirement.value
            or "." in requirement.value
            or "::" in requirement.value
            or (
                any(char.isupper() for char in requirement.value[1:])
                and any(char.islower() for char in requirement.value)
            )
        )
    )


def _candidate_source_view(candidate: EvidenceCandidate) -> dict[str, Any]:
    metadata = candidate.original.get("metadata")
    metadata = metadata if isinstance(metadata, Mapping) else {}
    view = dict(metadata)
    view.update({
        "content": candidate.display_text,
        "text": candidate.display_text,
        "path": candidate.path_or_url,
        "source": candidate.path_or_url,
        "title": candidate.section,
        "heading_path": candidate.section,
        "project_identity": candidate.project_identity,
        "module_id": candidate.module_id,
        "authority": candidate.original.get("authority") or candidate.authority,
        "project_doc_authority": (
            candidate.original.get("project_doc_authority")
            or metadata.get("project_doc_authority")
            or candidate.original.get("authority")
            or candidate.authority
        ),
        "project_doc_lifecycle_status": (
            candidate.original.get("project_doc_lifecycle_status")
            or metadata.get("project_doc_lifecycle_status")
            or candidate.original.get("lifecycle_status")
            or metadata.get("lifecycle_status")
            or "active"
        ),
    })
    return view


def _candidate_preference(candidate: EvidenceCandidate, *, length_dependent: bool = True) -> tuple[Any, ...]:
    return (
        _version_rank(candidate.version_binding),
        0 if candidate.docs_snapshot_exact is True else 1,
        -len(candidate.covered_requirement_ids),
        *((candidate.token_estimate,) if length_dependent else ()),
        -candidate.relevance_millis,
        candidate.retrieval_rank,
        candidate.stable_id,
    )


def _candidate_requirement_witness(
    candidate: EvidenceCandidate,
    requirement_id: str,
) -> RequirementWitness | None:
    return next(
        (item for item in candidate.requirement_witnesses if item.requirement_id == requirement_id),
        None,
    )


def _lifecycle_assignment_rank(
    requirement: EvidenceRequirement,
    candidate: EvidenceCandidate,
) -> int:
    lifecycle = str(
        _candidate_source_view(candidate).get("project_doc_lifecycle_status") or "active"
    ).casefold()
    historical = lifecycle in {"completed", "historical", "closed", "superseded", "deprecated"}
    if requirement.lifecycle_intent == "either":
        return 0
    if requirement.lifecycle_intent == "historical":
        return 0 if historical else 1
    return 1 if historical else 0


def _assignment_preference(
    requirement: EvidenceRequirement,
    candidate: EvidenceCandidate,
    witness: RequirementWitness | None,
    *,
    length_dependent: bool = True,
) -> tuple[Any, ...]:
    target_identity_rank = 0
    if requirement.proof_role == "target_identity":
        wanted = requirement.value.casefold().replace("\\", "/")
        target_identity_rank = 0 if (
            any(symbol.casefold() == wanted for symbol in candidate.symbols)
            or candidate.source_identity.casefold().replace("\\", "/").endswith("/" + wanted)
            or candidate.source_identity.casefold().replace("\\", "/") == wanted
        ) else 1
    return (
        0 if witness is not None else 1,
        -(witness.completeness_score if witness else 0),
        target_identity_rank,
        _lifecycle_assignment_rank(requirement, candidate),
        _version_rank(candidate.version_binding),
        -candidate.relevance_millis,
        *((len(witness.unit_text) if witness else candidate.token_estimate * 4,) if length_dependent else ()),
        candidate.retrieval_rank,
        candidate.stable_id,
    )


def _selected_identity(candidate: EvidenceCandidate) -> dict[str, Any]:
    return {
        "stable_id": candidate.stable_id,
        "content_sha256": candidate.content_sha256,
        "source_identity": candidate.source_identity,
        "parent_logical_id": candidate.parent_logical_id,
        "projected_content_sha256": hashlib.sha256(
            candidate.projected_text.encode("utf-8")
        ).hexdigest(),
    }


def _shingles(value: str, size: int) -> set[tuple[str, ...]]:
    tokens = [token.casefold() for token in _TOKEN_RE.findall(" ".join(value.split()))]
    if not tokens:
        return set()
    if len(tokens) < size:
        return {tuple(tokens)}
    return {tuple(tokens[index:index + size]) for index in range(len(tokens) - size + 1)}


def _jaccard_millis(left: str, right: str, size: int) -> int:
    left_set, right_set = _shingles(left, size), _shingles(right, size)
    union = left_set | right_set
    return int(len(left_set & right_set) * 1000 / len(union)) if union else 0


def _repair_mandatory_selection(
    selected: Sequence[EvidenceCandidate],
    candidates: Sequence[EvidenceCandidate],
    mandatory: set[str],
    *,
    prefer_proof_completeness: bool = False,
) -> list[EvidenceCandidate]:
    """One bounded 1/2-item replacement pass for a smaller complete cover."""

    if not selected or not mandatory:
        return list(selected)
    current = list(selected)
    current_ids = {item.stable_id for item in current}
    pool = [item for item in candidates if item.stable_id not in current_ids]

    def complete(rows: Sequence[EvidenceCandidate]) -> bool:
        coverage = set().union(*(item.covered_requirement_ids for item in rows)) if rows else set()
        return mandatory <= coverage

    def quality(rows: Sequence[EvidenceCandidate]) -> tuple[Any, ...]:
        proof_quality: tuple[Any, ...] = ()
        if prefer_proof_completeness:
            proof_quality = (-sum(
                witness.completeness_score
                for item in rows
                for witness in item.requirement_witnesses
                if witness.requirement_id in mandatory
            ),)
        return (
            *proof_quality,
            sum(_version_rank(item.version_binding) for item in rows),
            sum(item.token_estimate for item in rows),
            len(rows),
            tuple(sorted(item.stable_id for item in rows)),
        )

    best, best_quality = current, quality(current)
    removals = [combo for size in (1, 2) for combo in itertools.combinations(current, min(size, len(current)))]
    additions = [combo for size in (1, 2) for combo in itertools.combinations(pool, min(size, len(pool)))]
    for removed in removals:
        retained = [item for item in current if item not in removed]
        for added in additions:
            proposal = [*retained, *added]
            proposal_quality = quality(proposal)
            if complete(proposal) and proposal_quality < best_quality:
                best, best_quality = proposal, proposal_quality
    return best


def _selection_terms(candidates: Sequence[EvidenceCandidate]) -> set[str]:
    return {
        token.casefold()
        for candidate in candidates
        for token in _TOKEN_RE.findall(candidate.display_text)
        if len(token) > 2
    }


def _marginal_utility(candidate: EvidenceCandidate, selected_terms: set[str], mandatory: set[str]) -> int:
    terms = {token.casefold() for token in _TOKEN_RE.findall(candidate.display_text) if len(token) > 2}
    novelty = min(80, len(terms - selected_terms) * 4)
    return (
        len(candidate.covered_requirement_ids & mandatory) * 1000
        + len(candidate.covered_requirement_ids) * 180
        + (120 if _version_rank(candidate.version_binding) == 0 else 20)
        + (80 if candidate.docs_snapshot_exact is True else 0)
        + (80 if candidate.projected_text.strip() else 0)
        + min(100, max(0, candidate.relevance_millis // 10))
        + (60 if candidate.symbols else 0)
        + novelty
        - (80 if candidate.navigation_only else 0)
    )


def _redundant_token_ratio_millis(
    candidates: Sequence[EvidenceCandidate], config: SelectionConfig
) -> int:
    redundant = 0
    accepted: list[EvidenceCandidate] = []
    for candidate in candidates:
        if any(
            _jaccard_millis(candidate.display_text, previous.display_text, config.shingle_size)
            >= config.near_duplicate_threshold
            for previous in accepted
        ):
            redundant += candidate.token_estimate
        accepted.append(candidate)
    total = sum(item.token_estimate for item in candidates)
    return int(redundant * 1000 / total) if total else 0


def _count_reasons(omissions: Sequence[Omission]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for omission in omissions:
        counts[omission.reason_code] = counts.get(omission.reason_code, 0) + 1
    return dict(sorted(counts.items()))

__all__=['SelectionDecision', 'resolve_assignment_unit', 'validate_assignment_binding', 'MixedSelectionLane', 'AggregateMixedSelectionDecision', 'aggregate_mixed_selection', 'docs_selection_config', 'library_docs_selection_config', 'project_docs_selection_config', 'patch_selection_config', '_eligible_candidates', '_query_identifier_conflict', '_query_identifier_values', '_candidate_source_view', '_candidate_preference', '_candidate_requirement_witness', '_lifecycle_assignment_rank', '_assignment_preference', '_selected_identity', '_shingles', '_jaccard_millis', '_repair_mandatory_selection', '_selection_terms', '_marginal_utility', '_redundant_token_ratio_millis', '_count_reasons']
