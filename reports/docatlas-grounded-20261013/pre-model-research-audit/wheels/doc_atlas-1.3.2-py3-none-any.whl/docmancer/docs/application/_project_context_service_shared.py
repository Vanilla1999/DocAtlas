from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any
import re

from docmancer.docs.application.project_answer_outline import build_project_answer_outline
from docmancer.docs.application.evidence_selection import (
    build_requirements,
    project_docs_selection_config,
    select_evidence,
)
from docmancer.docs.application.evidence_requirements import build_patch_evidence_requirements
from docmancer.docs.domain.answer_completeness import (
    derive_project_answer_completeness,
    extract_project_answer_requirements,
    extract_query_relevance_terms,
)
from docmancer.docs.domain.mutation_intent import MutationIntentContract, build_mutation_intent
from docmancer.docs.domain.lifecycle_policy import (
    lifecycle_allows,
    lifecycle_intent as lifecycle_intent_for_question,
    temporal_relevance_for_status,
)
from docmancer.docs.domain.project_doc_ranking import is_changelog_path, normalize_doc_path, project_source_taxonomy, rerank_project_doc_chunks
from docmancer.docs.domain.project_query_intent import classify_project_query_intent
from docmancer.docs.domain.project_state import bound_project_docs_handoff, evaluate_documentation_sections
from docmancer.docs.domain.project_evidence import classify_project_evidence
from docmancer.docs.domain.quality import has_code_symbol_evidence, internal_noise_score, is_trivial_section, looks_like_code_or_command
from docmancer.docs.domain.snippets import best_context_pack_snippet, build_snippet_presentation, validate_response_style
from docmancer.docs.domain.source_map import build_project_repo_map, build_project_source_evidence, collect_project_source_facts, source_evidence_diagnostics, source_map_diagnostics
from docmancer.docs.domain.code_graph import build_code_graph_context_items, build_project_code_graph, code_graph_context_diagnostics, code_graph_diagnostics
from docmancer.docs.domain.trust_contract import build_project_context_trust_contract
from docmancer.docs.domain.content_trust import annotate_context_pack
from docmancer.docs.domain.documentation_query_plan import build_documentation_query_plan
from docmancer.docs.domain.query_terms import documentation_query_terms
from docmancer.docs.domain.retrieval_routing import (
    fit_stage_items,
    new_routing_record,
    record_stage,
    route_gap_recovery_stages,
    route_initial_stages,
    should_run_code_graph,
    should_run_repo_map,
    validate_routing_record,
)
from docmancer.docs.models import DeliveryDecision, DocsChunk, DocsResult, ProjectContextResult, ProjectDocsChunk, ProjectDocsResult, ProjectMetadata

LOW_TRUST_PROJECT_RISK_FLAGS = frozenset({
    "research_artifact",
    "dogfood_artifact",
    "patch_review_artifact",
    "generated_review_output",
})


def _dependency_confirmation_blocks_local_answer(
    *,
    has_confirmation: bool,
    explicit_dependency_requested: bool,
    local_answer_available: bool,
) -> bool:
    """Return whether dependency acquisition must block local delivery.

    Auto-detected dependencies are a recall hint.  They may request network
    access only when local project evidence did not already prove the answer.
    Explicit dependency/deps-only requests retain the confirmation boundary.
    """

    return bool(
        has_confirmation
        and (explicit_dependency_requested or not local_answer_available)
    )


@dataclass(frozen=True)
class ContextTrustDecision:
    answer_available: bool
    reason: str
    confidence: str
    passed_relevance_gate: bool
    max_project_score: float | None
    query_terms_matched: list[str]
    query_terms_missing: list[str]


def _documentation_gap_actions(actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [action for action in actions if action.get("action") == "create_reviewable_project_doc"]


def _source_ground_documentation_gap(
    actions: list[dict[str, Any]],
    *,
    root: Path,
    repo_map: list[dict[str, Any]] | None = None,
    code_graph: Any = None,
    allow_repo_map_build: bool = True,
    allow_code_graph_build: bool = True,
) -> tuple[list[dict[str, Any]], Any]:
    """Attach bounded paths while returning the observed repo map for host diagnostics."""
    gap_actions = _documentation_gap_actions(actions)
    if not gap_actions:
        return repo_map or [], code_graph
    observed_repo_map = repo_map
    if repo_map is None and allow_repo_map_build:
        observed_repo_map = collect_project_source_facts(
            root,
            max_files=24,
            token_budget=4000,
            include_unmatched=True,
        )
        repo_map, _ = fit_stage_items("repo_map", observed_repo_map)
    repo_map = repo_map or []
    if code_graph is None and allow_code_graph_build:
        code_graph = build_project_code_graph(
            root,
            max_files=24,
            token_budget=4000,
            include_unmatched=True,
        )
    evidence = classify_project_evidence(root, repo_map=repo_map, code_graph=code_graph)
    for action in gap_actions:
        gap = dict(action.get("documentation_gap") or {})
        sections, evidence_complete = evaluate_documentation_sections(
            list(gap.get("required_sections") or []),
            evidence,
        )
        gap["required_sections"] = sections
        gap["evidence_to_collect"] = evidence
        gap["evidence_complete"] = evidence_complete
        action["documentation_gap"] = gap
        compact = bound_project_docs_handoff(action)
        action.clear()
        action.update(compact)
    return observed_repo_map or repo_map, code_graph




def project_context_pack(*, question: str = "", project_docs: ProjectDocsResult | None, dependency_docs: DocsResult | None) -> list[dict[str, Any]]:
    pack: list[dict[str, Any]] = []
    source_native = True
    answer_lifecycle_intent = lifecycle_intent_for_question(question)
    if project_docs:
        for item in project_docs.results:
            lifecycle_metadata = {"lifecycle_status": item.lifecycle_status or "active"}
            if item.stale or not lifecycle_allows(lifecycle_metadata, answer_lifecycle_intent):
                continue
            if not source_native and _drop_placeholder_context_doc(item):
                continue
            if not source_native and _drop_low_value_context_section(item.content, item.title, item.heading_path):
                continue
            token_estimate = max(1, len(item.content) // 4) if item.content else 0
            freshness = "stale" if item.stale else "current"
            source_taxonomy = project_source_taxonomy(item.path, doc_scope=item.doc_scope, module_path=item.module_path)
            # Literal artifact-path exclusions precede caller attribution labels.
            # Metadata risk/authority claims must not classify quoted content.
            if _should_skip_low_trust_project_source(question, source_taxonomy):
                continue
            if item.authority:
                source_taxonomy["authority"] = item.authority
            elif item.metadata.get("project_doc_authority") or item.metadata.get("authority"):
                source_taxonomy["authority"] = item.metadata.get("project_doc_authority") or item.metadata["authority"]
            pack.append({
                "stable_chunk_id": item.stable_chunk_id,
                "parent_logical_id": item.parent_logical_id,
                "display_content_hash": item.display_content_hash,
                "_source_snapshot_sha256": item.content_hash,
                # Preserve the committed child identity independently of the
                # retrieval DTO's project_doc class and display-window hash.
                **{key: item.metadata[key] for key in (
                    "_reference_evidence", "_reference_root_plan", "_reference_plans", "_evidence_sets",
                    "generation_id", "resolved_version", "source_identity", "source_content_hash",
                ) if key in item.metadata},
                **({
                    "byte_start": item.metadata["byte_span"][0],
                    "byte_end": item.metadata["byte_span"][1],
                } if isinstance(item.metadata.get("byte_span"), (list, tuple))
                    and len(item.metadata["byte_span"]) == 2
                    and all(type(value) is int for value in item.metadata["byte_span"])
                    and 0 <= item.metadata["byte_span"][0] <= item.metadata["byte_span"][1] else {}),
                "_source_catalog_hash": item.metadata.get("project_doc_catalog_entry_hash"),
                **({
                    "char_start": item.char_start,
                    "char_end": item.char_end,
                } if item.char_start is not None and item.char_end is not None else {}),
                **({
                    "line_start": item.line_start,
                    "line_end": item.line_end,
                } if item.line_start is not None and item.line_end is not None else {}),
                "source_class": "project_doc",
                "source_type": source_taxonomy["source_type"],
                "source_kind": source_taxonomy["source_kind"],
                "authority": source_taxonomy["authority"],
                "risk_flags": source_taxonomy["risk_flags"],
                "doc_scope": item.doc_scope,
                "module_id": item.module_id,
                "module_name": item.module_name,
                "module_path": item.module_path,
                "module_type": item.module_type,
                "description": item.description,
                "catalog_role": item.metadata.get("project_doc_reason"),
                "lifecycle_status": item.lifecycle_status or "active",
                "temporal_relevance": temporal_relevance_for_status(item.lifecycle_status),
                "index_freshness": "stale" if item.stale else "synchronized",
                "impact_policy": item.impact_policy,
                "project_identity": item.project_identity,
                "retrieval_query_ids": list(item.metadata.get("retrieval_query_ids") or ()),
                "retrieval_query_matches": dict(item.metadata.get("retrieval_query_matches") or {}),
                "project_ranking": dict(item.metadata.get("project_ranking") or {}),
                "path": item.path,
                "url": item.url,
                "title": item.title,
                "heading_path": item.heading_path,
                "freshness": freshness,
                "why_selected": project_why_selected(item),
                "content": item.content,
                "display_text": item.content,
                "token_estimate": token_estimate,
                "source": {
                    "source_class": "project_doc",
                    "source_type": source_taxonomy["source_type"],
                    "source_kind": source_taxonomy["source_kind"],
                    "authority": source_taxonomy["authority"],
                    "risk_flags": source_taxonomy["risk_flags"],
                    "doc_scope": item.doc_scope,
                    "module_id": item.module_id,
                    "module_name": item.module_name,
                    "module_path": item.module_path,
                    "module_type": item.module_type,
                    "description": item.description,
                    "lifecycle_status": item.lifecycle_status or "active",
                    "temporal_relevance": temporal_relevance_for_status(item.lifecycle_status),
                    "index_freshness": "stale" if item.stale else "synchronized",
                    "impact_policy": item.impact_policy,
                    "project_identity": item.project_identity,
                    "path": item.path,
                    "url": item.url,
                    "title": item.title,
                },
                "section": {
                    "title": item.title,
                    "heading_path": item.heading_path,
                    "freshness": freshness,
                },
            })
            snippet = context_pack_snippet(item)
            if snippet:
                pack[-1]["snippet"] = snippet
                pack[-1]["surrounding_context"] = item.content
    if dependency_docs:
        for item in dependency_docs.results:
            if _drop_low_value_context_section(item.content, item.title, getattr(item, "heading_path", None)):
                continue
            token_estimate = max(1, len(item.content) // 4) if item.content else 0
            freshness = "stale" if dependency_docs.stale_before_refresh else "current"
            pack.append({
                "source_class": "dependency_doc",
                "dependency": dependency_docs.library,
                "requested_version": dependency_docs.requested_version,
                "resolved_version": dependency_docs.resolved_version or dependency_docs.version,
                "version_source": dependency_docs.version_source,
                "docs_exactness": dependency_docs.docs_exactness,
                "docs_binding_source": dependency_docs.docs_binding_source,
                "confidence": dependency_docs.confidence,
                "url": item.url,
                "source_url": item.source,
                "title": item.title,
                "freshness": freshness,
                "why_selected": "dependency docs resolved through Docmancer registry/project metadata",
                "content": item.content,
                "token_estimate": token_estimate,
                "source": {
                    "source_class": "dependency_doc",
                    "library": dependency_docs.library,
                    "requested_version": dependency_docs.requested_version,
                    "version": dependency_docs.resolved_version or dependency_docs.version,
                    "url": item.url,
                    "source_url": item.source,
                    "title": item.title,
                },
                "section": {
                    "title": item.title,
                    "heading_path": getattr(item, "heading_path", None),
                    "freshness": freshness,
                },
            })
            snippet = context_pack_snippet(item)
            if snippet:
                pack[-1]["snippet"] = snippet
                pack[-1]["surrounding_context"] = item.content
    return pack


def _library_next_action(dependency_docs: DocsResult, action: Any) -> dict[str, Any]:
    if isinstance(action, dict):
        return action
    return {"tool": dependency_docs.tool, "reason": action}


def _project_docs_preflight_confirmation_result(*, root: Path, question: str, mode: str, project_docs: ProjectDocsResult) -> ProjectContextResult:
    answer_completeness = {
        "schema_version": "answer-completeness-1.0",
        "status": "unavailable",
        "answer_type": "unavailable",
        "coverage_score": 0.0,
        "matched_terms": [],
        "missing_terms": [],
        "coverage_by_requirement": [],
        "source_search_required": False,
        "reason_codes": ["project_docs_preflight_confirmation_required"],
    }
    return ProjectContextResult(
        project_path=str(root),
        question=question,
        status=project_docs.status if project_docs.status in {"stale", "confirmation_required"} else "confirmation_required",
        answer_available=False,
        answer_type="unavailable",
        answer_completeness=answer_completeness,
        mode=mode,
        reason="project_docs_preflight_confirmation_required",
        context_pack=[],
        project_docs=project_docs,
        dependency_docs=None,
        trust_contract={
            "sources": {"selected": [], "rejected": [], "risky": []},
            "policy": {"direct_webfetch": "forbidden", "reason_code": "project_docs_preflight_confirmation_required"},
        },
        warnings=project_docs.warnings,
        next_actions=project_docs.next_actions,
        recommended_next_actions=project_docs.next_actions,
        next_action=project_docs.next_action,
        requires_confirmation=True,
        confirmation_reason=project_docs.confirmation_reason,
        arguments_patch=project_docs.arguments_patch,
        metrics={"answer_completeness": answer_completeness},
        diagnostics={"preflight": project_docs.diagnostics.get("preflight") if isinstance(project_docs.diagnostics, dict) else project_docs.diagnostics},
        answer_outline={"answer_completeness": answer_completeness},
        message=project_docs.message or "Project docs preflight requires confirmation before returning trusted project context.",
    )


def _drop_placeholder_context_doc(item: ProjectDocsChunk) -> bool:
    metadata = getattr(item, "metadata", None) or {}
    return (metadata.get("placeholder") is True
            or _looks_like_placeholder_context_doc(getattr(item, "path", None), getattr(item, "content", None)))


def _looks_like_placeholder_context_doc(path: str | None, content: str | None) -> bool:
    return not str(content or "").strip()


def _should_skip_low_trust_project_source(question: str, source_taxonomy: dict[str, Any]) -> bool:
    risk_flags = set(source_taxonomy.get("risk_flags") or [])
    return bool(risk_flags.intersection(LOW_TRUST_PROJECT_RISK_FLAGS)
                or source_taxonomy.get("authority") in {"artifact", "research", "generated", "stale"})


def _question_explicitly_targets_low_trust_artifacts(question: str) -> bool:
    # Request wording cannot lift catalog/source trust restrictions.
    return False


def _query_relevance_gate(
    *,
    question: str,
    intent: Any,
    context_pack: list[dict[str, Any]],
    relevance_terms: list[str] | None = None,
) -> dict[str, Any]:
    # Compatibility diagnostics only. Token overlap cannot grant relevance or
    # answer authority, including callers outside the MCP read scope.
    return {
        "passed": False, "reason": "relevance_unassessed",
        "required_terms": [], "matched_terms": [], "missing_terms": [],
        "matched_details": [], "weighted_score": None,
        "matched_term_count": 0, "required_term_count": 0,
    }


def _make_context_trust_decision(
    *,
    question: str,
    context_pack: list[dict[str, Any]],
    project_docs: ProjectDocsResult | None,
    dependency_docs: DocsResult | None,
    source_evidence_items: list[dict[str, Any]],
    relevance_gate: dict[str, Any],
    answer_available: bool,
    answer_type: str,
    intent: Any,
    support_decision: Any | None = None,
) -> ContextTrustDecision:
    return ContextTrustDecision(
        False, "partial_navigational_context" if context_pack else "no_reliable_context",
        "partial" if context_pack else "low", False, None, [], [],
    )


def _max_project_ranking_score(project_docs: ProjectDocsResult | None) -> float | None:
    scores: list[float] = []
    for chunk in project_docs.results if project_docs else []:
        metadata = getattr(chunk, "metadata", None) or {}
        ranking = metadata.get("project_ranking") if isinstance(metadata, dict) else None
        value = ranking.get("final_score") if isinstance(ranking, dict) else None
        if isinstance(value, (int, float)):
            scores.append(float(value))
    if scores:
        return max(scores)
    return 1.0 if project_docs and project_docs.results else None


STRONG_PROJECT_SCORE_THRESHOLD = 0.35


def _score_is_strong(score: float | None) -> bool:
    return score is not None and score >= STRONG_PROJECT_SCORE_THRESHOLD


def _is_low_signal_single_token_query(question: str) -> bool:
    return not bool(str(question or "").strip())


def _context_has_query_evidence(context_pack: list[dict[str, Any]], terms: list[str] | None) -> bool:
    if not terms:
        return True
    return bool(_matched_query_terms(context_pack, terms))


def _matched_query_terms(context_pack: list[dict[str, Any]], terms: list[str]) -> list[str]:
    matched: list[str] = []
    normalized_items = [_normalize_gate_text(_context_item_text_for_gate(item)) for item in context_pack]
    for term in terms:
        normalized_term = _normalize_gate_text(term)
        if normalized_term and any(normalized_term in text for text in normalized_items):
            if term not in matched:
                matched.append(term)
    return matched


def _context_item_text_for_gate(item: dict[str, Any]) -> str:
    source = item.get("source") if isinstance(item.get("source"), dict) else {}
    section = item.get("section") if isinstance(item.get("section"), dict) else {}
    parts = [
        item.get("path"),
        item.get("title"),
        item.get("heading_path"),
        item.get("content"),
        item.get("snippet"),
        source.get("path"),
        source.get("title"),
        section.get("title"),
    ]
    return "\n".join(str(part) for part in parts if part)


def _normalize_gate_text(value: Any) -> str:
    if isinstance(value, dict):
        parts = [
            value.get("code"),
            value.get("text"),
            value.get("content"),
            value.get("title"),
            value.get("why_relevant"),
        ]
        value = "\n".join(str(part) for part in parts if part)
    elif isinstance(value, list):
        value = "\n".join(str(part) for part in value if part)
    text = str(value or "").replace("\\", "/").lower()
    return re.sub(r"\s+", " ", text)


def _repo_map_token_budget(tokens: int | None) -> int:
    if not tokens:
        return 900
    return max(120, min(900, tokens // 4))


def _source_evidence_token_budget(tokens: int | None) -> int:
    if not tokens:
        return 700
    return max(120, min(700, tokens // 5))


def _code_graph_build_token_budget(tokens: int | None) -> int:
    if not tokens:
        return 3000
    return max(1200, min(5000, int(tokens * 0.35)))


def _code_graph_context_token_budget(tokens: int | None) -> int:
    if not tokens:
        return 900
    return max(400, min(1400, int(tokens * 0.12)))


def _compact_code_graph_diagnostics(diagnostics: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "node_count",
        "edge_count",
        "selected_files",
        "selected_paths",
        "edge_kinds",
        "confidence_summary",
        "unresolved_import_count",
        "unresolved_reference_count",
        "graph_scope",
        "limitations",
    )
    return {key: diagnostics[key] for key in keys if key in diagnostics}


def _drop_low_value_context_section(content: str, title: str | None = None, heading_path: str | None = None) -> bool:
    if not is_trivial_section(content, title, heading_path):
        return False
    text = (content or "").strip()
    lowered = text.lower()
    title_lower = (title or "").strip().lower()
    return (
        not text
        or lowered == title_lower
        or bool(re.fullmatch(r"\d+(?:\.\d+){1,3}(?:\s+-\s+\d{4}-\d{2}-\d{2})?", text))
    )


def context_pack_snippet(item: DocsChunk) -> dict[str, Any] | None:
    return best_context_pack_snippet(item)


def project_why_selected(item: Any) -> str:
    path = normalize_doc_path(getattr(item, "path", None))
    metadata = getattr(item, "metadata", None) or {}
    ranking = metadata.get("project_ranking") if isinstance(metadata, dict) else None
    ranking_reasons = ranking.get("reasons") if isinstance(ranking, dict) else None
    if ranking_reasons:
        base_reason = _project_source_kind_reason(path)
        reasons = [str(reason) for reason in ranking_reasons if reason]
        return "; ".join([base_reason, *reasons])

    return _project_source_kind_reason(path)


def _project_source_kind_reason(path: str) -> str:
    return "selected because it matched repo-owned project documentation for the question"


def project_context_metrics(
    *,
    context_pack: list[dict[str, Any]],
    project_docs: ProjectDocsResult | None,
    dependency_docs: DocsResult | None,
    intent: Any | None = None,
) -> dict[str, Any]:
    source_classes = [item.get("source_class") for item in context_pack]
    paths = [normalize_doc_path(item.get("path") or ((item.get("source") or {}).get("path") if isinstance(item.get("source"), dict) else None)) for item in context_pack]
    path_counts: dict[str, int] = {}
    for path in paths:
        if path:
            path_counts[path] = path_counts.get(path, 0) + 1
    changelog_count = sum(1 for path in paths if is_changelog_path(path))
    project_result_count = len(project_docs.results) if project_docs else 0
    dependency_result_count = len(dependency_docs.results) if dependency_docs else 0
    raw_result_count = project_result_count + dependency_result_count
    raw_results = [*(project_docs.results if project_docs else []), *(dependency_docs.results if dependency_docs else [])]
    context_tokens = sum(int(item.get("token_estimate") or 0) for item in context_pack)
    raw_docs_tokens = sum(int(((item.metadata or {}).get("raw_tokens") or 0)) for item in (project_docs.results if project_docs else []))
    max_items_from_single_source = max(path_counts.values(), default=0)
    quality_warnings = []
    if intent and not getattr(intent, "wants_release_history", False) and changelog_count:
        quality_warnings.append({
            "code": "changelog_in_non_release_context",
            "message": "CHANGELOG.md appeared in context for a non-release query.",
        })
    if intent and getattr(intent, "broad", False) and max_items_from_single_source > 2:
        quality_warnings.append({
            "code": "low_source_diversity",
            "message": "Broad query returned too many chunks from one source.",
        })
    return {
        "context_pack_items": len(context_pack),
        "selected_source_count": len(context_pack),
        "project_result_count": project_result_count,
        "dependency_result_count": dependency_result_count,
        "token_estimate": context_tokens,
        "source_classes": sorted({str(item) for item in source_classes if item}),
        "quality": {
            "query_intent": getattr(intent, "name", None),
            "changelog_items": changelog_count,
            "changelog_ratio": changelog_count / len(context_pack) if context_pack else 0.0,
            "unique_source_count": len(path_counts),
            "max_items_from_single_source": max_items_from_single_source,
            "has_readme": any(path.endswith("readme.md") for path in paths),
            "has_architecture": any("architecture" in path for path in paths),
            "has_contributing": any(path.endswith("contributing.md") for path in paths),
            "has_docs_mcp_source": any("mcp-docs" in path or "docs-server" in path for path in paths),
            "has_packs_mcp_source": any("mcp-packs" in path for path in paths),
            "relevance_coverage": len(context_pack) / max(1, raw_result_count),
            "trivial_sections_filtered": max(0, raw_result_count - len(context_pack)),
            "noise_sections_demoted": sum(1 for item in raw_results if internal_noise_score(getattr(item, "content", "")) >= 0.5),
            "warnings": quality_warnings,
        },
        "token_savings": _token_savings_metrics(raw_docs_tokens, context_tokens),
    }


def _token_savings_metrics(raw_docs_tokens: int, context_pack_tokens: int) -> dict[str, Any]:
    raw = max(0, int(raw_docs_tokens or 0))
    pack = max(0, int(context_pack_tokens or 0))
    if raw == 0:
        return {
            "raw_docs_tokens": raw,
            "context_pack_tokens": pack,
            "savings_percent": None,
            "used_percent": None,
            "agentic_runway_multiplier": None,
            "meaning": "compression_vs_raw_docs_not_relevance_score",
        }
    return {
        "raw_docs_tokens": raw,
        "context_pack_tokens": pack,
        "savings_percent": round(max(0, raw - pack) / raw * 100, 1),
        "used_percent": round(pack / raw * 100, 1),
        "agentic_runway_multiplier": round(raw / pack, 2) if pack else None,
        "meaning": "compression_vs_raw_docs_not_relevance_score",
    }
from docmancer.retrieval.query_planning import extract_document_locator

__all__ = [name for name in globals() if not name.startswith('__')]
