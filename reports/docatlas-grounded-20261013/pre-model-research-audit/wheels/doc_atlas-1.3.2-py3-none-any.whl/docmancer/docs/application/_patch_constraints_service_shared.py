from __future__ import annotations

import json
import fnmatch
import hashlib
import re
import tomllib
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from docmancer.docs.domain.code_graph import build_code_graph_context_items, build_project_code_graph
from docmancer.docs.domain.source_map import build_project_repo_map, build_project_source_evidence
from docmancer.docs.models import DependencyObservation, PatchConstraint, PatchConstraintPacket

DEFAULT_MAX_CONSTRAINTS = 12
DEFAULT_MAX_TOKENS = 1200
LOCKFILES = {
    "pubspec.lock",
    "poetry.lock",
    "uv.lock",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "Cargo.lock",
    "go.sum",
}
MANIFESTS = {"pubspec.yaml", "pyproject.toml", "requirements.txt", "package.json", "Cargo.toml", "go.mod"}
DEPENDENCY_FILES = LOCKFILES | MANIFESTS
GENERATED_PATTERNS = (
    "*.g.dart",
    "*.freezed.dart",
    "*.pb.go",
    "*.pb.dart",
    "*.generated.*",
    "GeneratedPluginRegistrant.*",
    "generated/",
    "dist/",
)
GENERATED_ARTIFACT_SOURCE_PATTERNS = (
    "eval/task_level/results/**",
    ".docatlas/**",
)
PATCH_REVIEW_DIR_NAMES = {"patch-review", "patch_review"}
PATCH_REVIEW_ARTIFACT_NAMES = {
    "review_summary.md",
    "constraints.md",
    "constraints.json",
    "validation.json",
    "changed_files.json",
    "patch.diff",
    "patch.raw.diff",
    "git_status.txt",
    "git_status.raw.txt",
    "changed_files.raw.json",
    "patch_hygiene.json",
    "untracked_files.json",
    "ignored_runtime_artifacts.json",
    "review_notes.md",
    "checks.txt",
}
DOGFOOD_TASK_ARTIFACT_NAMES = {"task.md", "review_notes.md"}
ASSET_REGISTRY_FILENAMES = {"assets.dart", "asset.dart", "assets.gen.dart", "assets.g.dart"}
SYMBOL_SOURCE_SUFFIXES = (".py", ".dart", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".kt", ".java", ".md", ".txt")
TREE_GLYPH_RE = re.compile(r"[│├└┬┴┼─]{2,}|^[│├└┬┴┼─]")
EXCLUDED_SOURCE_PARTS = {
    "eval",
    "fixtures",
    "results",
    "runtime",
    "workspaces",
    "hidden_tests",
    "oracles",
    ".cache",
    ".dart_tool",
    ".pytest_cache",
    ".uv",
    "uv-cache",
    "archive-v0",
    "materialized",
    "node_modules",
    "build",
    ".venv",
    "venv",
    ".git",
    "__pycache__",
}

__all__ = [name for name in globals() if not name.startswith('__')]
