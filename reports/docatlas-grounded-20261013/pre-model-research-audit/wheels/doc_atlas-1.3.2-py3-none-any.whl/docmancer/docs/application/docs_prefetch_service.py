from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Protocol
import json
import shutil
import threading
import time
from urllib.parse import urlparse

import httpx
import yaml

from docmancer.core.config import DocmancerConfig
from docmancer.docs.domain.policies import docs_policy, is_stale
from docmancer.docs.curated_sources import canonical_source_identity
from docmancer.docs.application.library_refresh_policy import metadata_for_record
from docmancer.docs.domain.project_state import create_project_docs_next_action, has_high_level_project_overview, partition_project_doc_state, project_docs_structured_next_action
from docmancer.docs.domain.source_identity import docs_exactness, docs_identity, docs_request
from docmancer.docs.domain.target_security import host_allowed, is_remote_url, path_allowed, url_security_error
from docmancer.docs.domain.trust_contract import build_project_context_trust_contract
from docmancer.docs.github_source_manifest import normalize_resolved_github_manifest
from docmancer.docs.finite_membership import preflight_target_urls, selected_robots, validate_target_collections
from docmancer.docs.models import DocsChunk, DocsInspectResult, DocsJobStartResult, DocsManifestValidationResult, DocsPruneResult, DocsRemoveResult, DocsResult, DocsSourceResolution, DocsTarget, DocsTargetResult, DocsTargetsPrefetchResult, LibraryInfo, ProjectDocsBootstrapResult, ProjectDocsChunk, ProjectDocsIngestResult, ProjectDocsInspectResult, ProjectDocsResult, ProjectMetadata, ProjectPrefetchResult, RefreshResult
from docmancer.docs.registry import LibraryRecord
from docmancer.docs.resolver import canonical_library_id, normalize_library_name, normalize_version
from docmancer.docs.dartdoc import discover_pub_dartdoc_seed_urls, is_pub_dartdoc_target, normalize_pub_dartdoc_target, pub_dartdoc_root_url

STALE_AFTER_DAYS = 30
DEFAULT_DOC_TOKENS = 4000
PUB_DOCS_URL_TEMPLATE = "https://pub.dev/documentation/{library}/{version}/"
NO_PROJECT_VERSION_WARNING = "No version was found in project metadata; using latest/default docs."
PACKAGE_NOT_FOUND_WARNING = "Package was not found in pubspec.lock."
FLUTTER_CHANNEL_DOCS_WARNING = (
    "Flutter project version {version} was detected, but api.flutter.dev provides current stable API docs, "
    "not an exact archived snapshot."
)


class DocsPrefetchDependencies(Protocol):
    jobs: Any
    registry: Any

    def _target_from_dict(self, value: dict[str, Any] | DocsTarget) -> DocsTarget: ...
    def _discover_pub_dartdoc_target(self, target: DocsTarget, warnings: list[str], job_id: str | None = None, canonical_id: str | None = None) -> DocsTarget: ...
    def _resolve_github_directory_target(self, target: DocsTarget) -> DocsTarget: ...
    def _refresh_record_unlocked(self, record: Any, *, force: bool, lock_held: bool = False) -> Any: ...
    def _target_urls(self, target: DocsTarget) -> tuple[list[str], str | None]: ...
    def _target_to_spec(self, target: DocsTarget, urls: list[str] | None = None) -> dict[str, Any]: ...
    def _target_result_summary(self, result: DocsTargetResult) -> dict[str, Any]: ...
    def _now(self) -> str: ...
    def _is_stale(self, last_refreshed_at: str | None) -> bool: ...
    def _lock_for(self, library_id: str) -> Any: ...
    def _agent_instance(self, record: LibraryRecord | None = None) -> Any: ...


class DocsPrefetchService:
    def __init__(self, deps: DocsPrefetchDependencies):
        self.deps = deps
        self.jobs = deps.jobs
        self.registry = deps.registry

    def progress_callback_for(self, job_id: str | None, canonical_id: str):
        if not job_id:
            return None

        def _callback(event: dict[str, Any]) -> None:
            phase = event.get("phase") or "fetching"
            url = event.get("url") or event.get("current_url")
            changes: dict[str, Any] = {
                "phase": phase,
                "current_target": canonical_id,
                "message": event.get("message") or phase,
            }
            if url:
                changes["current_url"] = str(url)
            current = self.jobs.get(job_id)
            if event.get("total_pages") is not None:
                changes["total_pages"] = max(int(event["total_pages"]), current.total_pages if current else 0)
            if event.get("discovered_pages") is not None:
                changes["discovered_pages"] = int(event["discovered_pages"])
            if event.get("fetched_pages") is not None:
                changes["fetched_pages"] = int(event["fetched_pages"])
                changes["completed_pages"] = int(event["fetched_pages"])
            if event.get("indexed_pages") is not None:
                changes["indexed_pages"] = int(event["indexed_pages"])
            if event.get("failed_pages") is not None and current:
                changes["failed_pages"] = current.failed_pages + int(event["failed_pages"])
            self.jobs.update(job_id, **changes)
            self.jobs.append_event(job_id, event)

        return _callback

    def _job_cancelled(self, job_id: str | None) -> bool:
        if not job_id:
            return False
        current = self.jobs.get(job_id)
        return self.jobs.cancellation_requested(job_id) or bool(
            current and current.status in {"failed", "cancelled", "interrupted"}
        )

    def prefetch_docs_targets(
        self,
        targets: list[dict[str, Any] | DocsTarget],
        *,
        force_refresh: bool = False,
        continue_on_error: bool = True,
        async_: bool = False,
    ) -> DocsTargetsPrefetchResult | DocsJobStartResult:
        targets = deepcopy(targets)
        if async_:
            job = self.jobs.create("prefetch_docs_targets")
            self.jobs.update(job.job_id, status="running", message="Started docs prefetch job.")
            threading.Thread(
                target=self._run_prefetch_docs_targets_job,
                args=(job.job_id, targets, force_refresh, continue_on_error),
                daemon=True,
            ).start()
            return DocsJobStartResult(job_id=job.job_id, status="running", message="Started docs prefetch job.")
        return self.prefetch_docs_targets_sync(
            targets,
            force_refresh=force_refresh,
            continue_on_error=continue_on_error,
        )

    def _run_prefetch_docs_targets_job(
        self,
        job_id: str,
        targets: list[dict[str, Any] | DocsTarget],
        force_refresh: bool,
        continue_on_error: bool,
    ) -> None:
        try:
            self.prefetch_docs_targets_sync(
                targets,
                force_refresh=force_refresh,
                continue_on_error=continue_on_error,
                job_id=job_id,
            )
        except Exception as exc:
            self.jobs.append_error(job_id, str(exc))
            self.jobs.update(job_id, status="failed", phase="done", message=str(exc))

    def prefetch_docs_targets_sync(
        self,
        targets: list[dict[str, Any] | DocsTarget],
        *,
        force_refresh: bool = False,
        continue_on_error: bool = True,
        job_id: str | None = None,
        deadline_at: float | None = None,
    ) -> DocsTargetsPrefetchResult:
        started = time.monotonic()
        results: list[DocsTargetResult] = []
        target_summaries: list[dict[str, Any]] = []
        seen: set[str] = set()
        warnings: list[str] = []
        aborted = False
        pages_indexed_total = 0
        chunks_indexed_total = 0
        pages_failed_total = 0
        targets_completed = 0
        targets_failed = 0
        raw_targets = deepcopy(list(targets))
        if job_id:
            self.jobs.update(
                job_id,
                status="running",
                phase="resolving",
                total_targets=len(raw_targets),
                message=f"Resolving {len(raw_targets)} docs targets.",
            )

        for index, raw_target in enumerate(raw_targets, start=1):
            if self._job_cancelled(job_id):
                aborted = True
                if job_id:
                    self.jobs.append_warning(job_id, "Docs prefetch job cancelled before the next target started.")
                    self.jobs.update(job_id, status="cancelled", phase="done", message="Docs prefetch job cancelled.")
                break
            target = self.deps._target_from_dict(raw_target)
            version = normalize_version(target.version) or "latest"
            source_type = target.source_type or "api"
            canonical_id = canonical_library_id(target.library, target.ecosystem, version, source_type)
            if job_id:
                self.jobs.update(
                    job_id,
                    phase="resolving",
                    current_target=canonical_id,
                    message=f"Resolving target {index}/{len(raw_targets)}.",
                )
                self.jobs.append_event(job_id, {"phase": "resolving", "message": f"Target {index}/{len(raw_targets)} started", "target": canonical_id})

            if canonical_id in seen:
                targets_failed += 1
                result = DocsTargetResult(
                    canonical_id=canonical_id,
                    status="failed",
                    library=target.library,
                    ecosystem=target.ecosystem,
                    version=version,
                    source_type=source_type,
                    warnings=list(target.warnings),
                    message="duplicate canonical target id",
                )
                results.append(result)
                target_summaries.append(self.deps._target_result_summary(result))
                if job_id:
                    self.jobs.append_error(job_id, f"{canonical_id}: duplicate canonical target id")
                    self.jobs.update(job_id, failed_targets=targets_failed, message="duplicate canonical target id")
                if not continue_on_error:
                    aborted = True
                    break
                continue
            seen.add(canonical_id)

            try:
                if isinstance(raw_target, dict):
                    validate_target_collections(raw_target)
                if not (target.docs_url or target.docs_url_template or target.seed_urls or target.source_manifest.get("documents")):
                    raise ValueError("explicit_members_required")
                if target.source_manifest and "documents" not in target.source_manifest:
                    raise ValueError("resolved_github_manifest_required")
                urls, error = self.deps._target_urls(target)
                if not error:
                    urls = list(preflight_target_urls(
                        urls, max_pages=target.max_pages,
                        allowed_domains=target.allowed_domains, path_prefixes=target.path_prefixes,
                        source_manifest=(normalize_resolved_github_manifest(target.source_manifest) if target.source_manifest else None),
                        cancellation_callback=lambda: self._job_cancelled(job_id), deadline_at=deadline_at,
                    ))
            except Exception as exc:
                urls, error = [], str(exc)
            if self._job_cancelled(job_id):
                aborted = True
                if job_id:
                    self.jobs.append_warning(job_id, "Docs prefetch job cancelled during target discovery.")
                    self.jobs.update(job_id, status="cancelled", phase="done", message="Docs prefetch job cancelled.")
                break
            if error:
                targets_failed += 1
                result = DocsTargetResult(
                    canonical_id=canonical_id,
                    status="failed",
                    library=target.library,
                    ecosystem=target.ecosystem,
                    version=version,
                    source_type=source_type,
                    warnings=list(target.warnings),
                    message=error,
                )
                results.append(result)
                target_summaries.append(self.deps._target_result_summary(result))
                if job_id:
                    self.jobs.append_error(job_id, f"{canonical_id}: {error}")
                    self.jobs.update(job_id, failed_targets=targets_failed, message=error)
                if not continue_on_error:
                    aborted = True
                    break
                continue

            target_spec = self.deps._target_to_spec(target, urls)
            existing = self.registry.get(target.library, target.ecosystem, version, source_type)
            previous_checkpoint = (
                ((existing.target_spec or {}).get("ingestion_checkpoint") or {})
                if existing is not None and not force_refresh else {}
            )
            completed_urls = [
                url for url in previous_checkpoint.get("completed_urls", [])
                if url in urls
            ]
            quarantined_urls = [
                url for url in previous_checkpoint.get("quarantined_urls", [])
                if url in urls and url not in completed_urls
            ]
            target_spec["ingestion_checkpoint"] = {
                "schema_version": 1,
                "resolved_urls": list(urls),
                "completed_urls": completed_urls,
                "pending_urls": [
                    url for url in urls
                    if url not in completed_urls and url not in quarantined_urls
                ],
                "failed_urls": {
                    url: reason
                    for url, reason in (previous_checkpoint.get("failed_urls") or {}).items()
                    if url in urls and url not in completed_urls
                },
                "attempts": int(previous_checkpoint.get("attempts") or 0),
                "attempts_by_url": dict(previous_checkpoint.get("attempts_by_url") or {}),
                "quarantined_urls": quarantined_urls,
                "max_attempts_per_url": 3,
            }
            manifest = target_spec.get("source_manifest") or {}
            if manifest.get("schema_version") == 2 and manifest.get("digest"):
                target_spec["last_attempt_manifest_digest"] = manifest["digest"]
                previous_spec = (existing.target_spec if existing else None) or {}
                previous_manifest = previous_spec.get("source_manifest") or {}
                if previous_manifest.get("schema_version") == 2:
                    target_spec["active_source_manifest"] = previous_manifest
                    target_spec["source_manifest"] = previous_manifest
                    target_spec["active_manifest_digest"] = previous_spec.get("active_manifest_digest") or previous_manifest.get("digest")
                    target_spec["last_complete_manifest_digest"] = previous_spec.get("last_complete_manifest_digest") or previous_manifest.get("digest")
            record = self.registry.upsert(
                library=target.library,
                ecosystem=target.ecosystem,
                version=version,
                source_type=source_type,
                docs_url=urls[0],
                docs_url_template=target.docs_url_template,
                now=self.deps._now(),
                status="available",
                target_spec=target_spec,
            )

            with self.deps._lock_for(record.library_id):
                if self._job_cancelled(job_id):
                    if existing is not None:
                        self.registry.restore(existing)
                    else:
                        self.registry.delete(record.library_id)
                    aborted = True
                    if job_id:
                        self.jobs.append_warning(job_id, "Docs prefetch job cancelled while waiting for the target lock.")
                        self.jobs.update(job_id, status="cancelled", phase="done", message="Docs prefetch job cancelled.")
                    break
                record = self.registry.get(record.library_id, source_type=record.source_type) or record
                checkpoint = (record.target_spec or {}).get("ingestion_checkpoint") or {}
                checkpoint_pending = list(checkpoint.get("pending_urls") or [])
                if (
                    not force_refresh
                    and not self.deps._is_stale(record.last_refreshed_at)
                    and record.status != "partial"
                    and not checkpoint_pending
                ):
                    targets_completed += 1
                    retained_partial = (record.last_error or "").startswith("partial ingestion:")
                    results.append(
                        result := DocsTargetResult(
                            canonical_id=record.library_id,
                            status="partial" if retained_partial else "skipped",
                            library=record.name,
                            ecosystem=record.ecosystem,
                            version=record.version,
                            source_type=record.source_type,
                            docs_url=record.docs_url,
                            warnings=list(target.warnings),
                            message=record.last_error if retained_partial else None,
                        )
                    )
                    target_summaries.append(self.deps._target_result_summary(result))
                    if job_id:
                        self.jobs.update(
                            job_id,
                            completed_targets=targets_completed,
                            phase="indexing",
                            message=f"Skipped fresh target {index}/{len(raw_targets)}.",
                        )
                    continue
                if record.status == "partial" and not checkpoint_pending and checkpoint.get("quarantined_urls"):
                    targets_completed += 1
                    results.append(
                        result := DocsTargetResult(
                            canonical_id=record.library_id,
                            status="partial",
                            library=record.name,
                            ecosystem=record.ecosystem,
                            version=record.version,
                            source_type=record.source_type,
                            docs_url=record.docs_url,
                            warnings=list(target.warnings),
                            message=record.last_error or "partial ingestion: checkpoint_quarantined",
                        )
                    )
                    target_summaries.append(self.deps._target_result_summary(result))
                    continue
                try:
                    pages_indexed = 0
                    chunks_indexed = 0
                    partial_reasons: list[str] = []
                    empty_seeds = 0
                    per_url_max_pages = target.max_pages if target.doc_format == "dartdoc" else (1 if target.seed_urls and not target.docs_url and not target.docs_url_template else target.max_pages)
                    if job_id:
                        self.jobs.update(
                            job_id,
                            phase="fetching",
                            total_pages=(self.jobs.get(job_id).total_pages if self.jobs.get(job_id) else 0) + len(urls),
                            message=f"Fetching target {index}/{len(raw_targets)}.",
                        )
                    progress_callback = self.progress_callback_for(job_id, record.library_id)
                    manifest = (
                        normalize_resolved_github_manifest(target.source_manifest)
                        if target.source_manifest.get("schema_version") == 2 else None
                    )
                    if manifest:
                        attempted_spec = self.deps._target_to_spec(target, urls)
                        attempted_spec["last_attempt_manifest_digest"] = manifest["digest"]
                        if record.target_spec and record.target_spec.get("active_source_manifest"):
                            attempted_spec["active_source_manifest"] = record.target_spec["active_source_manifest"]
                            attempted_spec["active_manifest_digest"] = record.target_spec.get("active_manifest_digest")
                            attempted_spec["last_complete_manifest_digest"] = record.target_spec.get("last_complete_manifest_digest")
                        record = replace(record, target_spec=attempted_spec)
                        refreshed = self.deps._refresh_record_unlocked(record, force=True, lock_held=True)
                        if refreshed.status not in {"updated", "ok"}:
                            raise RuntimeError(refreshed.message or "manifest refresh failed")
                        pages_indexed = refreshed.pages_indexed
                        chunks_indexed = refreshed.chunks_indexed
                        pages_indexed_total += refreshed.pages_indexed
                        chunks_indexed_total += refreshed.chunks_indexed
                        operation_urls: list[str] = []
                    else:
                        checkpoint = (record.target_spec or {}).get("ingestion_checkpoint") or {}
                        completed_checkpoint_urls = set(checkpoint.get("completed_urls") or [])
                        quarantined_checkpoint_urls = set(checkpoint.get("quarantined_urls") or [])
                        operation_urls = [
                            url for url in urls
                            if url not in completed_checkpoint_urls and url not in quarantined_checkpoint_urls
                        ]
                    for url_index, url in enumerate(operation_urls, start=1):
                        if self._job_cancelled(job_id):
                            aborted = True
                            raise KeyboardInterrupt("Docs prefetch job cancelled.")
                        add_kwargs: dict[str, Any] = {
                            "max_pages": per_url_max_pages,
                            "browser": target.browser,
                            "exact_urls": [url],
                            "allowed_domains": target.allowed_domains,
                            "path_prefixes": target.path_prefixes,
                            "robots_urls": selected_robots(urls),
                            "metadata": {
                                **metadata_for_record(record),
                                "canonical_source_identity": canonical_source_identity(url),
                                "canonical_id": record.canonical_id or record.library_id,
                            },
                        }
                        if target.discovery_strategy not in {None, "auto"}:
                            add_kwargs["strategy"] = target.discovery_strategy
                        if target.doc_format:
                            add_kwargs["doc_format"] = target.doc_format
                        if target.query:
                            add_kwargs["query"] = target.query
                        if manifest:
                            add_kwargs["source_manifest"] = manifest
                        if progress_callback:
                            add_kwargs["progress_callback"] = progress_callback
                            progress_callback({"phase": "fetching", "message": f"Fetching seed URL {url_index}/{len(urls)}", "url": url, "total_pages": len(urls)})
                        if job_id:
                            add_kwargs["cancellation_callback"] = lambda: self._job_cancelled(job_id)
                        if deadline_at is not None:
                            add_kwargs["deadline_at"] = deadline_at
                        agent = self.deps._agent_instance(record)
                        try:
                            agent.last_fetch_failure = None
                            agent.last_discovery_diagnostics = {}
                        except AttributeError:
                            pass
                        pages = agent.add(
                            url,
                            recreate=False,
                            **add_kwargs,
                        )
                        if self._job_cancelled(job_id):
                            aborted = True
                            raise KeyboardInterrupt("Docs prefetch job cancelled.")
                        fetch_failure = getattr(agent, "last_fetch_failure", None)
                        diagnostics = dict(getattr(agent, "last_discovery_diagnostics", {}) or {})
                        page_ledger = [page for page in diagnostics.get("page_ledger") or [] if isinstance(page, dict)]
                        usable_pages = sum(page.get("outcome") == "usable" for page in page_ledger)
                        page_failures = int(diagnostics.get("page_failure_count") or 0)
                        if not page_failures:
                            page_failures = sum(page.get("outcome") in {"failed", "skipped"} for page in page_ledger)
                        indexed_chunks = pages if isinstance(pages, int) else 0
                        indexed_pages = usable_pages if page_ledger else indexed_chunks
                        pages_indexed += indexed_pages
                        chunks_indexed += indexed_chunks
                        pages_indexed_total += indexed_pages
                        chunks_indexed_total += indexed_chunks
                        pages_failed_total += page_failures
                        if isinstance(pages, int) and pages <= 0:
                            empty_seeds += 1
                        reason_code = diagnostics.get("reason_code")
                        if fetch_failure is not None:
                            partial_reasons.append(str(getattr(fetch_failure, "category", None) or fetch_failure))
                        if diagnostics.get("complete") is False and reason_code:
                            partial_reasons.append(str(reason_code))
                        if page_failures:
                            partial_reasons.append("page_failures")
                        checkpoint = dict((record.target_spec or {}).get("ingestion_checkpoint") or {})
                        checkpoint_completed = list(checkpoint.get("completed_urls") or [])
                        checkpoint_failed = dict(checkpoint.get("failed_urls") or {})
                        attempts_by_url = dict(checkpoint.get("attempts_by_url") or {})
                        quarantined_urls = list(checkpoint.get("quarantined_urls") or [])
                        attempts_by_url[url] = int(attempts_by_url.get(url) or 0) + 1
                        page_complete = bool(
                            indexed_pages > 0
                            and fetch_failure is None
                            and page_failures == 0
                            and diagnostics.get("complete") is not False
                        )
                        if page_complete:
                            if url not in checkpoint_completed:
                                checkpoint_completed.append(url)
                            checkpoint_failed.pop(url, None)
                        else:
                            checkpoint_failed[url] = str(
                                reason_code
                                or getattr(fetch_failure, "category", None)
                                or "incomplete_page"
                            )
                            if attempts_by_url[url] >= int(checkpoint.get("max_attempts_per_url") or 3):
                                if url not in quarantined_urls:
                                    quarantined_urls.append(url)
                        checkpoint.update({
                            "schema_version": 1,
                            "resolved_urls": list(urls),
                            "completed_urls": checkpoint_completed,
                            "pending_urls": [
                                item for item in urls
                                if item not in checkpoint_completed and item not in quarantined_urls
                            ],
                            "failed_urls": checkpoint_failed,
                            "attempts": int(checkpoint.get("attempts") or 0) + 1,
                            "attempts_by_url": attempts_by_url,
                            "quarantined_urls": quarantined_urls,
                            "max_attempts_per_url": int(checkpoint.get("max_attempts_per_url") or 3),
                        })
                        updated_spec = dict(record.target_spec or {})
                        updated_spec["ingestion_checkpoint"] = checkpoint
                        record = self.registry.upsert(
                            library=record.name,
                            ecosystem=record.ecosystem,
                            version=record.version,
                            source_type=record.source_type,
                            docs_url=record.docs_url,
                            docs_url_template=record.docs_url_template,
                            now=self.deps._now(),
                            status="partial" if checkpoint["pending_urls"] else "available",
                            last_error=("partial ingestion: checkpoint_pending" if checkpoint["pending_urls"] else ""),
                            target_spec=updated_spec,
                        )
                        if job_id:
                            self.jobs.update(
                                job_id,
                                phase="indexing",
                                completed_pages=pages_indexed_total,
                                failed_pages=pages_failed_total,
                                completed_chunks=chunks_indexed_total,
                                total_chunks=max(self.jobs.get(job_id).total_chunks if self.jobs.get(job_id) else 0, chunks_indexed_total),
                                message=f"Indexed {url_index}/{len(urls)} seed URLs.",
                            )
                            self.jobs.append_event(job_id, {"phase": "indexing", "message": f"Indexed seed URL {url_index}/{len(urls)}", "url": url})
                    if pages_indexed <= 0:
                        raise RuntimeError("empty_index: target produced no indexable documentation")
                    if empty_seeds:
                        partial_reasons.append("empty_seed")
                except KeyboardInterrupt:
                    if existing is not None:
                        self.registry.restore(existing)
                    else:
                        self.registry.delete(record.library_id)
                    aborted = True
                    if job_id:
                        self.jobs.append_warning(job_id, "Docs prefetch job cancelled before the current target was marked ready.")
                        self.jobs.update(job_id, status="cancelled", phase="done", message="Docs prefetch job cancelled.")
                    break
                except Exception as exc:
                    record = self.registry.get(record.library_id, source_type=record.source_type) or record
                    if self._job_cancelled(job_id):
                        if existing is not None:
                            self.registry.restore(existing)
                        else:
                            self.registry.delete(record.library_id)
                        aborted = True
                        if job_id:
                            self.jobs.append_warning(job_id, "Docs prefetch job cancelled during the current target.")
                            self.jobs.update(job_id, status="cancelled", phase="done", message="Docs prefetch job cancelled.")
                        break
                    targets_failed += 1
                    pages_failed_total += 1
                    if existing is not None and existing.status == "available":
                        restored_spec = dict(existing.target_spec or {})
                        attempted_digest = (record.target_spec or {}).get("last_attempt_manifest_digest")
                        if attempted_digest:
                            restored_spec["last_attempt_manifest_digest"] = attempted_digest
                        attempted_diagnostics = (record.target_spec or {}).get("last_attempt_manifest_diagnostics")
                        if attempted_diagnostics:
                            restored_spec["last_attempt_manifest_diagnostics"] = attempted_diagnostics
                        self.registry.restore(replace(existing, target_spec=restored_spec))
                        record = self.registry.get(existing.library_id, source_type=existing.source_type) or existing
                    else:
                        self.registry.upsert(
                            library=record.name,
                            ecosystem=record.ecosystem,
                            version=record.version,
                            source_type=record.source_type,
                            docs_url=record.docs_url,
                            docs_url_template=record.docs_url_template,
                            now=self.deps._now(),
                            status="failed",
                            last_error=str(exc),
                            target_spec=record.target_spec,
                        )
                    results.append(
                        result := DocsTargetResult(
                            canonical_id=record.library_id,
                            status="failed",
                            library=record.name,
                            ecosystem=record.ecosystem,
                            version=record.version,
                            source_type=record.source_type,
                            docs_url=record.docs_url,
                            warnings=list(target.warnings),
                            message=str(exc),
                        )
                    )
                    target_summaries.append(self.deps._target_result_summary(result))
                    if job_id:
                        self.jobs.append_error(job_id, f"{record.library_id}: {exc}")
                        self.jobs.update(
                            job_id,
                            failed_targets=targets_failed,
                            failed_pages=pages_failed_total,
                            message=str(exc),
                        )
                    if not continue_on_error:
                        aborted = True
                        break
                    continue

                targets_completed += 1
                partial_message = None
                if partial_reasons:
                    partial_message = f"partial ingestion: {', '.join(dict.fromkeys(partial_reasons))}"
                final_checkpoint = (record.target_spec or {}).get("ingestion_checkpoint") or {}
                if final_checkpoint.get("pending_urls"):
                    pending_reason = "checkpoint_pending"
                    partial_message = (
                        f"{partial_message}, {pending_reason}"
                        if partial_message else f"partial ingestion: {pending_reason}"
                    )
                if final_checkpoint.get("quarantined_urls"):
                    quarantine_reason = "checkpoint_quarantined"
                    partial_message = (
                        f"{partial_message}, {quarantine_reason}"
                        if partial_message else f"partial ingestion: {quarantine_reason}"
                    )
                refreshed_at = self.deps._now()
                record = self.registry.get(record.library_id, source_type=record.source_type) or record
                record = self.registry.upsert(
                    library=record.name,
                    ecosystem=record.ecosystem,
                    version=record.version,
                    source_type=record.source_type,
                    docs_url=record.docs_url,
                    docs_url_template=record.docs_url_template,
                    now=refreshed_at,
                    status="partial" if partial_message else "available",
                    last_refreshed_at=refreshed_at,
                    last_error=partial_message or "",
                    target_spec=record.target_spec,
                )
                results.append(
                    result := DocsTargetResult(
                        canonical_id=record.library_id,
                        status="partial" if partial_message else "ready",
                        library=record.name,
                        ecosystem=record.ecosystem,
                        version=record.version,
                        source_type=record.source_type,
                        docs_url=record.docs_url,
                        pages_indexed=pages_indexed,
                        warnings=list(target.warnings),
                        message=partial_message,
                    )
                )
                target_summaries.append(self.deps._target_result_summary(result))
                if job_id:
                    self.jobs.update(
                        job_id,
                        completed_targets=targets_completed,
                        phase="indexing",
                        message=f"Indexed target {index}/{len(raw_targets)}.",
                    )
                    self.jobs.append_event(job_id, {"phase": "indexing", "message": f"Target {index}/{len(raw_targets)} finished", "target": record.library_id})

        failed = sum(1 for result in results if result.status == "failed")
        partial = any(result.status == "partial" for result in results)
        if aborted:
            status = "aborted"
        elif failed:
            status = "partial" if any(result.status in {"ready", "partial", "skipped"} for result in results) else "failed"
        elif partial:
            status = "partial"
        else:
            status = "ok"
        duration_ms = int((time.monotonic() - started) * 1000)
        if job_id and not self._job_cancelled(job_id):
            job_status = "succeeded" if status == "ok" else ("partial" if status in {"partial", "aborted"} else "failed")
            self.jobs.update(
                job_id,
                status=job_status,
                phase="done",
                completed_targets=targets_completed,
                failed_targets=targets_failed,
                completed_pages=pages_indexed_total,
                failed_pages=pages_failed_total,
                completed_chunks=chunks_indexed_total,
                total_chunks=max(self.jobs.get(job_id).total_chunks if self.jobs.get(job_id) else 0, chunks_indexed_total),
                target_results=target_summaries,
                message="Docs prefetch job finished.",
            )
        return DocsTargetsPrefetchResult(
            status=status,
            results=results,
            warnings=warnings,
            duration_ms=duration_ms,
                pages_indexed=pages_indexed_total,
                pages_failed=pages_failed_total,
                chunks_indexed=chunks_indexed_total,
            targets_completed=targets_completed,
            targets_failed=targets_failed,
        )
