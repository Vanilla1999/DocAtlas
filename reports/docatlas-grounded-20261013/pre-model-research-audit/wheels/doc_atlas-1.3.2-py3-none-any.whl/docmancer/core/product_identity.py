from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from docmancer._version import __version__

PRODUCT_ID = "dev.vanilla1999.docatlas"
PRODUCT_NAME = "DocAtlas"
PRODUCT_HOME_ENV = "DOCATLAS_HOME"
DEFAULT_HOME_NAME = ".docatlas"
PRIMARY_CONFIG_NAME = "docatlas.yaml"
STATE_OWNER_FILENAME = "state-owner.json"
STATE_SCHEMA_VERSION = 1


class StateOwnershipError(RuntimeError):
    """Raised when DocAtlas cannot prove ownership of a writable state root."""


@dataclass(frozen=True)
class HomeResolution:
    path: Path
    source: str


@dataclass(frozen=True)
class StateInspection:
    path: Path
    classification: str
    reasons: tuple[str, ...] = ()
    owner: dict[str, object] | None = None

    @property
    def is_safe_docatlas(self) -> bool:
        return self.classification in {"empty", "owned_docatlas"}


_FOREIGN_TOP_LEVEL = frozenset({
    "tree",
    "memory.db",
})
# Only product-specific managed MCP state is strong enough to auto-classify
# an unowned legacy root as DocAtlas. Generic names such as ``servers`` or
# ``secrets`` are intentionally not ownership evidence by themselves.


def _absolute(path: str | Path) -> Path:
    """Make a path absolute without dereferencing its final symlink."""

    return Path(os.path.abspath(str(Path(path).expanduser())))


def resolve_home(
    *,
    explicit_path: str | Path | None = None,
    env: Mapping[str, str] | None = None,
    home_dir: str | Path | None = None,
) -> HomeResolution:
    """Resolve the DocAtlas machine-state root without touching the filesystem.

    ``DOCATLAS_HOME`` is authoritative; old product identities are ignored.

    Resolution deliberately does not dereference the final path component.
    Ownership inspection must see a symlink root as a symlink and fail closed
    rather than normalizing it away before the safety check.
    """

    if explicit_path is not None:
        return HomeResolution(_absolute(explicit_path), "explicit")
    values = os.environ if env is None else env
    primary = str(values.get(PRODUCT_HOME_ENV) or "").strip()
    if primary:
        return HomeResolution(_absolute(primary), "docatlas_env")
    base = Path(home_dir).expanduser() if home_dir is not None else Path.home()
    return HomeResolution(_absolute(base / DEFAULT_HOME_NAME), "default")


def docatlas_home() -> Path:
    return resolve_home().path


def _owner_path(path: Path) -> Path:
    return path / STATE_OWNER_FILENAME


def _read_owner(path: Path) -> tuple[dict[str, object] | None, str | None]:
    marker = _owner_path(path)
    if marker.is_symlink():
        return None, "invalid ownership marker: marker is a symlink"
    if not marker.is_file():
        return None, None
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return None, f"invalid ownership marker: {exc.__class__.__name__}"
    if not isinstance(payload, dict):
        return None, "invalid ownership marker: not an object"
    return payload, None


def _signature_uses_symlink(root: Path, relative: Path) -> bool:
    """Reject evidence reached through a symlink before trusting its identity."""

    current = root
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            return True
        if not current.exists():
            return False
    return False


def inspect_state(path: str | Path) -> StateInspection:
    raw = _absolute(path)
    if raw.is_symlink():
        return StateInspection(raw, "ambiguous", ("state root is a symlink",))
    root = raw.resolve()
    if not root.exists():
        return StateInspection(root, "missing")
    if not root.is_dir():
        return StateInspection(root, "ambiguous", ("state root is not a plain directory",))

    owner, owner_error = _read_owner(root)
    if owner_error:
        return StateInspection(root, "ambiguous", (owner_error,))
    if owner is not None:
        if owner.get("product_id") == PRODUCT_ID:
            if owner.get("state_schema_version") != STATE_SCHEMA_VERSION:
                return StateInspection(
                    root,
                    "ambiguous",
                    ("unsupported DocAtlas state schema version",),
                    owner,
                )
            return StateInspection(root, "owned_docatlas", owner=owner)
        return StateInspection(root, "foreign", ("ownership marker belongs to another product",), owner)

    try:
        entries = tuple(root.iterdir())
    except OSError as exc:
        return StateInspection(root, "ambiguous", (f"cannot inspect state root: {exc.__class__.__name__}",))
    if not entries:
        return StateInspection(root, "empty")

    signature_paths = tuple(Path(name) for name in _FOREIGN_TOP_LEVEL)
    symlinked = sorted(
        relative.as_posix()
        for relative in signature_paths
        if _signature_uses_symlink(root, relative)
    )
    if symlinked:
        return StateInspection(
            root,
            "ambiguous",
            ("identity signature traverses symlink: " + ", ".join(symlinked),),
        )

    foreign = sorted(name for name in _FOREIGN_TOP_LEVEL if (root / name).exists())
    if foreign:
        return StateInspection(root, "foreign", (f"foreign signatures: {', '.join(foreign)}",))
    return StateInspection(
        root,
        "ambiguous",
        ("non-empty state has no DocAtlas ownership marker",),
    )


def ownership_payload() -> dict[str, object]:
    return {
        "product_id": PRODUCT_ID,
        "state_schema_version": STATE_SCHEMA_VERSION,
        "created_by_version": __version__,
    }


def ensure_owned_home(
    path: str | Path | None = None,
) -> Path:
    """Create/verify a DocAtlas-owned state root before a write.

    A non-empty directory is never claimed unless it is already DocAtlas-owned
    Foreign and ambiguous roots always fail closed.
    """

    raw = Path(path).expanduser() if path is not None else docatlas_home()
    inspection = inspect_state(raw)
    root = inspection.path
    if inspection.classification == "owned_docatlas":
        return root
    if inspection.classification in {"foreign", "ambiguous"}:
        raise StateOwnershipError(
            f"refusing to write unowned state root {root}: {inspection.classification}; "
            + "; ".join(inspection.reasons)
        )
    root.mkdir(parents=True, exist_ok=True)
    marker = _owner_path(root)
    if not marker.exists():
        try:
            with marker.open("x", encoding="utf-8") as handle:
                handle.write(json.dumps(ownership_payload(), indent=2, sort_keys=True) + "\n")
        except FileExistsError:
            pass
    final = inspect_state(root)
    if final.classification != "owned_docatlas":
        raise StateOwnershipError(f"failed to establish DocAtlas ownership for {root}")
    return root


__all__ = [
    "DEFAULT_HOME_NAME",
    "HomeResolution",
    "PRIMARY_CONFIG_NAME",
    "PRODUCT_HOME_ENV",
    "PRODUCT_ID",
    "PRODUCT_NAME",
    "STATE_OWNER_FILENAME",
    "STATE_SCHEMA_VERSION",
    "StateInspection",
    "StateOwnershipError",
    "docatlas_home",
    "ensure_owned_home",
    "inspect_state",
    "ownership_payload",
    "resolve_home",
]
