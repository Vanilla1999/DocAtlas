"""`doc-atlas mcp docs-serve`: stdio MCP server for library documentation."""
from __future__ import annotations

import asyncio
import copy
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, cast

import jsonschema
from docmancer.docs.application.action_packet import ACTION_PACKET_OUTPUT_SCHEMA

from docmancer.core.storage_topology import StorageTopologyResolver
from docmancer.docs.domain.project_path_validation import validate_project_path
from docmancer.docs.interfaces.mcp.error_contract import build_mcp_error_payload, debug_errors_enabled
from docmancer.docs.service import LibraryDocsService
from docmancer.docs.interfaces.mcp.context_tools import (
    BOUNDED_STRUCTURED_CONTENT_MARKER,
    context_tools,
    handle_context_tool,
)
from docmancer.docs.interfaces.mcp.docs_tools import handle_library_tool, library_tools
from docmancer.docs.interfaces.mcp.prefetch_tools import handle_prefetch_tool, prefetch_tools
from docmancer.docs.interfaces.mcp.project_tools import handle_project_tool, project_tools

ToolHandler = Callable[[str, dict[str, Any], LibraryDocsService], dict[str, Any] | None]


@dataclass(frozen=True)
class DocsServerConfig:
    expose_admin: bool = False
    expose_advanced: bool = False
    text_fallback: bool = False

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> "DocsServerConfig":
        return cls(
            expose_admin=env.get("DOCATLAS_MCP_ADMIN_TOOLS") == "1",
            expose_advanced=env.get("DOCATLAS_MCP_ADVANCED_TOOLS") == "1",
            text_fallback=env.get("DOCATLAS_MCP_TEXT_FALLBACK") == "1",
        )


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    input_schema: dict[str, Any]
    handler: ToolHandler
    output_schema: dict[str, Any] | None = None
    validation_schema: dict[str, Any] | None = None

    def to_tool_dict(self) -> dict[str, Any]:
        result = {"name": self.name, "description": self.description, "inputSchema": copy.deepcopy(self.input_schema)}
        if self.output_schema is not None:
            result["outputSchema"] = copy.deepcopy(self.output_schema)
        return result


@dataclass(frozen=True)
class DocsMcpSurface:
    tools: tuple[ToolSpec, ...]
    handlers: Mapping[str, ToolHandler]


DOCS_TARGET_INPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "library": {"type": "string", "minLength": 1},
        "ecosystem": {"type": ["string", "null"]},
        "version": {"type": ["string", "null"]},
        "source_type": {"type": ["string", "null"]},
        "docs_url": {"type": ["string", "null"]},
        "docs_url_template": {"type": ["string", "null"]},
        "seed_urls": {"type": ["array", "null"], "items": {"type": "string"}},
        "allowed_domains": {"type": ["array", "null"], "items": {"type": "string"}},
        "path_prefixes": {"type": ["array", "null"], "items": {"type": "string"}},
        "max_pages": {"type": ["integer", "null"], "minimum": 1, "maximum": 500},
        "browser": {"type": ["boolean", "null"]},
        "doc_format": {"type": ["string", "null"]},
        "warnings": {"type": ["array", "null"], "items": {"type": "string"}},
        "source_manifest": {"type": ["object", "null"]},
    },
    "required": ["library"],
    "additionalProperties": False,
}


_DOCS_CONTEXT_OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["status"],
    "properties": {
        "status": {"enum": ["ok", "truncated", "insufficient_evidence", "failed"]},
        "kind": {"enum": ["docs_answer", "docs_context"]},
        "estimated_tokens": {"type": "integer"},
        "context_quality": {
            "type": "object",
            "required": ["status", "reasons"],
            "properties": {
                "status": {"enum": ["checked", "partial", "unverified", "unavailable"]},
                "reasons": {
                    "type": "array", "maxItems": 2, "uniqueItems": True,
                    "items": {"enum": [
                        "coverage_unverified", "requested_part_missing", "budget_limited",
                        "source_unavailable", "source_changed", "structure_unverified",
                    ]},
                },
            },
            "additionalProperties": False,
        },
        "read_next": {
            "type": "array", "maxItems": 1,
            "items": {
                "type": "object",
                "required": [
                    "source_uri", "path", "project_identity", "snapshot_sha256",
                    "line_start", "line_end", "reason",
                ],
                "properties": {
                    "source_uri": {"type": "string", "pattern": "^docatlas://source/[0-9a-f]{24}$"},
                    "path": {"type": "string", "minLength": 1},
                    "project_identity": {"type": "string", "minLength": 1},
                    "snapshot_sha256": {"type": "string", "pattern": "^sha256:[0-9a-f]{64}$"},
                    "line_start": {"type": "integer", "minimum": 1},
                    "line_end": {"type": "integer", "minimum": 1},
                    "reason": {"type": "string", "pattern": "^[a-z0-9_]{1,64}$"},
                },
                "additionalProperties": False,
            },
        },
        "reason_code": {"type": "string"},
        "operational_reason_code": {"type": "string"},
        "documentation_supported": {"type": "boolean"},
        "investigation_allowed": {"type": "boolean"},
        "hard_stop": {"type": "boolean"},
        "recovery_origin": {"type": "string"},
        "recovery_reason_code": {"type": "string"},
        "recovery_disposition": {"type": "string"},
        "module_candidates": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["module_path"],
                "properties": {
                    "module_path": {"type": "string"},
                    "module_name": {"type": "string"},
                    "module_type": {"type": "string"},
                },
                "additionalProperties": False,
            },
        },
        "missing": {"type": "array", "items": {"type": "string"}},
        "recommended_next_action": {"type": "object"},
    },
}

_PATCH_CONTEXT_OUTPUT_SCHEMA = copy.deepcopy(ACTION_PACKET_OUTPUT_SCHEMA)
_PATCH_CONTEXT_OUTPUT_SCHEMA["properties"].update({
    "kind": {"const": "patch_context"},
    "source_search_status": {"const": "required"},
    "recommended_next_action": {
        "type": "object",
        "required": ["tool", "type", "handled_by", "auto_execute", "requires_confirmation",
                     "repeat_docs_context", "query_terms"],
        "properties": {
            "tool": {"const": "code_search"},
            "type": {"const": "search_local_source"},
            "handled_by": {"const": "coding_agent"},
            "auto_execute": {"const": False},
            "requires_confirmation": {"const": False},
            "repeat_docs_context": {"const": False},
            **{key: {"type": "array", "minItems": 1,
                     "items": {"type": "string", "minLength": 1}}
               for key in ("query_terms", "suggested_doc_paths", "suggested_symbols")},
        },
        "additionalProperties": False,
    },
})
_PATCH_CONTEXT_OUTPUT_SCHEMA["required"].append("kind")
PUBLIC_GET_DOCS_CONTEXT_OUTPUT_SCHEMA: dict[str, Any] = {
    "oneOf": [_DOCS_CONTEXT_OUTPUT_SCHEMA, _PATCH_CONTEXT_OUTPUT_SCHEMA],
}

__all__=[n for n in globals() if not n.startswith('__')]
