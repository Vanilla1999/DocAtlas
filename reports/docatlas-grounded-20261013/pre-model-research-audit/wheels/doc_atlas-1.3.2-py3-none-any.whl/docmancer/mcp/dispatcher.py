"""Tool-call dispatcher: schema validation, safety, credentials, idempotency, executor.

This is the runtime spine described in spec sections 2.5, 2.7.5, 2.8.1,
2.8.3, 2.8.5, 2.8.6, 2.8.7. Pure functions where possible so tests can
drive it directly without a real MCP transport.
"""
from __future__ import annotations

import difflib
import time
from dataclasses import dataclass
from typing import Any

import jsonschema

from docmancer.mcp import credentials, idempotency, safety
from docmancer.mcp.executors import get_executor
from docmancer.mcp.logging import log_call
from docmancer.mcp.manifest import InstalledPackage, Manifest
from docmancer.mcp.network_policy import SecurityError, grant_from_mapping, target_url, validate_http_target
from docmancer.mcp.search import ToolEntry, build_corpus, search_with_metadata
from docmancer.mcp.slug import split_tool_name


@dataclass
class DispatchResult:
    ok: bool
    body: Any
    error_code: str | None = None
    idempotency_key: str | None = None
    status: int | str | None = None


SEARCH_TOOL = "docmancer_search_tools"
CALL_TOOL = "docmancer_call_tool"
DEFAULT_EXECUTOR = "noop_doc"

SEARCH_TOOL_SCHEMA = {
    "type": "object",
    "properties": {
        "query": {"type": "string"},
        "package": {"type": "string"},
        "limit": {"type": "integer", "minimum": 1, "maximum": 25, "default": 5},
    },
    "required": ["query"],
}

CALL_TOOL_SCHEMA = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "args": {"type": "object"},
    },
    "required": ["name", "args"],
}


class Dispatcher:
    def __init__(self, manifest: Manifest):
        self._manifest = manifest
        self._corpus: list[ToolEntry] = build_corpus(manifest.enabled_packages())

    def list_tools(self) -> list[dict[str, Any]]:
        return [
            {
                "name": SEARCH_TOOL,
                "description": (
                    "Search across installed API packages for tools matching a task. "
                    "Returns top-K tool names with descriptions, score/rank "
                    "metadata, low-confidence search metadata, and inlined input "
                    "schemas. Pass an empty query with package to list that package's "
                    "tools. Always call this before docmancer_call_tool."
                ),
                "inputSchema": SEARCH_TOOL_SCHEMA,
            },
            {
                "name": CALL_TOOL,
                "description": (
                    "Invoke a tool returned by docmancer_search_tools. Use the fully "
                    "qualified name from the search result."
                ),
                "inputSchema": CALL_TOOL_SCHEMA,
            },
        ]

    def search_tools(
        self,
        query: str,
        *,
        package: str | None = None,
        limit: int = 5,
    ) -> dict[str, Any]:
        hits, search_meta = search_with_metadata(self._corpus, query, package=package, limit=limit)
        fallback_hint: str | None = None
        if not hits and package and query:
            hits, search_meta = search_with_metadata(self._corpus, "", package=package, limit=limit)
            fallback_hint = "No lexical matches; showing package tools instead."
        out: list[dict[str, Any]] = []
        for hit in hits:
            m = hit.entry
            entry: dict[str, Any] = {
                "name": m.name,
                "package": m.package,
                "version": m.version,
                "description": m.description,
                "safety": m.safety,
                "score": hit.score,
                "lexicalScore": hit.lexical_score,
                "semanticScore": hit.semantic_score,
                "rankReason": hit.rank_reason,
            }
            entry["inputSchema"] = m.input_schema
            out.append(entry)
        if fallback_hint:
            search_meta = {**search_meta, "lowConfidence": True, "hint": fallback_hint}
        return {
            "matches": out,
            "search": search_meta,
        }

    def call_tool(self, name: str, args: dict[str, Any]) -> DispatchResult:
        start = time.time()
        resolved = self._resolve(name)
        if resolved is None:
            suggestions = self._fuzzy_suggestions(name)
            body = {
                "error": "tool_not_found",
                "message": f"Unknown tool: {name}",
                "did_you_mean": suggestions,
            }
            log_call(tool=name, args=args, status="tool_not_found",
                     latency_ms=int((time.time() - start) * 1000))
            return DispatchResult(False, body, "tool_not_found")

        pkg, operation = resolved
        contract = pkg.contract()
        auth = contract.get("auth", {}) or {}
        input_schema = operation.get("inputSchema") or _schema_from_params(operation)

        # Strip docmancer control fields before validation
        validation_args = {k: v for k, v in args.items() if not k.startswith("_docatlas")}
        try:
            jsonschema.validate(validation_args, input_schema)
        except jsonschema.ValidationError as exc:
            body = {
                "error": "invalid_args",
                "message": exc.message,
                "schema_path": list(exc.absolute_path),
                "schema": input_schema,
            }
            log_call(tool=name, args=args, status="invalid_args",
                     latency_ms=int((time.time() - start) * 1000))
            return DispatchResult(False, body, "invalid_args")

        executor_kind = operation.get("executor", DEFAULT_EXECUTOR)
        operation_grant = pkg.grant_for(str(operation.get("id") or ""))
        validated_http_target = None
        if executor_kind == "http":
            http_meta = operation.get("http", {}) or {}
            try:
                validated_http_target = validate_http_target(
                    target_url(http_meta.get("base_url", ""), http_meta.get("path", "")),
                    grant_from_mapping(operation_grant),
                )
            except SecurityError as exc:
                body = {"error": exc.code, "message": f"HTTP target blocked: {exc.code}"}
                log_call(tool=name, args=args, status=exc.code,
                         latency_ms=int((time.time() - start) * 1000))
                return DispatchResult(False, body, exc.code)

        auth_material = credentials.build_auth(pkg.package, auth, args)
        missing = auth_material.missing
        gate = safety.check(
            package=pkg.package,
            version=pkg.version,
            operation=operation,
            allow_destructive=pkg.allow_destructive and bool(operation_grant.get("allow_destructive")),
            has_credentials=not missing or not (operation.get("safety") or {}).get("requires_auth"),
        )
        if not gate.allowed:
            body = {
                "error": gate.error_code,
                "message": gate.message,
                "missing_credential_sources": missing if gate.error_code == "missing_credentials" else None,
            }
            log_call(tool=name, args=args, status=gate.error_code or "blocked",
                     latency_ms=int((time.time() - start) * 1000))
            return DispatchResult(False, body, gate.error_code)

        # Idempotency
        idempotency_key: str | None = None
        idempotency_header = auth.get("idempotency_header")
        if _should_create_idempotency_key(operation, executor_kind) and idempotency_header:
            idempotency_key, _ = idempotency.get_or_create_key(name, args)

        if executor_kind in {"python_import", "shell"} and not getattr(pkg, "allow_execute", False):
            body = {
                "error": "execution_not_allowed",
                "message": (
                    f"Operation {operation.get('id')} uses executor '{executor_kind}' which "
                    f"requires opt-in. To enable: doc-atlas install-pack {pkg.package}@{pkg.version} "
                    f"--allow-execute, then restart your agent."
                ),
            }
            log_call(tool=name, args=args, status="execution_not_allowed",
                     latency_ms=int((time.time() - start) * 1000))
            return DispatchResult(False, body, "execution_not_allowed")
        allowed_executors = operation_grant.get("allowed_executors") or []
        if executor_kind in {"python_import", "shell"} and executor_kind not in allowed_executors:
            body = {
                "error": "executor_not_granted",
                "message": f"Operation {operation.get('id')} is not granted for executor '{executor_kind}'.",
            }
            log_call(tool=name, args=args, status="executor_not_granted",
                     latency_ms=int((time.time() - start) * 1000))
            return DispatchResult(False, body, "executor_not_granted")
        executor = get_executor(executor_kind)
        operation_for_executor = dict(operation)
        if executor_kind == "http":
            operation_for_executor["_docatlas_http_grant"] = operation_grant
            if validated_http_target is not None:
                operation_for_executor["_docatlas_http_resolved_ips"] = list(validated_http_target.resolved_ips)
        elif executor_kind == "python_import":
            operation_for_executor["_docatlas_operation_grant"] = operation_grant
        result = executor.call(
            operation=operation_for_executor,
            args=validation_args,
            auth_headers={} if executor_kind == "python_import" else auth_material.headers,
            required_headers={} if executor_kind == "python_import" else auth.get("required_headers", {}) or {},
            idempotency_key=idempotency_key,
            idempotency_header=idempotency_header,
            auth_params={} if executor_kind == "python_import" else auth_material.params,
            auth_cookies={} if executor_kind == "python_import" else auth_material.cookies,
        )

        body: Any = result.body
        if isinstance(body, dict) and idempotency_key:
            body = {**body, "_docatlas": {"idempotency_key": idempotency_key}}

        log_call(
            tool=name,
            args=args,
            status=result.status,
            latency_ms=int((time.time() - start) * 1000),
            idempotency_key=idempotency_key,
        )
        return DispatchResult(
            ok=result.ok,
            body=body if result.ok else {"error": result.error or "executor_error", "status": result.status, "body": body},
            error_code=None if result.ok else "executor_error",
            idempotency_key=idempotency_key,
            status=result.status,
        )

    # ---- internals ----

    def _resolve(self, tool_name: str) -> tuple[InstalledPackage, dict[str, Any]] | None:
        for entry in self._corpus:
            if entry.name == tool_name:
                pkg = self._manifest.find(entry.package, entry.version)
                if pkg is None:
                    return None
                contract = pkg.contract()
                for op in contract.get("operations", []):
                    if op.get("id") == entry.operation_id:
                        return pkg, op
                return None
        # Fallback: parse the name and search the contract directly
        parts = split_tool_name(tool_name)
        if not parts:
            return None
        pkg_slug, _ver_slug, op_id = parts
        for pkg in self._manifest.enabled_packages():
            if pkg.package.replace(".", "_").replace("-", "_").replace("/", "_") != pkg_slug:
                continue
            for op in pkg.contract().get("operations", []):
                if op.get("id") == op_id:
                    return pkg, op
        return None

    def _fuzzy_suggestions(self, name: str, n: int = 3) -> list[str]:
        names = [t.name for t in self._corpus]
        return difflib.get_close_matches(name, names, n=n, cutoff=0.4)


def _schema_from_params(operation: dict[str, Any]) -> dict[str, Any]:
    """Build a JSON Schema from contract `params` if no inputSchema was provided."""
    properties: dict[str, Any] = {}
    required: list[str] = []
    for p in operation.get("params", []) or []:
        name = p.get("name")
        if not name:
            continue
        prop: dict[str, Any] = {}
        if p.get("type"):
            prop["type"] = p["type"]
        if p.get("description"):
            prop["description"] = p["description"]
        properties[name] = prop or {"type": "string"}
        if p.get("required"):
            required.append(name)
    schema: dict[str, Any] = {"type": "object", "properties": properties, "additionalProperties": True}
    if required:
        schema["required"] = required
    return schema


def _should_create_idempotency_key(operation: dict[str, Any], executor_kind: str) -> bool:
    if executor_kind != "http":
        return False
    method = ((operation.get("http") or {}).get("method") or "GET").upper()
    if method in {"GET", "HEAD", "OPTIONS"}:
        return False
    safety_meta = operation.get("safety") or {}
    return safety_meta.get("idempotent") is not True
