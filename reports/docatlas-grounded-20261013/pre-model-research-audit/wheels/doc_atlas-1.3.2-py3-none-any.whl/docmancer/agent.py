from __future__ import annotations

from docmancer._agent_parser_loading import _import_class
import json
import logging
import os
import hashlib
import fnmatch
import re
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable
from datetime import datetime, timezone



from docmancer.core.config import DocmancerConfig
from docmancer.core.models import Document, RetrievedChunk
from docmancer.core.sqlite_store import SQLiteStore, document_section_count

logger = logging.getLogger(__name__)

_PARSERS = {
    ".txt": "docmancer.connectors.parsers.text:TextLoader",
    ".md": "docmancer.connectors.parsers.markdown:MarkdownLoader",
    ".markdown": "docmancer.connectors.parsers.markdown:MarkdownLoader",
    ".pdf": "docmancer.connectors.parsers.pdf:PDFLoader",
    ".docx": "docmancer.connectors.parsers.docx:DOCXLoader",
    ".rtf": "docmancer.connectors.parsers.rtf:RTFLoader",
    ".html": "docmancer.connectors.parsers.html:HTMLLoader",
    ".htm": "docmancer.connectors.parsers.html:HTMLLoader",
}

SOURCE_DERIVED_METADATA_KEYS = {
    "docset_root",
    "canonical_url",
    "source_url",
    "title",
    "description",
    "section_path",
    "lang",
    "format",
}


class DocmancerAgent:
    """High-level API for local documentation context compression."""

    def __init__(self, config: DocmancerConfig | None = None, _lazy_init: bool = False):
        self.config = config or DocmancerConfig()
        self._store: SQLiteStore | None = None
        self.last_ingest_report_path: Path | None = None
        self.last_ingest_skips: list[dict[str, str]] = []
        self.last_discovery_diagnostics: dict[str, Any] = {}
        self.last_vector_sync_metrics: dict[str, Any] = {
            "status": "not_requested"
        }
        if not _lazy_init:
            self._init_components()

    def _init_components(self) -> None:
        if self.config.index.provider != "sqlite":
            raise ValueError(
                f"Unsupported index provider '{self.config.index.provider}'. Supported: sqlite."
            )
        self._store = SQLiteStore(
            self.config.index.db_path,
            extracted_dir=self.config.index.extracted_dir or None,
        )

    @property
    def store(self) -> SQLiteStore:
        if self._store is None:
            self._init_components()
        assert self._store is not None
        return self._store

    def _get_loader(self, suffix: str):
        parser_path = _PARSERS.get(suffix)
        if not parser_path:
            raise ValueError(f"No parser for '{suffix}'. Supported: {list(_PARSERS.keys())}")
        cls = _import_class(parser_path)
        return cls()

    def ingest_documents(
        self,
        documents: list[Document],
        recreate: bool = False,
        *,
        with_vectors: bool = True,
    ) -> int:
        self.last_vector_sync_metrics = {
            "status": "requested" if with_vectors else "not_requested"
        }
        for document in documents:
            if str(document.metadata.get("format") or "").casefold() == "markdown":
                document.metadata.setdefault("chunking_schema", "parent-child-v1")
                document.metadata.setdefault("child_target_tokens", 160)
                document.metadata.setdefault("child_hard_max_tokens", 512)
        logger.info("Indexing %d document(s) with SQLite FTS5", len(documents))
        result = self.store.add_documents(
            documents,
            recreate=recreate,
            activate_generation=not with_vectors,
        )
        logger.info("Stored %d source(s), %d section(s)", result.sources, result.sections)
        if with_vectors:
            try:
                if result.generation_id:
                    self.prepare_vector_generation(result.generation_id)
                    synced = self._sync_vectors_if_enabled(
                        generation_id=result.generation_id,
                        prune_stale=False,
                    )
                    self._require_completed_vector_sync(synced)
                    primary_metrics = dict(self.last_vector_sync_metrics)
                    self.store.activate_generation(
                        result.generation_id,
                        require_vector_witness=self._vector_retrieval_required(),
                    )
                    if synced:
                        self._sync_vectors_if_enabled(
                            generation_id=result.generation_id,
                            prune_stale=True,
                        )
                        cleanup_metrics = dict(self.last_vector_sync_metrics)
                        self.last_vector_sync_metrics = {
                            **primary_metrics,
                            "duration_ms": int(primary_metrics.get("duration_ms", 0))
                            + int(cleanup_metrics.get("duration_ms", 0)),
                            "cleanup": cleanup_metrics,
                        }
                else:
                    synced = self._sync_vectors_if_enabled(
                        generation_id=self.store.active_generation_id()
                    )
                    self._require_completed_vector_sync(synced)
            except Exception as exc:
                if result.generation_id:
                    if self.discard_vector_generation(result.generation_id):
                        self.store.discard_candidate_generation(result.generation_id)
                raise RuntimeError(f"vector indexing failed after FTS5 ingest: {exc}") from exc
        return result.sections

    def ingest_records(
        self,
        records,
        *,
        recreate: bool = False,
        batch_size: int = 1000,
        with_vectors: bool = True,
        progress_callback=None,
    ) -> int:
        """Stream-ingest an iterable of ``Document`` records.

        Designed for atomic-record sources (USPTO case files, court filings)
        where the iterator would yield millions of records. The iterable is
        consumed lazily and committed every ``batch_size`` rows.
        """
        result = self.store.add_documents_stream(
            records,
            recreate=recreate,
            batch_size=batch_size,
            progress_callback=progress_callback,
        )
        logger.info(
            "Stream-ingested %d source(s), %d section(s)",
            result.sources,
            result.sections,
        )
        if with_vectors:
            try:
                synced = self._sync_vectors_if_enabled(
                    generation_id=self.store.active_generation_id()
                )
                self._require_completed_vector_sync(synced)
            except Exception as exc:
                raise RuntimeError(f"vector indexing failed after FTS5 ingest: {exc}") from exc
        return result.sections

    def _base_vector_collection_name(self) -> str:
        explicit = self.config.vector_store.collection
        if explicit:
            return explicit
        slug = Path(self.config.index.db_path).stem or "docmancer"
        safe_slug = re.sub(r"[^A-Za-z0-9_]", "_", slug).strip("_") or "docmancer"
        if safe_slug[0].isdigit():
            safe_slug = f"index_{safe_slug}"
        return f"docmancer_{safe_slug}"

    def _vector_collection_name(self) -> str:
        """Resolve the collection activated with the SQLite generation."""
        generation = self.store.generation_info()
        if generation and generation.get("vector_collection"):
            return str(generation["vector_collection"])
        return self._base_vector_collection_name()

    def prepare_vector_generation(self, generation_id: str | None = None) -> str:
        """Assign a unique collection before a candidate generation is synchronized."""
        target = generation_id or self.store.active_generation_id()
        if not target:
            raise RuntimeError("cannot prepare vectors without an index generation")
        info = self.store.generation_info(target) or {}
        base = self._base_vector_collection_name()[:180].rstrip("._-") or "docmancer"
        collection = (
            f"{base}_pc_"
            f"{str(info.get('retrieval_config_hash') or info.get('config_hash') or '')[:12]}_"
            f"{str(target).removeprefix('gen-')[:12]}"
        )
        self.store.set_generation_vector_collection(target, collection)
        return collection

    def _vector_retrieval_required(self) -> bool:
        mode = str(getattr(self.config.retrieval, "default_mode", "lexical") or "lexical").lower()
        return mode in {"dense", "sparse", "hybrid"}

    def _require_completed_vector_sync(self, result: Any | None) -> None:
        """Fail closed when the configured read path requires vector parity."""
        if result is not None or not self._vector_retrieval_required():
            return
        reason = str(self.last_vector_sync_metrics.get("reason") or "vector_sync_incomplete")
        self.last_vector_sync_metrics = {
            **self.last_vector_sync_metrics,
            "status": "failed",
            "reason": reason,
        }
        raise RuntimeError(
            f"vector retrieval mode {self.config.retrieval.default_mode!r} requires a "
            f"complete vector index, but synchronization did not complete: {reason}"
        )

    def _sync_vectors_if_enabled(
        self,
        *,
        section_ids: set[int] | None = None,
        prune_ids: set[int] | None = None,
        generation_id: str | None = None,
        prune_stale: bool = True,
    ) -> Any | None:
        """Embed any new chunks and upsert into the configured vector store.

        When a caller explicitly requests vectors, this may download the
        pinned Qdrant binary on first run, start it with telemetry disabled,
        embed selected sections, and upsert them into the configured store.

        Opt-outs (each used by tests and FTS5-only installs):

        - ``DOCATLAS_AUTO_VECTORS=0`` skips the vector path entirely.
        - ``DOCATLAS_QDRANT_URL`` short-circuits the managed lifecycle.
        - Missing cloud-embedding API key for the configured provider:
          logs a warning and falls back to FTS5-only ingest (no vectors).
        - ``[vector]`` extras stripped from the venv: silent no-op.
        """
        import os as _os

        started = time.monotonic()
        self.last_vector_sync_metrics = {"status": "starting"}

        if _os.environ.get("DOCATLAS_AUTO_VECTORS") == "0":
            logger.debug("vector sync disabled by DOCATLAS_AUTO_VECTORS=0")
            self.last_vector_sync_metrics = {
                "status": "skipped",
                "reason": "disabled_by_environment",
                "duration_ms": int((time.monotonic() - started) * 1000),
            }
            return None

        try:
            from docmancer.embeddings import get_embeddings_provider
            from docmancer.embeddings.pipeline import sync_vector_store
            from docmancer.runtime.qdrant_manager import QdrantManager, ensure_running
            from docmancer.stores.base import get_vector_store
        except ImportError as exc:
            logger.info("vector indexing disabled: %s", exc)
            self.last_vector_sync_metrics = {
                "status": "skipped",
                "reason": "missing_vector_extra",
                "duration_ms": int((time.monotonic() - started) * 1000),
            }
            return None

        # Graceful fallback: cloud embedding providers need an API key. When
        # the configured provider has no key in env, log once and skip the
        # vector path so FTS5 ingest still succeeds.
        emb_provider = (self.config.embeddings.provider or "").lower()
        _provider_keys = {
            "openai": "OPENAI_API_KEY",
            "voyage": "VOYAGE_API_KEY",
            "cohere": "COHERE_API_KEY",
        }
        required_key = _provider_keys.get(emb_provider)
        if required_key and not _os.environ.get(required_key):
            logger.warning(
                "embeddings.provider=%r requires %s; falling back to FTS5-only ingest "
                "(set the env var, or switch to embeddings.provider=fastembed for local "
                "embeddings with no API key).",
                emb_provider,
                required_key,
            )
            self.last_vector_sync_metrics = {
                "status": "skipped",
                "reason": "missing_provider_api_key",
                "duration_ms": int((time.monotonic() - started) * 1000),
            }
            return None

        vs_config = self.config.vector_store
        backend_started = time.monotonic()
        if vs_config.provider == "qdrant" and not vs_config.url:
            resolution = ensure_running()
            if resolution.fallback or not resolution.url:
                logger.info(
                    "managed qdrant unavailable (%s); falling back to sqlite-vec",
                    resolution.reason,
                )
                vs_config = vs_config.model_copy(update={"provider": "sqlite-vec"})
            else:
                vs_config = vs_config.model_copy(update={"url": resolution.url})

        try:
            vector_store = get_vector_store(vs_config, embeddings_dim=self.config.embeddings.dimensions)
        except ImportError as exc:
            logger.info("vector indexing disabled (missing extra): %s", exc)
            self.last_vector_sync_metrics = {
                "status": "skipped",
                "reason": "vector_store_unavailable",
                "duration_ms": int((time.monotonic() - started) * 1000),
            }
            return None

        backend_setup_ms = int((time.monotonic() - backend_started) * 1000)

        provider = get_embeddings_provider(self.config.embeddings)
        include_sparse = self.config.retrieval.default_mode in {"sparse", "hybrid"}
        generation_info = self.store.generation_info(generation_id) if generation_id else None
        collection = (
            str(generation_info["vector_collection"])
            if generation_info else self._vector_collection_name()
        )
        self.last_vector_sync_metrics = {
            "status": "syncing",
            "vector_backend": vs_config.provider,
            "collection": collection,
        }
        result = sync_vector_store(
            store=self.store,
            config=self.config,
            provider=provider,
            vector_store=vector_store,
            collection=collection,
            include_sparse=include_sparse,
            section_ids=section_ids,
            prune_ids=prune_ids,
            generation_id=generation_id,
            prune_stale=prune_stale,
        )
        result.duration_ms = int((time.monotonic() - started) * 1000)
        result.backend_setup_ms = backend_setup_ms
        result.collection = collection
        if generation_id and section_ids is None:
            backend_identity = vector_store.backend_identity()
            self.store.set_generation_vector_backend(
                generation_id, vs_config.provider, backend_identity
            )
            expected_ids = {
                str(row.get("vector_id") or row.get("section_id"))
                for row in self.store.list_sections_for_embedding(generation_id)
            }
            actual_ids = vector_store.point_ids(collection)
            missing_ids = expected_ids - actual_ids
            extra_ids = actual_ids - expected_ids
            if missing_ids or extra_ids:
                raise RuntimeError(
                    "candidate vector collection parity failed: "
                    f"expected={len(expected_ids)}, actual={len(actual_ids)}, "
                    f"missing={len(missing_ids)}, extra={len(extra_ids)}"
                )
            parity_digest = hashlib.sha256(
                "\n".join(sorted(expected_ids)).encode("utf-8")
            ).hexdigest()
            if str((self.store.generation_info(generation_id) or {}).get("status")) != "active":
                self.store.record_vector_parity_witness(
                    generation_id,
                    digest=parity_digest,
                    count=len(expected_ids),
                    backend=vs_config.provider,
                    backend_identity=backend_identity,
                    collection=collection,
                )
            if prune_stale and generation_id == self.store.active_generation_id():
                removable: list[str] = []
                for candidate in self.store.superseded_generation_candidates(retain=1):
                    stale_generation = str(candidate["generation_id"])
                    stale_collection = str(candidate.get("vector_collection") or "")
                    stale_identity = str(candidate.get("vector_backend_identity") or "")
                    stale_backend = str(candidate.get("vector_backend") or "")
                    if (
                        not stale_identity
                        or stale_identity != backend_identity
                        or stale_backend != vs_config.provider
                    ):
                        logger.warning(
                            "retaining generation %s because vector backend identity is unverified",
                            stale_generation,
                        )
                        continue
                    if stale_collection and stale_collection != collection:
                        try:
                            vector_store.delete_collection(stale_collection)
                        except Exception as exc:
                            logger.warning(
                                "retaining generation %s because vector collection cleanup failed: %s",
                                stale_generation,
                                exc,
                            )
                            continue
                    removable.append(stale_generation)
                if removable:
                    self.store.delete_superseded_generations(removable)
        self.last_vector_sync_metrics = {
            "status": "success",
            "vector_backend": vs_config.provider,
            **asdict(result),
        }
        logger.info(
            "vectors: embedded=%d upserted=%d cache_hits=%d unchanged=%d pruned=%d",
            result.embedded,
            result.upserted,
            result.skipped_cache,
            result.skipped_unchanged,
            result.pruned,
        )
        return result

    def discard_vector_generation(self, generation_id: str | None = None) -> bool:
        """Best-effort cleanup for an unpublished candidate vector collection."""
        info = self.store.generation_info(generation_id) or {}
        collection = str(
            info.get("vector_collection")
            or self.last_vector_sync_metrics.get("collection")
            or ""
        )
        backend = str(
            info.get("vector_backend")
            or self.last_vector_sync_metrics.get("vector_backend")
            or ""
        ).lower()
        if not collection or backend not in {"qdrant", "sqlite-vec"}:
            return False
        try:
            from docmancer.runtime.qdrant_manager import ensure_running
            from docmancer.stores.base import get_vector_store

            vector_config = self.config.vector_store.model_copy(update={"provider": backend})
            if backend == "qdrant" and not vector_config.url:
                resolution = ensure_running()
                if resolution.fallback or not resolution.url:
                    return False
                vector_config = vector_config.model_copy(update={"url": resolution.url})
            vector_store = get_vector_store(
                vector_config,
                embeddings_dim=self.config.embeddings.dimensions,
            )
            expected_identity = str(info.get("vector_backend_identity") or "")
            if (
                not expected_identity
                or expected_identity != vector_store.backend_identity()
            ):
                logger.warning(
                    "candidate vector collection cleanup deferred: unverified backend identity"
                )
                return False
            vector_store.delete_collection(collection)
            return True
        except Exception as exc:
            logger.warning(
                "candidate vector collection cleanup deferred for %s: %s",
                collection,
                exc,
            )
            return False

    def sync_vectors(self) -> Any | None:
        """Synchronize the committed SQLite index into its production vector collection."""
        return self._sync_vectors_if_enabled(generation_id=self.store.active_generation_id())

    def sync_vector_chunks(self, section_ids: set[int]) -> Any | None:
        """Upsert only explicitly affected chunks without reconciling unrelated rows."""
        if section_ids:
            return self._sync_vectors_if_enabled(
                section_ids=set(section_ids),
                prune_ids=set(),
                generation_id=self.store.active_generation_id(),
            )
        return None

    def prune_vector_chunks(self, chunk_ids: set[int]) -> int:
        """Delete exact tracked vector ids without embedding or starting a backend."""
        import os as _os

        if not chunk_ids:
            return 0
        generation_id = self.store.active_generation_id()
        collection = self._vector_collection_name()
        generation_records: dict[str, dict[str, str]] = {}
        tracked_stable_ids: list[str] = []
        vector_ids: list[str | int]
        if generation_id:
            generation_records = self.store.list_generation_vector_upserts(collection)
            wanted = {int(value) for value in chunk_ids}
            active_rows = self.store.list_sections_for_embedding(generation_id)
            tracked_stable_ids = [
                str(row["stable_chunk_id"])
                for row in active_rows
                if int(row["section_id"]) in wanted
                and str(row["stable_chunk_id"]) in generation_records
            ]
            vector_ids = [
                generation_records[stable_id]["vector_id"]
                for stable_id in tracked_stable_ids
            ]
            if not vector_ids:
                return 0
        else:
            tracked = set(self.store.list_embedding_upserts(collection)) & {
                int(value) for value in chunk_ids
            }
            if not tracked:
                return 0
            vector_ids = sorted(tracked)
        try:
            from docmancer.runtime.qdrant_manager import QdrantManager
            from docmancer.stores.base import get_vector_store
        except ImportError as exc:
            raise RuntimeError(f"vector cleanup unavailable: {exc}") from exc

        vs_config = self.config.vector_store
        if vs_config.provider == "qdrant" and not vs_config.url:
            explicit_url = _os.environ.get("DOCATLAS_QDRANT_URL")
            if explicit_url:
                vs_config = vs_config.model_copy(update={"url": explicit_url})
            else:
                status = QdrantManager().status()
                if not (status.get("alive") and status.get("owned") and status.get("healthy")):
                    raise RuntimeError(
                        "vector cleanup requires the existing managed Qdrant process; "
                        "refusing to start or download it during incremental maintenance"
                    )
                vs_config = vs_config.model_copy(update={"url": status.get("url")})
        vector_store = get_vector_store(
            vs_config, embeddings_dim=self.config.embeddings.dimensions
        )
        deleted = vector_store.delete_points(collection, vector_ids)
        if generation_id:
            self.store.delete_generation_vector_upserts(
                collection, tracked_stable_ids
            )
        else:
            self.store.delete_embedding_upserts(
                collection, [int(value) for value in vector_ids]
            )
        return deleted

    def ingest(
        self,
        path: str | Path,
        recreate: bool = False,
        *,
        include: tuple[str, ...] = (),
        include_exact: tuple[str, ...] = (),
        extensionless_text_names: tuple[str, ...] = (),
        exclude: tuple[str, ...] = (),
        formats: tuple[str, ...] = (),
        recursive: bool = True,
        skip_known: bool = False,
        with_vectors: bool = True,
        metadata: dict[str, Any] | None = None,
        metadata_for_file: Callable[[Path], dict[str, Any]] | None = None,
    ) -> int:
        path = Path(path)
        extensionless_text_names_lower = {name.lower() for name in extensionless_text_names}
        if not path.exists():
            raise FileNotFoundError(f"Path not found: {path}")
        if path.is_file():
            files = [path]
        else:
            supported = set(_PARSERS.keys())
            selected_formats = {fmt if fmt.startswith(".") else f".{fmt}" for fmt in formats}
            allowed = supported & {fmt.lower() for fmt in selected_formats} if selected_formats else supported
            extensionless_text_allowed = not selected_formats or ".txt" in allowed

            def _allowed_file(candidate: Path) -> bool:
                suffix = candidate.suffix.lower()
                if suffix in allowed:
                    return True
                return (
                    not suffix
                    and extensionless_text_allowed
                    and candidate.name.lower() in extensionless_text_names_lower
                )

            if include_exact:
                root = path.resolve()
                selected_files: list[Path] = []
                seen: set[Path] = set()
                for relative in include_exact:
                    exact_path = Path(relative)
                    candidate = exact_path if exact_path.is_absolute() else path / exact_path
                    try:
                        resolved = candidate.resolve()
                        resolved.relative_to(root)
                    except (OSError, ValueError):
                        continue
                    if resolved in seen:
                        continue
                    seen.add(resolved)
                    if candidate.is_file() and _allowed_file(candidate):
                        selected_files.append(candidate)
                files = selected_files
            else:
                iterator = path.rglob("*") if recursive else path.glob("*")
                files = sorted(f for f in iterator if f.is_file() and _allowed_file(f))
                if include:
                    files = [f for f in files if self._matches_any(f.relative_to(path), include)]
            if exclude:
                files = [f for f in files if not self._matches_any(f.relative_to(path), exclude)]
        if not files:
            raise ValueError("No supported documents found.")
        documents = []
        skipped: list[dict[str, str]] = []
        for file_path in files:
            try:
                extensionless_as_text = (
                    not file_path.suffix
                    and file_path.name.lower() in extensionless_text_names_lower
                )
                loader = self._get_loader(".txt" if extensionless_as_text else file_path.suffix.lower())
                document = loader.load(file_path)
                suffix = "txt" if extensionless_as_text else file_path.suffix.lower().lstrip(".")
                format_name = "markdown" if suffix in {"md", "markdown"} else suffix
                document.metadata.setdefault("format", format_name)
                document.metadata.setdefault("chunking_strategy", getattr(loader, "chunking_strategy", "heading"))
                if format_name == "markdown":
                    document.metadata.setdefault("chunking_schema", "parent-child-v1")
                    document.metadata.setdefault("child_target_tokens", 160)
                    document.metadata.setdefault("child_hard_max_tokens", 512)
                chunk_size, chunk_overlap = self.config.loaders.settings_for(format_name)
                document.metadata.setdefault("chunk_size", chunk_size)
                document.metadata.setdefault("chunk_overlap", chunk_overlap)
                document.metadata.setdefault("docset_root", str(path if path.is_dir() else file_path))
                if path.is_dir():
                    document.metadata.setdefault("source_path", str(file_path.relative_to(path)))
                else:
                    document.metadata.setdefault("source_path", file_path.name)
                document.metadata.setdefault("title", file_path.stem)
                document.metadata.setdefault(
                    "content_hash",
                    hashlib.sha256(document.content.encode("utf-8")).hexdigest(),
                )
                if metadata:
                    document.metadata.update(metadata)
                if metadata_for_file:
                    document.metadata.update(metadata_for_file(file_path))
                content_hash = str(document.metadata.get("content_hash") or "")
                existing_metadata = self.store.source_metadata(document.source) if skip_known and content_hash else None
                if (
                    existing_metadata is not None
                    and existing_metadata.get("content_hash") == content_hash
                    and self._metadata_satisfies_skip_known(existing_metadata, document.metadata)
                ):
                    skipped.append(
                        {
                            "path": str(file_path),
                            "reason": "unchanged content hash",
                            "exception_type": "SkippedKnownFile",
                        }
                    )
                    continue
                documents.append(document)
            except Exception as exc:
                skipped.append(
                    {
                        "path": str(file_path),
                        "reason": str(exc),
                        "exception_type": type(exc).__name__,
                    }
                )
                logger.warning("Skipping %s: %s: %s", file_path, type(exc).__name__, exc)
        self._write_last_ingest_report(path, skipped)
        if not documents:
            raise ValueError(f"No documents could be loaded. See {self.last_ingest_report_path}")
        return self.ingest_documents(documents, recreate=recreate, with_vectors=with_vectors)

    @staticmethod
    def _matches_any(relative_path: Path, patterns: tuple[str, ...]) -> bool:
        value = relative_path.as_posix()
        return any(fnmatch.fnmatch(value, pattern) or relative_path.match(pattern) for pattern in patterns)

    @staticmethod
    def _metadata_satisfies_skip_known(existing_metadata: dict[str, Any], expected_metadata: dict[str, Any]) -> bool:
        return all(existing_metadata.get(key) == value for key, value in expected_metadata.items())

    def _write_last_ingest_report(self, root: Path, skipped: list[dict[str, str]]) -> None:
        home = Path(os.environ.get("DOCATLAS_HOME") or Path(self.config.index.db_path).expanduser().parent)
        home.mkdir(parents=True, exist_ok=True)
        report_path = home / "last-ingest-report.json"
        spill_path = home / "last-ingest-report.skipped.jsonl"
        max_inline = 10_000
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "root": str(root),
            "skipped_count": len(skipped),
            "skipped": skipped[:max_inline],
            "spillover_path": str(spill_path) if len(skipped) > max_inline else None,
        }
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        if len(skipped) > max_inline:
            spill_path.write_text(
                "\n".join(json.dumps(item, ensure_ascii=False) for item in skipped[max_inline:]) + "\n",
                encoding="utf-8",
            )
        elif spill_path.exists():
            spill_path.unlink()
        self.last_ingest_report_path = report_path
        self.last_ingest_skips = skipped

    def add(self, path_or_url: str, recreate: bool = False, **kwargs) -> int:
        if path_or_url.startswith(("http://", "https://")):
            return self.ingest_url(path_or_url, recreate=recreate, **kwargs)
        return self.ingest(path_or_url, recreate=recreate)

    def _get_fetcher(
        self,
        provider: str | None,
        fetcher=None,
        max_pages: int = 500,
        strategy: str | None = None,
        browser: bool = False,
        url: str | None = None,
        doc_format: str | None = None,
        seed_urls: list[str] | None = None,
        allowed_domains: list[str] | None = None,
        path_prefixes: list[str] | None = None,
        progress_callback: Callable[[dict[str, Any]], None] | None = None,
        cancellation_callback: Callable[[], bool] | None = None,
        deadline_at: float | None = None,
        source_manifest: dict[str, Any] | None = None,
        query: str | None = None,
        exact_urls: list[str] | None = None,
        robots_urls: list[str] | None = None,
    ):
        if fetcher is not None:
            raise ValueError("injected_fetcher_finite_contract_unavailable")
        from docmancer.connectors.fetchers.factory import build_fetcher

        if provider is None and url:
            provider = self._auto_detect_provider(url)

        return build_fetcher(
            url or "",
            provider=provider,
            timeout=getattr(self.config.web_fetch, "read_timeout_seconds", 30.0),
            max_pages=max_pages,
            strategy=strategy,
            browser=browser,
            workers=self.config.web_fetch.workers,
            doc_format=doc_format,
            seed_urls=seed_urls,
            allowed_domains=allowed_domains,
            path_prefixes=path_prefixes,
            max_redirects=getattr(self.config.web_fetch, "max_redirects", 5),
            connect_timeout=self.config.web_fetch.connect_timeout_seconds,
            max_total_seconds=self.config.web_fetch.max_total_seconds,
            use_env_proxy=getattr(self.config.web_fetch, "use_env_proxy", False),
            proxy_url=getattr(self.config.web_fetch, "proxy_url", None),
            max_response_bytes=getattr(self.config.web_fetch, "max_response_bytes", 8 * 1024 * 1024),
            max_decoded_text_bytes=getattr(
                self.config.web_fetch, "max_decoded_text_bytes", 16 * 1024 * 1024
            ),
            progress_callback=progress_callback,
            cancellation_callback=cancellation_callback,
            deadline_at=deadline_at,
            source_manifest=source_manifest,
            query=query,
            exact_urls=exact_urls if exact_urls is not None else ([url, *(seed_urls or [])] if url else []),
            robots_urls=robots_urls,
        )

    def _auto_detect_provider(self, url: str) -> str:
        logger.info("Using secure web fetcher; platform detection happens inside its network boundary")
        return "web"

    def ingest_url(
        self,
        url: str,
        recreate: bool = False,
        fetcher=None,
        provider: str | None = None,
        max_pages: int = 500,
        strategy: str | None = None,
        browser: bool = False,
        doc_format: str | None = None,
        seed_urls: list[str] | None = None,
        allowed_domains: list[str] | None = None,
        path_prefixes: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        progress_callback: Callable[[dict[str, Any]], None] | None = None,
        cancellation_callback: Callable[[], bool] | None = None,
        deadline_at: float | None = None,
        with_vectors: bool = True,
        source_manifest: dict[str, Any] | None = None,
        query: str | None = None,
        exact_urls: list[str] | None = None,
        robots_urls: list[str] | None = None,
    ) -> int:
        f = self._get_fetcher(
            provider,
            fetcher,
            max_pages=max_pages,
            strategy=strategy,
            browser=browser,
            url=url,
            doc_format=doc_format,
            seed_urls=seed_urls,
            allowed_domains=allowed_domains,
            path_prefixes=path_prefixes,
            progress_callback=progress_callback,
            cancellation_callback=cancellation_callback,
            deadline_at=deadline_at,
            source_manifest=source_manifest,
            query=query,
            exact_urls=exact_urls,
            robots_urls=robots_urls,
        )
        documents = f.fetch(url)
        self.last_fetch_failure = getattr(f, "last_fetch_failure", None)
        if cancellation_callback and cancellation_callback():
            raise RuntimeError("Documentation ingestion cancelled before indexing.")
        section_counts = {document.source: document_section_count(document) for document in documents}
        ledger = list(getattr(f, "last_page_ledger", []) or [])
        for page in ledger:
            if page.get("outcome") != "usable":
                continue
            page["chunks"] = int(
                section_counts.get(str(page.get("canonical_url")))
                or section_counts.get(str(page.get("discovered_url")))
                or 0
            )
        diagnostics = dict(getattr(f, "last_discovery_diagnostics", {}) or {})
        if ledger:
            diagnostics["page_ledger"] = ledger
        self.last_discovery_diagnostics = diagnostics
        if metadata:
            for document in documents:
                source_metadata = dict(document.metadata or {})
                document.metadata.update(metadata)
                for key in SOURCE_DERIVED_METADATA_KEYS:
                    if key in source_metadata:
                        document.metadata[key] = source_metadata[key]
        logger.info("Fetched %d document(s); starting index", len(documents))
        if progress_callback:
            progress_callback(
                {
                    "phase": "indexing",
                    "message": f"Indexing {len(documents)} documents",
                    "indexed_pages": 0,
                    "total_pages": len(documents),
                }
            )
        indexed = self.ingest_documents(documents, recreate=recreate, with_vectors=with_vectors)
        page_failures = int(diagnostics.get("page_failure_count") or 0)
        if not recreate and page_failures == 0 and documents:
            sources_by_root: dict[str, set[str]] = {}
            for document in documents:
                root = str((document.metadata or {}).get("docset_root") or "")
                if root:
                    sources_by_root.setdefault(root, set()).add(document.source)
            stale_removed = sum(
                self.store.delete_docset_sources_except(root, sources)
                for root, sources in sources_by_root.items()
            )
            if stale_removed:
                diagnostics["stale_sources_removed"] = stale_removed
                self.last_discovery_diagnostics = diagnostics
        if progress_callback:
            progress_callback(
                {
                    "phase": "indexing",
                    "message": f"Indexed {indexed} documents",
                    "indexed_pages": indexed,
                    "total_pages": len(documents),
                }
            )
        return indexed

    def fetch_documents(
        self,
        url: str,
        fetcher=None,
        provider: str | None = None,
        max_pages: int = 500,
        strategy: str | None = None,
        browser: bool = False,
        doc_format: str | None = None,
        seed_urls: list[str] | None = None,
        allowed_domains: list[str] | None = None,
        path_prefixes: list[str] | None = None,
        progress_callback: Callable[[dict[str, Any]], None] | None = None,
        exact_urls: list[str] | None = None,
        robots_urls: list[str] | None = None,
        source_manifest: dict[str, Any] | None = None,
    ) -> list[Document]:
        f = self._get_fetcher(
            provider,
            fetcher,
            max_pages=max_pages,
            strategy=strategy,
            browser=browser,
            url=url,
            doc_format=doc_format,
            seed_urls=seed_urls,
            allowed_domains=allowed_domains,
            path_prefixes=path_prefixes,
            progress_callback=progress_callback,
            exact_urls=exact_urls,
            robots_urls=robots_urls,
            source_manifest=source_manifest,
        )
        return f.fetch(url)

    def query(
        self,
        text: str,
        limit: int | None = None,
        budget: int | None = None,
        expand: str | None = None,
        filters: dict[str, Any] | None = None,
    ) -> list[RetrievedChunk]:
        return self.store.query(
            text,
            limit=limit if limit is not None else self.config.query.default_limit,
            budget=budget if budget is not None else self.config.query.default_budget,
            expand=expand if expand is not None else self.config.query.default_expand,
            filters=filters,
        )

    def query_context(
        self,
        text: str,
        *,
        style: str = "markdown",
        include_sources: bool = True,
        limit: int | None = None,
        budget: int | None = None,
        expand: str | None = None,
        filters: dict[str, Any] | None = None,
    ) -> str:
        """Query the index and return a formatted context string.

        Combines :meth:`query` and :func:`~docmancer.context.format_context`
        into a single call for convenience.
        """
        chunks = self.query(text, limit=limit, budget=budget, expand=expand, filters=filters)
        from docmancer.context import format_context

        return format_context(
            chunks, style=style, include_sources=include_sources,
            max_tokens=budget if budget is not None else self.config.query.default_budget,
        )

    def collection_stats(self) -> dict:
        return self.store.collection_stats()

    def get_collection_info(self) -> dict:
        return self.store.collection_stats()

    def list_sources(self) -> list[str]:
        return self.store.list_sources()

    def get_document(self, source: str) -> str | None:
        return self.store.get_document_content(source)

    def remove_source(self, source: str) -> tuple[bool, str]:
        if self.store.delete_docset(source):
            return True, "docset"
        if self.store.delete_source(source):
            return True, "source"
        return False, "missing"

    def remove_all_sources(self) -> bool:
        return self.store.delete_all()

    def list_sources_with_dates(self) -> list[dict]:
        return self.store.list_sources_with_dates()

    def list_grouped_sources_with_dates(self) -> list[dict]:
        return self.store.list_grouped_sources_with_dates()
