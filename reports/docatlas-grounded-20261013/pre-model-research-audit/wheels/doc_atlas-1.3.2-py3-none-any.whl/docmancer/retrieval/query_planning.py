"""Bounded, deterministic query analysis for contextual hybrid retrieval."""
from __future__ import annotations

import hashlib
import re
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping

from docmancer.docs.domain.query_terms import (
    documentation_exact_terms,
    is_exact_technical_token,
)
from docmancer.retrieval.contracts import (
    ExactTerm,
    FilterSpec,
    QueryPlan,
    canonical_hash,
)


QUERY_PLAN_SCHEMA_VERSION = "deterministic-query-plan-v1"
MAX_EXACT_TERMS = 12
MAX_CONCEPT_QUERIES = 3
MAX_DOCUMENT_LOCATOR_CHARS = 240
_TERM_PATTERNS = (
    ("quoted", re.compile(r"[`\"]([^`\"\n]{2,160})[`\"]")),
    ("flag", re.compile(r"(?<![\w.-])--[A-Za-z][A-Za-z0-9-]{1,118}")),
    ("error_code", re.compile(r"\b(?:ERR(?:OR)?[_-]?\d+|[A-Z][A-Z0-9]+[_-]\d+)\b")),
    ("config_key", re.compile(r"\b[A-Z][A-Z0-9_]{2,119}\b")),
    ("symbol", re.compile(r"\b[A-Za-z_]\w*(?:(?:::|\.)[A-Za-z_]\w*)+\b")),
    ("path", re.compile(r"(?<![\w/])(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+")),
)
_DOCUMENT_LOCATOR_RE = re.compile(
    r"(?<![\w/])((?:\.?\.?/)?(?:[A-Za-z0-9_.-]+/)*[A-Za-z0-9_.-]+\.[A-Za-z0-9_-]+)(?![\w/])",
)

_AUTHORITY_MINIMUMS = {
    "unknown": (
        "unknown", "stale", "external_generic", "mirror", "generated",
        "community", "supporting", "verified", "legal", "project_rule",
        "source_of_truth", "project_owned", "official",
    ),
    "community": (
        "community", "supporting", "verified", "project_rule",
        "source_of_truth", "project_owned", "official",
    ),
    "verified": ("verified", "project_rule", "source_of_truth", "project_owned", "official"),
    "project_rule": ("project_rule", "source_of_truth", "project_owned", "official"),
    "project_owned": ("source_of_truth", "project_owned", "official"),
    "official": ("official",),
    "legal": ("legal",),
}


def _strict_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in {0, 1}:
        return bool(value)
    if isinstance(value, str):
        return value.strip().casefold() in {"1", "true", "yes", "on"}
    return False


def _normalize_term(value: str) -> str:
    return " ".join(value.split()).casefold()[:160]


def _canonical_filter_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {
            str(key): _canonical_filter_value(item)
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
        }
    if isinstance(value, (set, frozenset)):
        return sorted(
            (_canonical_filter_value(item) for item in value),
            key=lambda item: canonical_hash(item),
        )
    if isinstance(value, (list, tuple)):
        return [_canonical_filter_value(item) for item in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def extract_exact_terms(query: str) -> tuple[ExactTerm, ...]:
    return tuple(
        ExactTerm(
            value=term.value,
            normalized_value=term.normalized_value,
            kind=term.kind,
        )
        for term in documentation_exact_terms(query, limit=MAX_EXACT_TERMS)
    )


def extract_document_locator(query: str) -> str | None:
    """Return a unique literal source path without interpreting surrounding prose."""
    matches = {
        match.group(1).replace("\\", "/").removeprefix("./").rstrip(".,;:!?")
        for match in _DOCUMENT_LOCATOR_RE.finditer(query)
        if _looks_like_source_path(match.group(1))
        and len(match.group(1)) <= MAX_DOCUMENT_LOCATOR_CHARS
        and Path(match.group(1).rstrip(".,;:!?`\"'")).suffix.casefold()
        in {".md", ".mdx", ".rst", ".txt", ".adoc"}
    }
    return next(iter(matches)) if len(matches) == 1 else None


def _looks_like_source_path(value: str) -> bool:
    normalized = value.replace("\\", "/")
    leaf = normalized.rsplit("/", 1)[-1]
    return (
        normalized.startswith(("./", "../", "/"))
        or "." in leaf
    )


def _concept_queries(query: str, exact_terms: tuple[ExactTerm, ...]) -> tuple[str, ...]:
    return ()


def _requirement_exact_terms(requirements: Any) -> tuple[ExactTerm, ...]:
    """Project canonical requirements into bounded retrieval hints without rebuilding them."""
    terms: list[ExactTerm] = []
    seen: set[str] = set()
    for requirement in requirements:
        kind = str(getattr(requirement, "kind", ""))
        if kind not in {"exact_term", "entity"}:
            continue
        value = " ".join(str(getattr(requirement, "value", "")).split())[:160]
        normalized = _normalize_term(value)
        if not normalized or normalized in seen:
            continue
        terms.append(ExactTerm(
            value=value,
            normalized_value=normalized,
            kind=str(getattr(requirement, "query_extraction_kind", "") or kind),
        ))
        seen.add(normalized)
        if len(terms) >= MAX_EXACT_TERMS:
            break
    return tuple(terms)


def _filter_spec(filters: Mapping[str, Any] | None) -> FilterSpec:
    filters = filters or {}

    def text(name: str) -> str | None:
        value = filters.get(name)
        return str(value).strip()[:240] if isinstance(value, (str, int)) and str(value).strip() else None

    def texts(name: str) -> tuple[str, ...]:
        value = filters.get(name)
        if isinstance(value, Mapping) and "in" in value:
            value = value.get("in")
        if isinstance(value, str):
            return (value[:240],)
        if isinstance(value, (list, tuple, set, frozenset)):
            normalized = {
                str(item).strip()[:240] for item in value if str(item).strip()
            }
            return tuple(sorted(normalized))[:16]
        return ()

    return FilterSpec(
        project_identity=text("project_identity"),
        project_doc_path=text("project_doc_path"),
        library_id=text("library_id"),
        resolved_version=text("resolved_version"),
        version_family=text("version_family"),
        source_classes=texts("source_class") or texts("source_classes"),
        minimum_authority=text("minimum_authority"),
        module_ids=texts("module_id") or texts("module_ids"),
        doc_scopes=texts("doc_scope") or texts("doc_scopes"),
        lifecycle_statuses=(
            texts("lifecycle_status")
            or texts("lifecycle_statuses")
            or texts("project_doc_lifecycle_status")
        ),
        temporal_relevance=texts("temporal_relevance"),
        index_freshness=texts("index_freshness"),
        exact_snapshot_required=_strict_bool(filters.get("exact_snapshot_required", False)),
        forbidden_sources=texts("forbidden_sources"),
    )


def compile_backend_filters(filters: Mapping[str, Any] | None) -> dict[str, Any]:
    """Compile the public filter vocabulary to backend-positive predicates.

    Negative source predicates are deliberately enforced by the dispatcher after
    every lane; neither sqlite-vec nor all supported Qdrant versions expose the
    same portable negative-filter contract.
    """
    raw = dict(filters or {})
    spec = _filter_spec(raw)
    for alias in (
        "source_classes", "module_ids", "doc_scopes", "minimum_authority",
        "lifecycle_statuses", "project_doc_lifecycle_status",
        "exact_snapshot_required", "forbidden_sources",
    ):
        raw.pop(alias, None)
    if spec.source_classes:
        raw["source_class"] = {"in": list(spec.source_classes)}
    if spec.module_ids:
        raw["module_id"] = {"in": list(spec.module_ids)}
    if spec.doc_scopes:
        raw["doc_scope"] = {"in": list(spec.doc_scopes)}
    if spec.lifecycle_statuses:
        raw["lifecycle_status"] = {"in": list(spec.lifecycle_statuses)}
    if spec.temporal_relevance:
        raw["temporal_relevance"] = {"in": list(spec.temporal_relevance)}
    if spec.index_freshness:
        raw["index_freshness"] = {"in": list(spec.index_freshness)}
    if spec.exact_snapshot_required:
        raw["docs_snapshot_exact"] = True
    if spec.minimum_authority:
        minimum = spec.minimum_authority.casefold().replace("-", "_")
        raw["authority"] = {"in": list(_AUTHORITY_MINIMUMS.get(minimum, ()))}
    return raw


def metadata_matches_filters(
    metadata: Mapping[str, Any],
    filters: Mapping[str, Any] | None,
    *,
    source: str = "",
) -> bool:
    """Defense-in-depth evaluator shared by lexical and vector results."""
    spec = _filter_spec(filters)
    values = dict(metadata)
    # Hydrated chunks retain source-owned project catalog metadata, while
    # vector payloads expose its normalized promoted filter field.
    values.setdefault("authority", values.get("project_doc_authority"))
    values.setdefault("project_doc_path", values.get("source_path"))
    values.setdefault(
        "lifecycle_status",
        values.get("project_doc_lifecycle_status") or "active",
    )
    values.setdefault(
        "temporal_relevance",
        "current" if str(values.get("lifecycle_status") or "active").casefold() in {"active", "current"} else "historical",
    )
    values.setdefault("index_freshness", "synchronized")
    values.setdefault("source", source)
    for key, expected in compile_backend_filters(filters).items():
        actual = values.get(key)
        if isinstance(expected, Mapping) and "in" in expected:
            if actual not in expected["in"]:
                return False
        elif isinstance(expected, (list, tuple, set, frozenset)):
            if actual not in expected:
                return False
        elif isinstance(expected, bool):
            if _strict_bool(actual) != expected:
                return False
        elif actual != expected:
            return False
    forbidden = {item.strip().casefold() for item in spec.forbidden_sources if item.strip()}
    identities = {
        str(source or "").strip().casefold(),
        str(values.get("source") or "").strip().casefold(),
        str(values.get("source_identity") or "").strip().casefold(),
        str(values.get("canonical_url") or "").strip().casefold(),
        str(values.get("source_url") or "").strip().casefold(),
        str(values.get("library_id") or "").strip().casefold(),
        str(values.get("canonical_id") or "").strip().casefold(),
        str(values.get("path") or "").strip().casefold(),
        str(values.get("project_doc_path") or "").strip().casefold(),
        str(values.get("source_path") or "").strip().casefold(),
    }
    return not bool(forbidden.intersection(identities))


def build_query_plan(
    query: str,
    *,
    filters: Mapping[str, Any] | None = None,
    requested_lanes: tuple[str, ...] = ("lexical",),
    requirements: Any | None = None,
) -> QueryPlan:
    # Requirements can carry inferred expected values; only literal query
    # syntax supplies exact retrieval constraints. Their hash remains bound.
    exact_terms = extract_exact_terms(query)
    concepts = _concept_queries(query, exact_terms)[:MAX_CONCEPT_QUERIES]
    filter_spec = _filter_spec(filters)
    executed_filters_hash = canonical_hash(_canonical_filter_value(filters or {}))
    original_hash = hashlib.sha256(query.encode("utf-8")).hexdigest()
    requirements_hash = str(getattr(requirements, "requirements_hash", ""))
    payload = {
        "schema_version": QUERY_PLAN_SCHEMA_VERSION,
        "original_query_hash": original_hash,
        "exact_terms": [asdict(term) for term in exact_terms],
        "concept_queries": list(concepts),
        "filters": asdict(filter_spec),
        "executed_filters_hash": executed_filters_hash,
        "requested_lanes": list(requested_lanes),
        "requirements_hash": requirements_hash,
    }
    return QueryPlan(
        original_query_hash=original_hash,
        exact_terms=exact_terms,
        concept_queries=concepts,
        filters=filter_spec,
        requested_lanes=requested_lanes,
        executed_filters_hash=executed_filters_hash,
        plan_hash=canonical_hash(payload),
        requirements_hash=requirements_hash,
        requirements=requirements,
    )


__all__ = [
    "MAX_CONCEPT_QUERIES",
    "MAX_EXACT_TERMS",
    "MAX_DOCUMENT_LOCATOR_CHARS",
    "QUERY_PLAN_SCHEMA_VERSION",
    "build_query_plan",
    "compile_backend_filters",
    "extract_document_locator",
    "extract_exact_terms",
    "metadata_matches_filters",
]
