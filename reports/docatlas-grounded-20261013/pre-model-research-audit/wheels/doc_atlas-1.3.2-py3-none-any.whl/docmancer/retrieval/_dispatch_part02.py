"""RetrievalDispatcher implementation shard 2."""
from __future__ import annotations

from ._dispatch_shared import *  # noqa: F401,F403


class _RetrievalDispatcherPart02:
    def _fan_out(
        self,
        *,
        query: str,
        mode: str,
        per_source_limit: int,
        filters: dict | None,
        verification_filters: dict | None,
    ) -> tuple[dict[str, list[Any]], dict[str, int], dict[str, str]]:
        from .dense import dense_search
        from .lexical import lexical_search
        from .sparse import sparse_search

        jobs: dict[str, Any] = {}
        # Backends may score a wider internal window, but only the first
        # verified ``per_source_limit`` hits enter the candidate lane. This is
        # required for sqlite-vec, which cannot push metadata predicates down.
        vector_scoring_limit = min(160, max(40, per_source_limit * 4))
        if mode == "hybrid":
            jobs["lexical"] = lambda: lexical_search(
                self.store, query, limit=min(40, per_source_limit), budget=10_000, filters=filters
            )
            jobs["dense"] = lambda: dense_search(
                vector_store=self.vector_store, provider=self.provider,
                collection=self.collection, query=query,
                limit=vector_scoring_limit, filters=filters,
            )
            if self._sparse_supported():
                jobs["sparse"] = lambda: sparse_search(
                    vector_store=self.vector_store, provider=self.provider,
                    collection=self.collection, query=query,
                    limit=vector_scoring_limit, filters=filters,
                )
        elif mode == "dense":
            jobs["dense"] = lambda: dense_search(
                vector_store=self.vector_store, provider=self.provider,
                collection=self.collection, query=query,
                limit=vector_scoring_limit, filters=filters,
            )
        elif mode == "sparse":
            jobs["sparse"] = lambda: sparse_search(
                vector_store=self.vector_store, provider=self.provider,
                collection=self.collection, query=query,
                limit=vector_scoring_limit, filters=filters,
            )
        else:
            return {}, {}, {}

        can_parallelize = bool(
            len(jobs) > 1
            and getattr(self.vector_store, "supports_concurrent_queries", True)
        )
        if can_parallelize:
            with ThreadPoolExecutor(max_workers=len(jobs)) as executor:
                outcomes = {
                    source: executor.submit(job)
                    for source, job in jobs.items()
                }
                resolved = {
                    source: future.result
                    for source, future in outcomes.items()
                }
        else:
            resolved = jobs

        candidate_lists: dict[str, list[Any]] = {}
        counts: dict[str, int] = {}
        failures: dict[str, str] = {}
        for source, resolve in resolved.items():
            try:
                hits = resolve()
            except Exception as exc:
                logger.warning("retrieval source %s failed (%s)", source, type(exc).__name__)
                failures[source] = f"{type(exc).__name__}: <redacted diagnostic text>"
                hits = []
            if not hits:
                counts[source] = 0
                continue
            if source == "lexical":
                hits = self._filter_chunks(hits, verification_filters)
            else:
                hits = [
                    hit for hit in hits
                    if metadata_matches_filters(
                        getattr(hit, "payload", {}) or {},
                        verification_filters,
                        source=str((getattr(hit, "payload", {}) or {}).get("source") or ""),
                    )
                ][:per_source_limit]
            shaped = _shape_for_fusion(source, hits)
            if shaped:
                candidate_lists[source] = shaped
                counts[source] = len(shaped)
        return candidate_lists, counts, failures

    def _sparse_supported(self) -> bool:
        if self.vector_store is None or not self.collection:
            return False
        metadata_fn = getattr(self.vector_store, "collection_metadata", None)
        if not callable(metadata_fn):
            return bool(self._sidecar_collection_metadata().get("sparse_model"))
        try:
            metadata = metadata_fn(self.collection)
        except Exception:
            return False
        if metadata is None:
            return bool(self._sidecar_collection_metadata().get("sparse_model"))
        return bool(metadata.get("sparse_model"))

    def _hydrate(self, section_ids: list[int], *, budget: int) -> list:
        if not section_ids:
            return []
        return self.store.fetch_sections_by_id(section_ids, budget=budget)

    def _filter_section_ids_before_hydration(
        self, section_ids: list[int], filters: dict | None,
    ) -> list[int]:
        if not section_ids or not filters:
            return section_ids
        metadata_for = getattr(self.store, "section_filter_metadata_for", None)
        if not callable(metadata_for):
            # Compatibility stores still retain the post-hydration policy check.
            return section_ids
        try:
            metadata_by_id = metadata_for(section_ids)
        except Exception as exc:
            logger.warning(
                "pre-hydration source-policy metadata failed (%s)",
                type(exc).__name__,
            )
            return []
        return [
            section_id
            for section_id in section_ids
            if (metadata := metadata_by_id.get(int(section_id))) is not None
            and metadata_matches_filters(
                metadata, filters, source=str(metadata.get("source") or ""),
            )
        ]

    def _hydrate_policy_filtered(
        self, section_ids: list[int], *, budget: int, filters: dict | None,
    ) -> list:
        return self._hydrate(
            self._filter_section_ids_before_hydration(section_ids, filters),
            budget=budget,
        )

    def _candidate_limit_for_diversity(self, limit: int, expand: str | None) -> int:
        if (expand or "").lower() in {"adjacent", "page"}:
            return limit
        # Bounded reserve for policy exclusions after backend search, independent
        # of document identity or the retired per-source diversity setting.
        return max(limit * 3, limit + 6)

    def _limit_sections_per_source(
        self,
        chunks: list[Any],
        *,
        limit: int | None = None,
        expand: str | None = None,
    ) -> list[Any]:
        if (expand or "").lower() in {"adjacent", "page"}:
            return chunks
        # Source identity is an access/provenance constraint, not a diversity
        # quota. Preserve the native (or fused) rank under the global bound.
        return chunks[:limit] if limit is not None else chunks

    @staticmethod
    def _filter_chunks(chunks: list[Any], filters: dict | None) -> list[Any]:
        if not filters:
            return chunks
        return [
            chunk for chunk in chunks
            if metadata_matches_filters(
                getattr(chunk, "metadata", {}) or {},
                filters,
                source=str(getattr(chunk, "source", "") or ""),
            )
        ]

    def _append_api_term_matches(
        self,
        query: str,
        chunks: list[Any],
        *,
        budget: int,
        expand: str | None = None,
        backend_filters: dict | None = None,
        verification_filters: dict | None = None,
    ) -> list[Any]:
        # Literal anchors remain constraints, not extra executable searches.
        return self._filter_chunks(chunks, verification_filters)

    def _degraded_mode_name(self, mode: str, candidate_lists: dict[str, list[Any]], failures: dict[str, str]) -> str:
        if not failures:
            return mode
        if not candidate_lists:
            return f"{mode}/lexical_fallback_degraded"
        signals = "_".join(sorted(candidate_lists.keys()))
        return f"{mode}/{signals}_degraded"
