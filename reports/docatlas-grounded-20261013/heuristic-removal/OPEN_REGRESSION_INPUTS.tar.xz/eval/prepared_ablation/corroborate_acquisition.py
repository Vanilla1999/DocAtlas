"""Offline source-bound corroboration where stage capture omits whole-file hash.

Never fills missing receipt fields: reports independent published snapshot/hash,
absolute-source hash and exact span/text hash checks as additional evidence.
"""
import hashlib
import json
from pathlib import Path

from eval.prepared_ablation.run import REPO, REPORT, save


def sha(data):
    return hashlib.sha256(data).hexdigest()


def corroborate(case_id, family, relative, first, last):
    prep_path = REPORT / 'attempt-01/preparation' / f'{family}.json'
    prep = json.loads(prep_path.read_text())
    source_path = REPO / 'eval/prepared_model_comparison40/sources' / family / relative
    raw = source_path.read_bytes()
    text = raw.decode()
    source = next(r for r in prep['snapshot_sources'] if r['path']==relative)
    if source['content_sha256'] != sha(raw) or not source['matches_pinned_source']:
        raise ValueError('independent snapshot verification failed')
    offsets = [0]
    for line in text.splitlines(keepends=True):
        offsets.append(offsets[-1]+len(line))
    target_start, target_end = offsets[first-1], offsets[last]
    acquisition_path = REPORT / 'attempt-01/calls' / case_id / 'V0/acquisition.json'
    acquisition = json.loads(acquisition_path.read_text())
    expected_source_sha = sha((str(Path(prep['root']) / relative)).encode())
    expected_identity = 'project_file:local:' + sha(prep['root'].encode()) + ':' + relative
    events = []
    for index, event in enumerate(acquisition['events']):
        matches, invalid = [], []
        for position, row in enumerate(event['rows'], 1):
            if row['source_sha256'] != expected_source_sha or row['source_identity'] != expected_identity:
                continue
            span = row.get('char_span')
            if not isinstance(span, list) or len(span)!=2:
                invalid.append(position)
                continue
            a, b = span
            if not (type(a) is int and type(b) is int and 0 <= a < b <= len(text)
                    and sha(text[a:b].encode()) == row['text_sha256']):
                invalid.append(position)
                continue
            if min(b,target_end)>max(a,target_start):
                matches.append(dict(position=position, stable_chunk_id=row['stable_chunk_id'],
                    section_id=row['section_id'], char_span=span, ranking=row['ranking'],
                    overlap_characters=min(b,target_end)-max(a,target_start), text_sha256=row['text_sha256']))
        events.append(dict(index=index+1, stage=event['stage'], query_sha256=event['query_sha256'],
            details=event['details'], row_count=event['row_count'], omitted_rows=event['omitted_rows'],
            invalid_target_positions=invalid, verified_overlapping_rows=matches))
    return dict(case_id=case_id, independent_source_raw_sha256=sha(raw),
        original_capture_raw_hash_field='may be absent; unchanged',
        basis='published snapshot hash + exact original source identity/absolute-path hash + raw span/text SHA',
        input_hashes={str(prep_path):sha(prep_path.read_bytes()), str(source_path):sha(raw),
                      str(acquisition_path):sha(acquisition_path.read_bytes())},
        target=dict(path=relative, lines=[first,last], char_span=[target_start,target_end]), events=events,
        limits='bounded scored windows, not full FTS index; no new SQL/retrieval; uncaptured reference boundary remains unknown')


if __name__ == '__main__':
    save(REPORT / 'ACQUISITION_CORROBORATED.json', dict(cases=[
        corroborate('V40-T02', 'textual', 'docs/guide/reactivity.md', 66, 73),
        corroborate('V40-E01', 'eslint', 'docs/src/use/configure/configuration-files.md', 19, 30)]))
