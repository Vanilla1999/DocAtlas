"""Offline acquisition audit of saved receipts, without importing the product.

This table cannot reconstruct missing FTS rows or attribute an omission to a boost.
It deliberately consumes no oracle and does not invoke retrieval or a model.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import tarfile


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def analyze_capture(
    acquisition: Path, selection: Path, source: Path, canonical_path: str,
    line_start: int, line_end: int,
) -> dict:
    """Compare saved observations to one independently specified source window.

    Offline only. Paths/lines are analysis inputs, never retrieval/oracle inputs.
    Missing rows do not establish missing indexing or an unlimited FTS rank.
    """
    source_bytes = source.read_bytes()
    text = source_bytes.decode("utf-8")
    lines = text.splitlines(keepends=True)
    if not 1 <= line_start <= line_end <= len(lines):
        raise ValueError("Invalid inclusive source line range")
    source_hash = sha256(source_bytes)
    start = sum(map(len, lines[:line_start - 1]))
    end = start + sum(map(len, lines[line_start - 1:line_end]))
    acquisition_bytes = acquisition.read_bytes()
    selection_bytes = selection.read_bytes()
    capture = json.loads(acquisition_bytes)
    if capture.get("schema_version") != "acquisition-observation-v1":
        raise ValueError("Expected a direct capture_acquisition receipt")
    records = json.loads(selection_bytes)
    records = records if isinstance(records, list) else [records]

    def inspect_rows(rows: list, *, captured: bool) -> dict:
        matches = []
        intervals = []
        invalid = []
        unidentifiable = 0
        for position, row in enumerate(rows, start=1):
            metadata = row if captured else row.get("metadata", {})
            binding = {} if captured else row.get("binding", {})
            identity = str(metadata.get("source_identity") or binding.get("document_id") or "")
            path = "" if captured else str(row.get("path") or binding.get("canonical_path") or "")
            same_path = path == canonical_path or identity.endswith(":" + canonical_path)
            if not identity and not path:
                unidentifiable += 1
            if not same_path:
                continue
            actual_hash = str(metadata.get("source_content_hash") or binding.get("content_sha256") or "").removeprefix("sha256:")
            span = metadata.get("char_span") if captured else row.get("span", metadata.get("char_span"))
            snippet_hash = row.get("text_sha256")
            if not snippet_hash and not captured and isinstance(row.get("text"), str):
                snippet_hash = sha256(row["text"].encode())
            if actual_hash != source_hash:
                invalid.append({"position": position, "reason": "source_hash_mismatch_or_absent"})
                continue
            if not (isinstance(span, list) and len(span) == 2
                    and all(type(value) is int for value in span)
                    and 0 <= span[0] <= span[1] <= len(text)):
                invalid.append({"position": position, "reason": "invalid_or_absent_span"})
                continue
            if sha256(text[span[0]:span[1]].encode()) != snippet_hash:
                invalid.append({"position": position, "reason": "text_hash_mismatch_or_absent"})
                continue
            if not captured and row.get("text") != text[span[0]:span[1]]:
                invalid.append({"position": position, "reason": "candidate_text_slice_mismatch"})
                continue
            overlap_start, overlap_end = max(start, span[0]), min(end, span[1])
            if overlap_start >= overlap_end:
                continue
            intervals.append((overlap_start, overlap_end))
            ranking = metadata.get("ranking") or {}
            matches.append({
                "position_1based": position, "span": span,
                "text_sha256": snippet_hash,
                "overlap_characters": overlap_end - overlap_start,
                "covers_required_window": span[0] <= start and end <= span[1],
                "raw_rank": ranking.get("raw_rank"),
                "scored_rank": ranking.get("final_rank"),
                "ranking": ranking,
            })
        covered = 0
        cursor = start
        for left, right in sorted(intervals):
            left = max(cursor, left)
            if right > left:
                covered += right - left
                cursor = right
        return {
            "row_count": len(rows), "verified_overlapping_rows": matches,
            "covered_characters": covered, "required_characters": end - start,
            "full_window_covered": covered == end - start,
            "invalid_target_rows": invalid, "unidentifiable_rows": unidentifiable,
        }

    events = []
    occurrences: dict[str, int] = {}
    stages = set()
    for event_index, event in enumerate(capture.get("events", []), start=1):
        stage = str(event.get("stage") or "")
        stages.add(stage)
        occurrences[stage] = occurrences.get(stage, 0) + 1
        observed = inspect_rows(event.get("rows", []), captured=True)
        incomplete = bool(event.get("omitted_rows") or capture.get("omitted_events")
                          or capture.get("errors") or observed["invalid_target_rows"]
                          or observed["unidentifiable_rows"])
        absent = not observed["verified_overlapping_rows"]
        events.append({
            "event_index_1based": event_index,
            "stage": stage, "stage_occurrence_1based": occurrences[stage],
            "query_sha256": event.get("query_sha256"), "details": event.get("details", {}),
            "omitted_rows": event.get("omitted_rows", 0),
            "recorded_row_count": event.get("row_count"),
            "observation_incomplete": incomplete, **observed,
            "required_window_observation": (
                "absent_at_bounded_scored_window_not_unindexed"
                if stage == "sqlite.scored_window" and absent and not incomplete else
                "absence_unresolved_incomplete_observation" if absent and incomplete else
                "no_verified_overlap_at_observed_boundary" if absent else
                "verified_overlap_at_observed_boundary"
            ),
        })
    selection_results = []
    for record_index, record in enumerate(records):
        lanes = {}
        for name in ("complete_candidates", "pool"):
            if name in record:
                lanes[name] = inspect_rows(record[name], captured=False)
        pool = record.get("pool", [])
        selected_indices = record.get("selection", {}).get("selected_indices")
        if isinstance(selected_indices, list):
            if any(type(index) is not int or not 0 <= index < len(pool) for index in selected_indices):
                raise ValueError("Invalid selected_indices in saved receipt")
            lanes["selected"] = inspect_rows([pool[index] for index in selected_indices], captured=False)
        selection_results.append({
            "record_index": record_index, "boundaries": lanes,
            "absent_boundaries": sorted({"complete_candidates", "pool", "selected"} - lanes.keys()),
        })
    expected = {"sqlite.scored_window", "sqlite.emitted", "dispatcher.emitted",
                "reference.input", "reference.prepared"}
    return {
        "schema_version": "captured-acquisition-window-audit-v1",
        "inputs": {str(acquisition): sha256(acquisition_bytes),
                   str(selection): sha256(selection_bytes), str(source): source_hash},
        "required_window": {"canonical_path": canonical_path,
                            "line_span_inclusive": [line_start, line_end],
                            "char_span_half_open": [start, end],
                            "source_sha256": source_hash,
                            "text_sha256": sha256(text[start:end].encode())},
        "events": events, "selection": selection_results,
        "absent_boundaries": sorted(expected - stages),
        "reference_preparation_attribution": (
            "unresolved_absent_pre_or_post_reference_boundary"
            if not {"reference.input", "reference.prepared"}.issubset(stages)
            else "see_explicit_reference_events_no_implicit_lane_pairing"
        ),
        "capture_errors": capture.get("errors", []),
        "omitted_events": capture.get("omitted_events", 0),
        "limitations": ["scored_window_is_bounded_not_all_FTS_matches",
                        "absent_does_not_mean_unindexed",
                        "no_missing_child_raw_rank_can_be_reconstructed",
                        "root_read_lane_identity_not_recorded_unless_explicit_details",
                        "event_order_not_proof_of_reference_loss_without_boundary",
                        "source_span_delivery_not_semantic_sufficiency"],
        "product_calls": 0, "model_calls": 0,
    }


def audit_archive(archive: Path, sources: Path, cases: set[str]) -> dict:
    result = {
        "schema_version": "offline-acquisition-audit-v1",
        "archive": str(archive), "archive_sha256": sha256(archive.read_bytes()),
        "verified_candidate_rows": 0, "sources": {}, "summary": [], "rows": [],
        "missing_boundaries": ["unlimited_fts_matches", "omitted_scoring_rows",
                               "pre_reference_chunks", "read_lane_identity"],
        "product_calls": 0, "model_calls": 0,
    }
    cache = {}
    with tarfile.open(archive) as bundle:
        for member in sorted(bundle.getmembers(), key=lambda item: item.name):
            if not member.name.endswith("/budget/selection.json"):
                continue
            case = member.name.split("/")[1]
            stream = bundle.extractfile(member)
            if stream is None:
                raise ValueError(f"Unreadable receipt: {member.name}")
            raw = stream.read()
            records = json.loads(raw)
            records = records if isinstance(records, list) else [records]
            for record_index, record in enumerate(records):
                unique = set()
                scoring_sizes = set()
                for ordinal, candidate in enumerate(record["complete_candidates"]):
                    metadata = candidate["metadata"]
                    project = Path(metadata["project_path"]).name
                    path = sources / project / candidate["path"]
                    if path not in cache:
                        data = path.read_bytes()
                        cache[path] = (data.decode("utf-8"), sha256(data))
                    source, source_hash = cache[path]
                    start, end = candidate["span"]
                    text_hash = sha256(candidate["text"].encode())
                    if not (0 <= start <= end <= len(source)):
                        raise ValueError(f"Invalid span: {case}:{ordinal}")
                    if source[start:end] != candidate["text"]:
                        raise ValueError(f"Source slice mismatch: {case}:{ordinal}")
                    if source_hash != candidate["binding"]["content_sha256"]:
                        raise ValueError(f"Source hash mismatch: {case}:{ordinal}")
                    if text_hash != candidate["text_sha256"]:
                        raise ValueError(f"Text hash mismatch: {case}:{ordinal}")
                    result["verified_candidate_rows"] += 1
                    result["sources"][str(path)] = source_hash
                    identity = (candidate["binding"]["document_id"],
                                json.dumps(candidate["binding"]["scope"], sort_keys=True),
                                source_hash, start, end, text_hash)
                    duplicate = identity in unique
                    unique.add(identity)
                    ranking = metadata.get("ranking", {})
                    scoring_sizes.add(ranking.get("candidate_pool_size"))
                    if not cases or case in cases:
                        result["rows"].append({
                            "case": case, "record": record_index, "ordinal": ordinal,
                            "receipt": member.name, "receipt_sha256": sha256(raw),
                            "path": str(path), "source_sha256": source_hash,
                            "span": [start, end], "line_span": metadata.get("line_span"),
                            "text_sha256": text_hash, "duplicate": duplicate,
                            "parent": metadata.get("parent_logical_id"),
                            "ranking": ranking,
                            "retrieval_trace": metadata.get("retrieval_trace"),
                            "lexical_mode": metadata.get("lexical_match", {}).get("mode"),
                        })
                result["summary"].append({
                    "case": case, "record": record_index,
                    "receipt": member.name, "receipt_sha256": sha256(raw),
                    "complete_records": len(record["complete_candidates"]),
                    "unique_verified_windows": len(unique),
                    "checked_pool_records": len(record["pool"]),
                    "observed_scoring_window_sizes": sorted(
                        size for size in scoring_sizes if size is not None),
                })
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--archive", type=Path)
    mode.add_argument("--acquisition", type=Path)
    parser.add_argument("--sources", type=Path)
    parser.add_argument("--selection", type=Path)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--source-path")
    parser.add_argument("--line-start", type=int)
    parser.add_argument("--line-end", type=int)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", action="append", default=[])
    args = parser.parse_args()
    if args.archive:
        if args.sources is None:
            parser.error("--archive requires --sources")
        result = audit_archive(args.archive, args.sources, set(args.case))
    else:
        if any(value is None for value in (args.selection, args.source, args.source_path,
                                           args.line_start, args.line_end)):
            parser.error("--acquisition requires --selection --source --source-path --line-start --line-end")
        result = analyze_capture(args.acquisition, args.selection, args.source,
                                 args.source_path, args.line_start, args.line_end)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
