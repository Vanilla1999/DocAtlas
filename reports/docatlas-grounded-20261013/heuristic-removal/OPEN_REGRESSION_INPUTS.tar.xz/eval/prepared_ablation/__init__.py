"""Frozen sequential experimental comparison, separate from historical evaluators."""
