"""Offline exact delivery plus explicit semantic review; never executes retrieval.

The historical exact-span/source-validity functions are reused unchanged. The
holdout's semantic oracle is independent and is never consumed by the runner.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Any

from eval.prepared_model_comparison40 import evaluate as historical


DEFAULT_CORPUS = Path(__file__).resolve().parent / "holdout"


def normalize_markdown_for_review(text: str) -> str:
    """Newlines only; never case-fold, tokenize, or strip Markdown punctuation.

    `*`, `**`, `/`, `!`, `=`, `<`, `>`, underscores, quoted leading spaces,
    and upper/lower-case flag distinctions may themselves be evidence. Keep
    links/fences/table separators too. This view is NOT used for exact scoring.
    """
    return text.replace("\r\n", "\n")


def verify_freeze(corpus_dir: Path) -> dict[str, Any]:
    corpus_dir = Path(corpus_dir).resolve()
    manifest_path = corpus_dir / "FREEZE_MANIFEST.json"
    manifest = json.loads(manifest_path.read_bytes())
    repo = Path(__file__).resolve().parents[2]
    errors = []
    files = manifest.get("files_sha256", {})
    if not isinstance(files, dict) or not files:
        raise ValueError("Missing frozen file hashes")
    for relative, digest in files.items():
        path = PurePosixPath(relative)
        if path.is_absolute() or ".." in path.parts or not isinstance(digest, str) or not historical.HASH.fullmatch(digest):
            errors.append(f"invalid_freeze_entry:{relative}")
            continue
        try:
            actual = hashlib.sha256((repo / path).read_bytes()).hexdigest()
        except OSError:
            actual = None
        if actual != digest:
            errors.append(f"frozen_file_changed_or_missing:{relative}")
    required = [corpus_dir / name for name in (
        "questions.json", "gold_spans.json", "semantic_rubric.json", "source_plan.json",
        "source-manifest.json", "gold-span-audit.json")]
    required += [Path(__file__).resolve(), Path(historical.__file__).resolve()]
    for path in required:
        if path.relative_to(repo).as_posix() not in files:
            errors.append(f"required_input_not_frozen:{path.name}")
    source_files = {p.relative_to(repo).as_posix() for p in (corpus_dir / "sources").rglob("*") if p.is_file()}
    frozen_sources = {p for p in files if p.startswith(corpus_dir.relative_to(repo).as_posix() + "/sources/")}
    if source_files != frozen_sources:
        errors.append("source_file_set_differs_from_freeze")
    return dict(pass_=not errors, errors=errors, checked_files=len(files),
                manifest_sha256=hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
                frozen_before_outputs=manifest.get("outputs_seen") is False)


def semantic_review(case: dict, rubric: dict, exact: dict, payload: dict,
                    review: dict | None) -> dict[str, Any]:
    """Check provenance/completeness of a human decision, not its semantics.

    A structurally valid human judgment is identified as such, never as an
    automatically proved semantic result. Exact quote checks authenticate cited
    evidence; they do not decide entailment or whether a relation is preserved.
    """
    result = dict(verdict="needs_review", method="independent_human_required",
                  generated_answer_correctness="not_measured", errors=[],
                  required_facet_ids=[f["id"] for f in rubric["facets"]],
                  source_relevance="needs_review")
    if review is None:
        return result
    errors = result["errors"]
    if not isinstance(review, dict):
        errors.append("review_not_object")
        return result
    if review.get("case_id") != case["id"] or review.get("mode") != exact["mode"]:
        errors.append("review_identity_mismatch")
    if review.get("packet_sha256") != exact["artifacts"]["public-payload.json"].get("sha256"):
        errors.append("review_packet_hash_mismatch")
    for key in ("reviewer", "reviewed_at_utc", "rationale"):
        if not isinstance(review.get(key), str) or not review[key].strip():
            errors.append(f"review_{key}_missing")
    if review.get("relations_conditions_negation_checked") is not True:
        errors.append("relations_conditions_negation_not_reviewed")
    verdict = review.get("verdict")
    if verdict not in ("pass", "fail", "needs_review"):
        errors.append("invalid_semantic_verdict")
    facets = review.get("facets")
    if not isinstance(facets, list) or not all(isinstance(f, dict) for f in facets):
        errors.append("review_facets_not_object_list")
        facets = []
    by_id = {f.get("facet_id"): f for f in facets if isinstance(f.get("facet_id"), str)}
    if len(by_id) != len(facets) or set(by_id) != set(result["required_facet_ids"]):
        errors.append("review_facet_set_incomplete_or_duplicate")
    public_sources = payload.get("sources", [])
    if not isinstance(public_sources, list):
        public_sources = []
    sources = {s["evidence_id"]: s for s in public_sources
               if isinstance(s, dict) and isinstance(s.get("evidence_id"), str)}
    valid_ids = {s["evidence_id"] for s in exact["source_integrity"] if s["integrity_pass"]}
    for frozen_facet in rubric["facets"]:
        facet = by_id.get(frozen_facet["id"], {})
        if not isinstance(facet.get("rationale"), str) or not facet["rationale"].strip():
            errors.append(f"facet_rationale_missing:{frozen_facet['id']}")
        assessment = facet.get("assessment")
        permitted = ("supported", "missing", "needs_review") if frozen_facet["kind"] == "documented" else ("unavailable_in_closed_corpus", "unsupported_claim", "needs_review")
        if assessment not in permitted:
            errors.append(f"invalid_facet_assessment:{frozen_facet['id']}")
        expected = "supported" if frozen_facet["kind"] == "documented" else "unavailable_in_closed_corpus"
        if verdict == "pass" and assessment != expected:
            errors.append(f"pass_with_unsatisfied_facet:{frozen_facet['id']}")
        evidence = facet.get("evidence", [])
        if not isinstance(evidence, list):
            errors.append("facet_evidence_not_list")
            evidence = []
        if assessment == "supported" and not evidence:
            errors.append(f"supported_without_citation:{frozen_facet['id']}")
        for citation in evidence:
            if not isinstance(citation, dict):
                errors.append("citation_not_object")
                continue
            evidence_id, quote = citation.get("evidence_id"), citation.get("quote")
            if not isinstance(evidence_id, str):
                errors.append("citation_evidence_id_not_string")
                continue
            source = sources.get(evidence_id, {})
            if evidence_id not in valid_ids:
                errors.append(f"citation_not_verified_public_evidence:{evidence_id}")
            snippet = source.get("snippet")
            if not isinstance(quote, str) or not quote.strip() or not isinstance(snippet, str) or quote not in snippet:
                errors.append(f"citation_quote_not_exact_selected_text:{evidence_id}")
            if not isinstance(citation.get("relation"), str) or not citation["relation"].strip():
                errors.append(f"citation_entailment_explanation_missing:{evidence_id}")
    relevance = review.get("source_relevance")
    if not isinstance(relevance, list) or not all(isinstance(r, dict) for r in relevance):
        errors.append("source_relevance_not_object_list")
        relevance = []
    relevance_ids = [r.get("evidence_id") for r in relevance]
    if (not all(isinstance(i, str) for i in relevance_ids)
            or len(set(relevance_ids)) != len(relevance_ids) or set(relevance_ids) != set(sources)):
        errors.append("source_relevance_review_incomplete")
    for row in relevance:
        if row.get("assessment") not in ("relevant", "irrelevant", "needs_review") or not row.get("rationale"):
            errors.append("invalid_source_relevance_review")
    if not exact["valid_public_call_and_integrity"]:
        errors.append("public_call_or_source_integrity_invalid")
    if not errors:
        result.update(verdict=verdict, method="recorded_independent_human_judgment",
                      source_relevance=relevance, review=review)
    return result


def evaluate(run_dir: Path, corpus_dir: Path = DEFAULT_CORPUS,
             modes: tuple[str, ...] | None = None, review_path: Path | None = None) -> dict[str, Any]:
    run_dir, corpus_dir = Path(run_dir).resolve(), Path(corpus_dir).resolve()
    frozen = verify_freeze(corpus_dir)
    if not frozen["pass_"] or not frozen["frozen_before_outputs"]:
        raise ValueError("Holdout freeze invalid: " + repr(frozen))
    cases = json.loads((corpus_dir / "questions.json").read_bytes())["cases"]
    oracles = {c["id"]: c for c in json.loads((corpus_dir / "gold_spans.json").read_bytes())["cases"]}
    rubrics = {c["id"]: c for c in json.loads((corpus_dir / "semantic_rubric.json").read_bytes())["cases"]}
    if len(cases) != 20 or len({c["id"] for c in cases}) != 20 or set(oracles) != set(rubrics) or set(oracles) != {c["id"] for c in cases}:
        raise ValueError("Holdout must contain 20 matching unique IDs")
    if Counter(c["answerability"] for c in cases) != {"within_budget": 8, "partial": 6, "unanswerable": 6}:
        raise ValueError("Holdout design must remain 8/6/6")
    manifest = json.loads((run_dir / "RUN_MANIFEST.json").read_bytes())
    if manifest.get("holdout_freeze_manifest_sha256") != frozen["manifest_sha256"]:
        raise ValueError("Runner did not bind this holdout freeze")
    if manifest.get("question_count") != 20:
        raise ValueError("Runner question count differs")
    arms = modes if modes is not None else tuple(manifest.get("arms", []))
    if not arms or len(set(arms)) != len(arms) or list(arms) != manifest.get("arms"):
        raise ValueError("Explicit arm list must match frozen runner arms")
    if any(not isinstance(a, str) or not a or PurePosixPath(a).name != a or a in (".", "..") for a in arms):
        raise ValueError("Invalid arm path segment")
    review_rows = [] if review_path is None else json.loads(Path(review_path).read_bytes())["reviews"]
    review_keys = [(r["case_id"], r["mode"]) for r in review_rows]
    if len(set(review_keys)) != len(review_keys) or any(key not in {(c["id"], a) for c in cases for a in arms} for key in review_keys):
        raise ValueError("Duplicate or unknown semantic review identity")
    reviews = dict(zip(review_keys, review_rows))
    groups = {g: historical._prepare(g, run_dir, corpus_dir) for g in sorted({c["project_group"] for c in cases})}
    rows = []
    for case in cases:
        for arm in arms:
            row = historical._case(case, oracles[case["id"]], arm, run_dir,
                                   groups[case["project_group"]], manifest.get("final_json_cap"))
            packet = run_dir / "calls" / case["id"] / arm / "public-payload.json"
            try:
                payload = json.loads(packet.read_bytes())
            except (OSError, ValueError):
                payload = {}
            if not isinstance(payload, dict):
                payload = {}
            row["semantic_review"] = semantic_review(case, rubrics[case["id"]], row, payload,
                                                      reviews.get((case["id"], arm)))
            rows.append(row)
    return dict(schema_version=1, corpus="new_closed_H20", freeze=frozen,
                measurement=historical.MEASUREMENT,
                holdout_design=dict(positive=8, partial=6, negative=6, families=4),
                historical_exact_evaluator_unchanged=True,
                semantic_method="Explicit independent review; quote membership authenticates citations only.",
                generated_answer_correctness="not_measured", cases=rows,
                summary={a: dict(exact_positive=sum(r["strict_positive_pass"] is True for r in rows if r["mode"] == a),
                                 exact_partial=sum(r["strict_partial_documented_pass"] is True for r in rows if r["mode"] == a),
                                 exact_negative=sum(r["strict_empty_source_pass"] is True for r in rows if r["mode"] == a),
                                 semantic=dict(Counter(r["semantic_review"]["verdict"] for r in rows if r["mode"] == a))) for a in arms})


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--corpus-dir", type=Path, default=DEFAULT_CORPUS)
    parser.add_argument("--reviews", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("Never overwrite an evaluation artifact")
    result = evaluate(args.run_dir, args.corpus_dir, review_path=args.reviews)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
