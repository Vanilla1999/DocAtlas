"""Offline native stage coverage using unchanged historical witness semantics."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from eval.prepared_model_comparison40.evaluate import _gold, _relative, _source_rows


def prepared_sources(preparation, dataset, family):
    sources = {}
    snapshots = {row['path']: row for row in preparation['snapshot_sources']}
    for path in (dataset / 'sources' / family).rglob('*'):
        if not path.is_file():
            continue
        relative = path.relative_to(dataset / 'sources' / family).as_posix()
        raw = path.read_bytes()
        content = raw.decode()
        offsets = [0]
        for line in content.splitlines(keepends=True):
            offsets.append(offsets[-1] + len(line))
        digest = hashlib.sha256(raw).hexdigest()
        snapshot = snapshots.get(relative, {})
        errors = []
        if snapshot.get('content_sha256') != digest or not snapshot.get('matches_pinned_source'):
            errors.append('raw_snapshot_mismatch')
        sources[relative] = dict(content=content, raw=raw, line_offsets=offsets,
                                 sha256=digest, errors=errors)
    return dict(root=preparation['root'], sources=sources)


def candidate_intervals(candidates, prepared):
    intervals, errors = {}, []
    for candidate in candidates:
        relative = _relative(candidate.get('path'), prepared['root'])
        source = prepared['sources'].get(relative)
        start, end = candidate.get('span', [None, None])
        if (source is None or type(start) is not int or type(end) is not int
                or not 0 <= start < end <= len(source['content'])
                or candidate.get('text') != source['content'][start:end]):
            errors.append(dict(id=candidate.get('id'), error='native_span_not_exact_raw'))
            continue
        intervals.setdefault(relative, []).append((start, end))
    return intervals, errors


def analyze(call_path: Path, preparation, dataset, case, oracle):
    prepared = prepared_sources(preparation, dataset, case['project_group'])
    payload = json.loads((call_path / 'public-payload.json').read_text())
    receipts = json.loads((call_path / 'selection.json').read_text())
    result = dict(case_id=case['id'], variant=call_path.name,
                  measure='raw character witness coverage, not semantic entailment',
                  selector_receipt_count=len(receipts), stages={})
    for stage in ('complete_candidates', 'pool', 'selected'):
        candidates = []
        for receipt in receipts:
            if stage == 'selected':
                candidates.extend(receipt['pool'][index] for index in
                                  receipt['selection'].get('selected_indices', []))
            else:
                candidates.extend(receipt.get(stage, []))
        intervals, errors = candidate_intervals(candidates, prepared)
        coverage = _gold(case, oracle, prepared, intervals)
        result['stages'][stage] = dict(coverage=coverage, errors=errors,
            candidates=len(candidates), unique_windows=len({(
                c.get('path'), tuple(c.get('span', [])), c.get('text_sha256')) for c in candidates}))
    _, intervals, errors = _source_rows(payload, prepared)
    result['stages']['public'] = dict(coverage=_gold(case, oracle, prepared, intervals), errors=errors)
    return result
