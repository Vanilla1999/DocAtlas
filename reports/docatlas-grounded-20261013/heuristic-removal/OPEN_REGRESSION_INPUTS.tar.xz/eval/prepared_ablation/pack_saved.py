"""Post-run adapter correction for explicit refused packets with omitted sources.

No product execution, rewritten payload or oracle. Original frozen adapter failure
and raw packets remain. Missing sources is allowed only on context-unavailable DTO.
"""
import argparse
import json
from pathlib import Path

from eval.prepared_ablation.comparator import OfflineTokenizer, native_evidence, pack_evidence
from eval.prepared_ablation.run import REPORT, save


def pack_saved(run_dir, output):
    tokenizer = OfflineTokenizer(REPORT / 'E/raw/o200k_base.tiktoken')
    records = []
    for path in sorted(run_dir.glob('calls/*/*/public-payload.json')):
        destination = output / path.parent.parent.name / f'{path.parent.name}.json'
        if destination.exists():
            continue
        payload = json.loads(path.read_bytes())
        missing = 'sources' not in payload
        if missing:
            if payload.get('kind') != 'docs_context' or payload.get('context_available') is not False:
                raise ValueError('missing sources outside explicit context-unavailable packet')
            evidence = dict(native_metadata=payload, sources=[])
        else:
            evidence = native_evidence('docatlas', payload)
        save(destination, pack_evidence(evidence, tokenizer))
        records.append(dict(path=str(path), packed=str(destination), explicit_empty_adapter=missing))
    save(REPORT / 'POSTPROCESSING_RECEIPT.json', dict(records=records, product_calls=0,
         reason='frozen adapter refused omitted sources on explicit context-unavailable DTO',
         policy='remaining saved packets only, unchanged text/attribution, identical tokenizer/cap/prefix'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    pack_saved(args.run_dir, args.output)
