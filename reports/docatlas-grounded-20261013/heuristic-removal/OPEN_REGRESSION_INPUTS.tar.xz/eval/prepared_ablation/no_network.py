#!/usr/bin/python3.12
"""OS seccomp launcher for the frozen Grounded Node CLI; no network sockets."""
import ctypes
import ctypes.util
import os
import sys


def restrict_network():
    library = ctypes.util.find_library('seccomp')
    if not library:
        raise RuntimeError('libseccomp unavailable; refuse unsandboxed comparator')
    seccomp = ctypes.CDLL(library, use_errno=True)
    seccomp.seccomp_init.argtypes = [ctypes.c_uint32]
    seccomp.seccomp_init.restype = ctypes.c_void_p
    seccomp.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    seccomp.seccomp_syscall_resolve_name.restype = ctypes.c_int
    seccomp.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    seccomp.seccomp_rule_add.restype = ctypes.c_int
    seccomp.seccomp_load.argtypes = [ctypes.c_void_p]
    seccomp.seccomp_load.restype = ctypes.c_int
    seccomp.seccomp_release.argtypes = [ctypes.c_void_p]
    context = seccomp.seccomp_init(0x7fff0000)  # SCMP_ACT_ALLOW
    if not context:
        raise RuntimeError('seccomp initialization failed')
    try:
        for name in (b'socket', b'connect', b'bind', b'listen', b'accept', b'accept4',
                     b'sendto', b'sendmsg', b'sendmmsg', b'socketcall'):
            number = seccomp.seccomp_syscall_resolve_name(name)
            if number >= 0 and seccomp.seccomp_rule_add(context, 0x00050001, number, 0) != 0:
                raise RuntimeError('seccomp deny rule failed')
        if seccomp.seccomp_load(context) != 0:
            raise RuntimeError('seccomp load failed')
    finally:
        seccomp.seccomp_release(context)


if __name__ == '__main__':
    restrict_network()
    node = '/home/viadmin/.nvm/versions/node/v22.22.2/bin/node'
    os.execv(node, [node, *sys.argv[1:]])
