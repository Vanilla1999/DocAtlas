"""Single sequential isolated Grounded workload and common evidence packaging."""
import argparse
import hashlib
import json
from pathlib import Path
import time

from eval.prepared_ablation.comparator import (
    CorpusFile, GroundedAdapter, OfflineTokenizer, native_evidence, pack_evidence,
)
from eval.prepared_ablation.run import REPO, REPORT, ledger, load_dataset, save


def run(args):
    manifest = json.loads(args.manifest.read_text())
    config = manifest['config']
    tokenizer = OfflineTokenizer(REPORT / 'E/raw/o200k_base.tiktoken')
    if args.output.exists():
        raise ValueError('fresh comparator output required')
    args.output.mkdir(parents=True)
    summary = dict(calls=0, preparations=0, status='running', records=[])
    started = time.perf_counter()
    try:
        for index, relative in enumerate(config['datasets']):
            dataset = REPO / relative
            cases, families = load_dataset(dataset)
            for family in families:
                group = f'{index}-{family["id"]}'
                adapter = GroundedAdapter(Path(config['grounded']['package_root']),
                    REPO / 'eval/prepared_ablation/no_network.py', args.output / 'families' / group)
                corpus_root = dataset / 'sources' / family['id']
                inventory = [CorpusFile(path, hashlib.sha256((corpus_root / path).read_bytes()).hexdigest())
                             for path in family['paths']]
                ledger(REPORT / 'EXECUTION_LEDGER.jsonl', 'grounded_prepare', 'started',
                       family=group, ingest_cli_calls=len(inventory), sandbox='seccomp socket deny')
                preparation = adapter.prepare(corpus_root, inventory, f'experiment-{group}')
                summary['preparations'] += len(inventory)
                save(args.output / 'preparation' / f'{group}.json', preparation)
                ledger(REPORT / 'EXECUTION_LEDGER.jsonl', 'grounded_prepare', 'returned', family=group,
                       ingest_cli_calls=len(inventory))
                for case in cases:
                    if case['project_group'] != family['id']:
                        continue
                    if summary['calls'] >= 60 or time.perf_counter()-started > 1800:
                        raise RuntimeError('frozen comparator call/wall ceiling')
                    summary['calls'] += 1
                    ledger(REPORT / 'EXECUTION_LEDGER.jsonl', 'grounded_search', 'started', case_id=case['id'])
                    result = adapter.query(case['question'], case['id'], limit=5)
                    destination = args.output / 'calls' / case['id']
                    save(destination / 'native.json', result)
                    if result['payload'] is not None:
                        packed = pack_evidence(native_evidence('grounded', result['payload']), tokenizer)
                        save(destination / 'packed.json', packed)
                    summary['records'].append(dict(case_id=case['id'], family=group,
                        status=result['status'], seconds=result['receipt']['seconds']))
                    ledger(REPORT / 'EXECUTION_LEDGER.jsonl', 'grounded_search', result['status'],
                           case_id=case['id'], seconds=result['receipt']['seconds'])
                    save(args.output / 'SUMMARY.json', summary)
                    print(json.dumps(summary['records'][-1]), flush=True)
        summary['status'] = 'completed'
    except Exception as exc:
        summary.update(status='blocked', error_type=type(exc).__name__, error=str(exc))
        ledger(REPORT / 'EXECUTION_LEDGER.jsonl', 'grounded_workload', 'blocked', error=str(exc))
    finally:
        summary['seconds'] = time.perf_counter()-started
        save(args.output / 'SUMMARY.json', summary)
    # Packing is offline, no extra DocAtlas calls and no query/gold-dependent crop.
    for path in sorted(args.docatlas.glob('calls/*/*/public-payload.json')):
        payload = json.loads(path.read_text())
        packed = pack_evidence(native_evidence('docatlas', payload), tokenizer)
        save(args.output / 'docatlas-packed' / path.parent.parent.name / f'{path.parent.name}.json', packed)
    return 0 if summary['status'] == 'completed' else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--docatlas', required=True, type=Path)
    args = parser.parse_args()
    raise SystemExit(run(args))
