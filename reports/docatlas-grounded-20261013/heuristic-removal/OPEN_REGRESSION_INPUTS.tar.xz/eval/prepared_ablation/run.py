"""Single sequential public-API runner; questions and sources, never oracle, enter runtime."""
from __future__ import annotations

import argparse
from contextlib import ExitStack, redirect_stderr
from copy import deepcopy
import io
import json
import os
from pathlib import Path
import resource
import subprocess
import time
import traceback

from eval.prepared_model_comparison40.run import (
    canonical, committed_sources, logical_state, now, save, sha, source_state,
    time_limit, versions,
)

REPO = Path(__file__).resolve().parents[2]
REPORT = REPO / 'reports/admission-experiments/prepared-retrieval/multiagent-20261013'


def ledger(path, operation, status, **fields):
    with path.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(dict(at_utc=now(), operation=operation, status=status,
                                     **fields), ensure_ascii=False) + '\n')
        handle.flush()
        os.fsync(handle.fileno())


def load_dataset(path):
    cases = json.loads((path / 'questions.json').read_text())['cases']
    families = json.loads((path / 'source_plan.json').read_text())['families']
    return cases, families


def freeze(config_path, output):
    config_path = config_path.resolve()
    inputs = {}
    for directory in ('docmancer', 'eval/prepared_ablation', 'eval/prepared_model_comparison40'):
        for path in sorted((REPO / directory).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                inputs[path.relative_to(REPO).as_posix()] = sha(path.read_bytes())
    for relative in ('pyproject.toml', 'eval/evidence_quality_v2/runtime.py',
                     'tests/test_prepared_ablation_integration.py',
                     'tests/test_prepared_retrieval_integration.py',
                     'tests/test_named_document_context_integration.py'):
        inputs[relative] = sha((REPO / relative).read_bytes())
    for path in (REPO / 'tests').glob('diagnostic_labels*.json'):
        inputs[path.relative_to(REPO).as_posix()] = sha(path.read_bytes())
    for name in ('PROTOCOL.md', 'CONTRACT_DECISIONS.md', 'OWNERSHIP.md', 'ENVIRONMENT.txt'):
        path = REPORT / name
        inputs[path.relative_to(REPO).as_posix()] = sha(path.read_bytes())
    config = json.loads(config_path.read_text())
    inputs[config_path.relative_to(REPO).as_posix()] = sha(config_path.read_bytes())
    package = Path(config['grounded']['package_root'])
    external = {str(p): sha(p.read_bytes()) for p in (
        package / 'package.json', package / 'dist/index.js',
        REPORT / 'E/raw/o200k_base.tiktoken', Path(config['grounded']['node']))}
    manifest = dict(frozen_at_utc=now(), base_commit=subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], text=True).strip(), inputs_sha256=inputs,
        config=config, runtime=versions(), installed_origin=str(REPO), external_sha256=external,
        boundary='installed editable package public in-process MCP, real isolated SQLite',
        generator_status='NOT MEASURED', token_budget=12000, tokenizer='tiktoken0.11.0/o200k_base')
    save(output, manifest)
    return manifest


def run(args):
    config = json.loads(args.config.read_text())
    manifest = json.loads(args.manifest.read_text())
    if any(sha((REPO / name).read_bytes()) != digest
           for name, digest in manifest['inputs_sha256'].items()):
        raise RuntimeError('frozen input changed before execution')
    if args.output.exists() or args.work.exists():
        raise ValueError('fresh output/work required, no overwriting attempts')
    args.output.mkdir(parents=True)
    args.work.mkdir(parents=True)
    ledger_path = REPORT / 'EXECUTION_LEDGER.jsonl'
    from eval.evidence_quality_v2 import runtime
    from docmancer.mcp.docs_server import call_docs_tool_payload
    from docmancer.docs.application.experimental_candidate_selection import experimental_selection_observer
    from docmancer.docs.application.experimental_candidate_selection import experimental_selection_flags
    from docmancer.retrieval.acquisition_diagnostics import capture_acquisition
    from docmancer.docs.application.query_trace import query_trace
    from docmancer.docs.application.projection_tokenizer import projection_token_count
    from eval.prepared_ablation.stages import prepared_sources
    from eval.prepared_model_comparison40.evaluate import _source_rows, _continuations

    started, started_cpu = time.perf_counter(), time.process_time()
    summary = dict(status='running', preparations=0, calls=0, returned=0,
                   answer_calls=0, model_calls=0, records=[])
    datasets = [REPO / path for path in config['datasets']]
    flag_keys = set(config['common']) | {key for flags in config['variants'].values() for key in flags}
    stopped_variants = set()
    try:
        for dataset_index, dataset in enumerate(datasets):
            cases, families = load_dataset(dataset)
            if args.smoke:
                if dataset_index:
                    break
                cases = cases[:1]
            for family in families:
                group_cases = [c for c in cases if c['project_group'] == family['id']]
                if not group_cases:
                    continue
                group = f'{dataset_index}-{family["id"]}'
                root, state = args.work / 'projects' / group, args.work / 'states' / group
                documents = {p: (dataset / 'sources' / family['id'] / p).read_text()
                             for p in family['paths']}
                runtime.write_project(root, documents)
                with runtime.isolated_service(state) as (service, config_object):
                    os.environ.update(config['common'])
                    summary['preparations'] += 1
                    ledger(ledger_path, 'prepare_docs', 'started', phase=args.phase, family=group)
                    with time_limit(180):
                        inventory = runtime.index_project(service, config_object, root)
                    sources, prepared = committed_sources(inventory, root, documents)
                    initial_db, initial_files = logical_state(inventory), source_state(root)
                    prep = dict(root=str(root), inventory=inventory, snapshot_sources=sources,
                                prepared_manifest=prepared, initial_database_state=initial_db,
                                initial_file_hashes=initial_files, corpus=str(dataset))
                    save(args.output / 'preparation' / f'{family["id"]}.json', prep)
                    validation_sources = prepared_sources(prep, dataset, family['id'])
                    ledger(ledger_path, 'prepare_docs', 'returned', phase=args.phase, family=group,
                           seconds=inventory['seconds'])
                    for case_index, case in enumerate(group_cases):
                        variants = list(config['variants'])
                        variants = variants[case_index % len(variants):] + variants[:case_index % len(variants)]
                        for variant in variants:
                            if variant in stopped_variants:
                                continue
                            if time.perf_counter() - started > 1800:
                                raise TimeoutError('frozen whole-run 1800-second ceiling')
                            if summary['calls'] >= (6 if args.smoke else 360):
                                raise RuntimeError('context call ceiling')
                            if logical_state(inventory) != initial_db or source_state(root) != initial_files:
                                raise RuntimeError('fixture mutated before context call')
                            for key in flag_keys:
                                os.environ.pop(key, None)
                            os.environ.update(config['common'])
                            os.environ.update(config['variants'][variant])
                            arguments = dict(question=case['question'], project_path=str(root), scope='project')
                            destination = args.output / 'calls' / case['id'] / variant
                            destination.mkdir(parents=True)
                            receipts, trace, payload = [], io.StringIO(), None
                            metadata = dict(case_id=case['id'], variant=variant, mode=variant, family=group,
                                            dataset=str(dataset), question=case['question'],
                                            public_request=deepcopy(arguments), project_root=str(root),
                                            status='started', started_at_utc=now())
                            save(destination / 'metadata.json', metadata)
                            ledger(ledger_path, 'get_docs_context', 'started', phase=args.phase,
                                   case_id=case['id'], variant=variant)
                            summary['calls'] += 1
                            call_started, cpu = time.perf_counter(), time.process_time()
                            with ExitStack() as stack:
                                observation = stack.enter_context(experimental_selection_observer(receipts.append))
                                acquisition = stack.enter_context(capture_acquisition())
                                stack.enter_context(experimental_selection_flags(
                                    **config.get('host_flags', {}).get(variant, {})))
                                try:
                                    with redirect_stderr(trace), query_trace(True), time_limit(60):
                                        payload = call_docs_tool_payload('get_docs_context', arguments, service)
                                    metadata['status'] = 'returned'
                                    summary['returned'] += 1
                                except Exception as exc:
                                    metadata.update(status='error', error_type=type(exc).__name__,
                                                    error=str(exc), traceback=traceback.format_exc())
                            metadata.update(seconds=time.perf_counter()-call_started,
                                            cpu_seconds=time.process_time()-cpu,
                                            observation_calls=observation.calls,
                                            observation_errors=observation.errors,
                                            peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                                            database_unchanged=logical_state(inventory) == initial_db,
                                            files_unchanged=source_state(root) == initial_files)
                            metadata.update(elapsed_seconds=metadata['seconds'],
                                            process_cpu_seconds=metadata['cpu_seconds'])
                            if payload is not None:
                                wire = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode()
                                (destination / 'public-payload.json').write_bytes(wire)
                                metadata.update(wire_sha256=sha(wire), bytes=len(wire),
                                                tokens=projection_token_count(wire),
                                                byte_proxy=(len(wire)+3)//4,
                                                source_count=len(payload.get('sources') or []))
                                metadata.update(wire_utf8_bytes=len(wire),
                                    codec_o200k_base=metadata['tokens'], utf8_quarter_proxy=metadata['byte_proxy'],
                                    within_wire_budget=max(metadata['tokens'], metadata['byte_proxy']) <= 12000)
                                _, _, integrity_errors = _source_rows(payload, validation_sources)
                                integrity_errors.extend(_continuations(payload, validation_sources))
                                if any(payload.get(key) is True for key in
                                       ('answer_supported', 'answer_available', 'edit_ready')):
                                    integrity_errors.append('unexpected_answer_or_edit_authority')
                                metadata['integrity_errors'] = integrity_errors
                                if integrity_errors:
                                    stopped_variants.add(variant)
                                    ledger(ledger_path, 'variant_stop', 'integrity_error',
                                           phase=args.phase, variant=variant, errors=integrity_errors)
                            save(destination / 'selection.json', receipts)
                            save(destination / 'acquisition.json', acquisition)
                            (destination / 'trace.jsonl').write_text(trace.getvalue())
                            save(destination / 'metadata.json', metadata)
                            summary['records'].append(metadata)
                            ledger(ledger_path, 'get_docs_context', metadata['status'], phase=args.phase,
                                   case_id=case['id'], variant=variant, seconds=metadata['seconds'])
                            save(args.output / 'SUMMARY.json', summary)
                            if not metadata['database_unchanged'] or not metadata['files_unchanged']:
                                raise RuntimeError('read-only invariant violated; stopping')
                            print(json.dumps(dict(case=case['id'], variant=variant,
                                                  status=metadata['status'], calls=summary['calls'])), flush=True)
        summary['frozen_inputs_unchanged'] = all(sha((REPO / name).read_bytes()) == digest
             for name, digest in manifest['inputs_sha256'].items())
        summary['stopped_variants'] = sorted(stopped_variants)
        summary['status'] = ('completed' if summary['returned'] == summary['calls']
            else 'completed_with_errors') if summary['frozen_inputs_unchanged'] and not stopped_variants else 'integrity_error'
    except Exception as exc:
        summary.update(status='error', error=str(exc), traceback=traceback.format_exc())
        ledger(ledger_path, 'workload', 'error', phase=args.phase, error=str(exc))
    finally:
        summary.update(seconds=time.perf_counter()-started,
                       process_cpu_seconds=time.process_time()-started_cpu,
                       peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        save(args.output / 'SUMMARY.json', summary)
    return 0 if summary['status'] == 'completed' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True, type=Path)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--freeze', action='store_true')
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--phase', default='comparison')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--work', type=Path)
    args = parser.parse_args()
    if args.freeze:
        freeze(args.config, args.manifest)
        return 0
    return run(args)


if __name__ == '__main__':
    raise SystemExit(main())
