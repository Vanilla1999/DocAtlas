"""Oracle-free comparison plumbing. Execution belongs to the sole coordinator.

No imports of product code, holdout, scorer or generator; no work on import.
Native receipts are immutable bytes. Packing is a whole-result ranked prefix,
not paragraph matching, content selection, deduplication or source restoration.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import time
from typing import Any, Sequence


TOKENIZER = "o200k_base"
TOKENIZER_SHA256 = "446a9538cb6c348e3516120d7c08b09f57c36495e2acfffe59a5bf8b0cfb1a2d"
TOKEN_CAP = 12000
GROUNDED_VERSION = "3.2.1"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def serialize(value: Any) -> str:
    """Exact model-visible evidence serialization; count this, not snippets only."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def preserve(path: Path, data: bytes) -> dict[str, Any]:
    """Never overwrite a native receipt, including on retries."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
    return {"path": str(path), "bytes": len(data), "sha256": sha256(data)}


class OfflineTokenizer:
    """Load a verified local BPE table without any implicit tiktoken download."""

    def __init__(self, table: Path):
        raw = table.read_bytes()
        if sha256(raw) != TOKENIZER_SHA256:
            raise ValueError("o200k_base table hash mismatch")
        import tiktoken
        ranks = {base64.b64decode(token, validate=True): int(rank)
                 for token, rank in (line.split() for line in raw.splitlines())}
        # Official o200k_base parameters (openai_public.py); only the loader
        # differs. Direct Encoding construction cannot fetch a remote asset.
        pattern = "|".join([
            r"""[^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]*[\p{Ll}\p{Lm}\p{Lo}\p{M}]+(?i:'s|'t|'re|'ve|'m|'ll|'d)?""",
            r"""[^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]+[\p{Ll}\p{Lm}\p{Lo}\p{M}]*(?i:'s|'t|'re|'ve|'m|'ll|'d)?""",
            r"\p{N}{1,3}", r" ?[^\s\p{L}\p{N}]+[\r\n/]*",
            r"\s*[\r\n]+", r"\s+(?!\S)", r"\s+",
        ])
        self.encoding = tiktoken.Encoding(
            name=TOKENIZER, pat_str=pattern, mergeable_ranks=ranks,
            special_tokens={"<|endoftext|>": 199999, "<|endofprompt|>": 200018})
        self.version = tiktoken.__version__

    def count(self, text: str) -> int:
        # Literal special-token-looking source text is ordinary evidence text.
        return len(self.encoding.encode(text, disallowed_special=()))


def native_evidence(engine: str, payload: Any) -> dict[str, Any]:
    """Keep full result bodies and all native attribution without invented spans.

    Grounded input is decoded official CLI stdout, not a historical wrapper.
    DocAtlas input is the public payload. Top-level policy metadata is retained.
    """
    if engine == "grounded":
        if not isinstance(payload, list):
            raise ValueError("expected Grounded CLI JSON result array")
        rows, metadata, body_key = payload, {}, "content"
    elif engine == "docatlas":
        if not isinstance(payload, dict) or not isinstance(payload.get("sources"), list):
            raise ValueError("expected DocAtlas public payload with sources")
        rows = payload["sources"]
        metadata = {key: value for key, value in payload.items() if key != "sources"}
        body_key = "snippet"
    else:
        raise ValueError("unknown comparison engine")
    sources = []
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get(body_key), str):
            raise ValueError("native result has no full textual body")
        sources.append({"content": row[body_key],
                        "attribution": {key: value for key, value in row.items()
                                        if key != body_key}})
    return {"native_metadata": metadata, "sources": sources}


def pack_evidence(evidence: dict[str, Any], tokenizer: OfflineTokenizer,
                  cap: int = TOKEN_CAP) -> dict[str, Any]:
    """Longest ranked prefix within cap, complete serialized metadata included.

    Stop at first non-fitting result, even if later smaller results would fit.
    No deduplication, crop, skipping or inspection of query/gold. Native payload
    remains separate. Empty package can be over-budget if metadata alone is huge.
    """
    if cap <= 0:
        raise ValueError("cap must be positive")
    rows = evidence["sources"]
    packed = {"native_metadata": evidence["native_metadata"], "sources": []}
    if tokenizer.count(serialize(packed)) > cap:
        raise ValueError("metadata alone exceeds cap; cannot silently drop policy")
    for row in rows:
        candidate = {**packed, "sources": [*packed["sources"], row]}
        if tokenizer.count(serialize(candidate)) > cap:
            break
        packed = candidate
    native_text, packed_text = serialize(evidence), serialize(packed)
    return {"payload": packed, "serialized": packed_text,
            "serialized_sha256": sha256(packed_text.encode("utf-8")),
            "tokenizer": TOKENIZER, "tokenizer_version": tokenizer.version,
            "table_sha256": TOKENIZER_SHA256, "cap_tokens": cap,
            "native_evidence_tokens": tokenizer.count(native_text),
            "packed_evidence_tokens": tokenizer.count(packed_text),
            "included_results": len(packed["sources"]),
            "omitted_suffix_results": len(rows) - len(packed["sources"]),
            "actual_prompt_tokens": None, "provider_usage": None,
            "product_estimated_tokens": evidence["native_metadata"].get("estimated_tokens")}


def count_prompt(serialized_prompt: str, tokenizer: OfflineTokenizer) -> dict[str, Any]:
    """Local count of a saved prompt; NOT provider chat framing/billed usage."""
    return {"serialized_prompt_tokens": tokenizer.count(serialized_prompt),
            "serialized_prompt_sha256": sha256(serialized_prompt.encode("utf-8")),
            "tokenizer": TOKENIZER, "provider_input_tokens": None,
            "provider_output_tokens": None, "cost_usd": None}


@dataclass(frozen=True)
class CorpusFile:
    path: str
    sha256: str


class GroundedAdapter:
    """Explicit opt-in CLI adapter for a sequential post-freeze runner.

    Constructor verifies package only. prepare()/query() execute public CLI.
    Caller supplies a frozen corpus inventory, unchanged question and one limit.
    No global Grounded MCP calls, library updates or default-store mutations.
    """

    def __init__(self, package_root: Path, node: Path, output: Path):
        self.package_root = package_root.resolve()
        package = json.loads((self.package_root / "package.json").read_text())
        if (package.get("name"), package.get("version")) != ("@arabold/docs-mcp-server", GROUNDED_VERSION):
            raise ValueError("Grounded package pin mismatch")
        self.entry = self.package_root / "dist/index.js"
        if not self.entry.is_file() or not node.is_absolute():
            raise ValueError("absolute Node path and installed entrypoint required")
        self.node, self.output = node, output.resolve()
        if self.output.exists():
            raise ValueError("isolated output must be fresh")
        self.ready = False

    def _call(self, receipt: Path, arguments: Sequence[str], timeout: int) -> dict[str, Any]:
        argv = [str(self.node), str(self.entry), "--config", str(self.config),
                "--store-path", str(self.output / "store"), "--no-telemetry",
                "--no-logo", *arguments]
        start = time.monotonic()
        error, returncode = None, None
        try:
            proc = subprocess.run(argv, cwd=self.output, env=self.env,
                                  capture_output=True, timeout=timeout, check=False)
            stdout, stderr, returncode = proc.stdout, proc.stderr, proc.returncode
        except subprocess.TimeoutExpired as exc:
            stdout, stderr = exc.stdout or b"", exc.stderr or b""
            error = "timeout"
        except OSError as exc:
            stdout, stderr, error = b"", b"", type(exc).__name__
        elapsed = time.monotonic() - start
        record = {"argv": argv, "seconds": elapsed, "returncode": returncode,
                  "error": error, "stdout": preserve(receipt / "stdout.bin", stdout),
                  "stderr": preserve(receipt / "stderr.bin", stderr),
                  "provider_usage": None, "cost_usd": None}
        preserve(receipt / "receipt.json", (serialize(record) + "\n").encode())
        return record

    def prepare(self, corpus_root: Path, files: Sequence[CorpusFile], library: str) -> dict[str, Any]:
        if self.output.exists() or not files or not library:
            raise ValueError("fresh output, nonempty frozen inventory/library required")
        root = corpus_root.resolve()
        copied, seen = [], set()
        # Validate ALL corpus files before any engine execution; reject symlinks.
        for item in files:
            rel = Path(item.path)
            source = root / rel
            if (rel.is_absolute() or ".." in rel.parts or item.path in seen
                    or not source.resolve().is_relative_to(root)
                    or any(p.is_symlink() for p in [source, *source.parents])):
                raise ValueError("unsafe/duplicate frozen corpus path")
            data = source.read_bytes()
            if sha256(data) != item.sha256:
                raise ValueError("frozen corpus hash mismatch")
            seen.add(item.path)
            copied.append((item, data))
        self.output.mkdir(parents=True)
        home = self.output / "home"
        home.mkdir()
        self.env = {k: os.environ[k] for k in ("PATH", "LANG", "LC_ALL", "TZ") if k in os.environ}
        self.env.update(HOME=str(home), XDG_CONFIG_HOME=str(home / "config"),
                        XDG_DATA_HOME=str(home / "data"), XDG_CACHE_HOME=str(home / "cache"),
                        DO_NOT_TRACK="1", DOCS_MCP_APP_TELEMETRY_ENABLED="false",
                        PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD="1")
        self.config = self.output / "config.json"
        config = {"app": {"storePath": str(self.output / "store"),
                          "telemetryEnabled": False, "embeddingModel": ""},
                  "scraper": {"maxPages": 1, "maxDepth": 1, "security": {
                      "fileAccess": {"mode": "allowedRoots",
                                     "allowedRoots": [str(self.output / "corpus")],
                                     "followSymlinks": False, "includeHidden": True}}}}
        preserve(self.config, (serialize(config) + "\n").encode())
        self.library = library
        manifest = [{"path": item.path, "sha256": item.sha256, "bytes": len(data)}
                    for item, data in copied]
        preserve(self.output / "corpus-manifest.json", (serialize(manifest) + "\n").encode())
        receipts = []
        for index, (item, data) in enumerate(copied):
            target = self.output / "corpus" / item.path
            preserve(target, data)
            receipt = self._call(self.output / "raw/ingest" / str(index),
                                 ["scrape", library, target.as_uri(), "--max-pages", "1",
                                  "--max-depth", "1", "--no-clean"], 240)
            receipts.append(receipt)
            if receipt["returncode"] != 0:
                raise RuntimeError("Grounded ingest failed; full receipt preserved")
        audit = self.audit_inventory()
        preserve(self.output / "ingest-audit.json", (serialize(audit) + "\n").encode())
        if audit["missing"] or audit["unexpected"] or audit["non_null_embeddings"]:
            raise RuntimeError("Grounded inventory or lexical-mode audit failed")
        self.ready = True
        return {"corpus": manifest, "receipts": receipts, "audit": audit}

    def audit_inventory(self) -> dict[str, Any]:
        manifest = json.loads((self.output / "corpus-manifest.json").read_text())
        expected = sorted((self.output / "corpus" / row["path"]).as_uri() for row in manifest)
        db_path = self.output / "store/documents.db"
        with sqlite3.connect(db_path.as_uri() + "?mode=ro", uri=True) as db:
            urls = sorted(row[0] for row in db.execute(
                "SELECT p.url FROM pages p JOIN versions v ON v.id=p.version_id "
                "JOIN libraries l ON l.id=v.library_id WHERE l.name=?", (self.library,)))
            count = db.execute(
                "SELECT count(*) FROM documents d JOIN pages p ON p.id=d.page_id "
                "JOIN versions v ON v.id=p.version_id JOIN libraries l ON l.id=v.library_id "
                "WHERE l.name=? AND d.embedding IS NOT NULL", (self.library,)).fetchone()[0]
        return {"expected_urls": expected, "indexed_urls": urls,
                "missing": sorted(set(expected) - set(urls)),
                "unexpected": sorted(set(urls) - set(expected)), "non_null_embeddings": count,
                "proof_boundary": "URL inventory + null embeddings; not identical chunking or parser bytes"}

    def query(self, question: str, call_id: str, *, limit: int = 5) -> dict[str, Any]:
        if not self.ready or not 1 <= limit <= 100 or not question:
            raise ValueError("audited preparation, unchanged question and limit 1..100 required")
        if not call_id or Path(call_id).name != call_id or call_id in (".", ".."):
            raise ValueError("call_id must be one safe path component")
        receipt_path = self.output / "raw/query" / call_id
        if receipt_path.exists():
            raise ValueError("query receipt already exists; retries require explicit new ID")
        receipt = self._call(receipt_path, ["search", self.library, question,
                            "--limit", str(limit), "--output", "json"], 90)
        if receipt["returncode"] != 0:
            return {"receipt": receipt, "payload": None, "status": "operational_error"}
        # Decode only AFTER both raw channels have been durably preserved.
        payload = json.loads((receipt_path / "stdout.bin").read_bytes())
        return {"receipt": receipt, "payload": payload, "status": "ok"}
