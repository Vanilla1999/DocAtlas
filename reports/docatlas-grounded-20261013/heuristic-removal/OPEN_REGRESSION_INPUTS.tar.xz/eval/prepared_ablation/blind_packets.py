"""Create label-hidden review evidence; never alter supplied text or source IDs."""
import argparse
import hashlib
import json
from pathlib import Path

from eval.prepared_ablation.run import REPO, save


def make_bundle(grounded_dir, output):
    corpus = REPO / 'eval/prepared_ablation/holdout'
    cases = json.loads((corpus / 'questions.json').read_text())['cases']
    oracle = {c['id']: c for c in json.loads((corpus / 'semantic_rubric.json').read_text())['cases']}
    mappings, review_cases = {}, []
    for case in cases:
        packets = []
        paths = [('V0', grounded_dir / 'docatlas-packed' / case['id'] / 'V0.json'),
                 ('VALL', grounded_dir / 'docatlas-packed' / case['id'] / 'VALL.json'),
                 ('Grounded', grounded_dir / 'calls' / case['id'] / 'packed.json')]
        for label, path in paths:
            if not path.exists():
                continue
            raw = path.read_bytes()
            packed = json.loads(raw)
            alias = 'packet-' + hashlib.sha256((case['id']+'|'+label+'|label-hidden-v1').encode()).hexdigest()[:12]
            mappings[alias] = dict(case_id=case['id'], variant=label, path=str(path), sha256=hashlib.sha256(raw).hexdigest())
            # Hide engine envelope/variant. Keep every packed text and native
            # attribution; no rewritten identifiers, code, predicates or crops.
            packets.append(dict(packet_id=alias, sources=packed['payload']['sources'],
                                included_results=packed['included_results'], tokens=packed['packed_evidence_tokens']))
        review_cases.append(dict(case=case, rubric=oracle[case['id']],
                                 packets=sorted(packets, key=lambda p:p['packet_id'])))
    save(output / 'LABEL_MAPPING_PRIVATE.json', mappings)
    save(output / 'BLIND_REVIEW_PACKETS.json', dict(cases=review_cases,
         boundary='packed evidence text/attribution unchanged; engine policy envelopes hidden only for semantic review',
         caveat='native attribution shape may reveal engine; label-hidden is not guaranteed engine-blind'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--grounded-dir', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    make_bundle(args.grounded_dir, args.output)
