"""Data-only acquisition; no product imports or evaluation execution."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
SPECS = [
    ("ruff", "astral-sh/ruff", "docs/configuration.md", "LICENSE"),
    ("uv", "astral-sh/uv", "docs/concepts/configuration-files.md", "LICENSE-MIT"),
    ("mkdocs", "mkdocs/mkdocs", "docs/user-guide/configuration.md", "LICENSE"),
    ("typer", "fastapi/typer", "docs/tutorial/parameter-types/bool.md", "LICENSE"),
]

def get(url):
    with urlopen(Request(url, headers={"User-Agent": "DocAtlas-independent-corpus"}), timeout=60) as response:
        return response.read(), response.status, response.url

def acquire(spec):
    family, repo, path, license_path = spec
    started = time.monotonic()
    api = f"https://api.github.com/repos/{repo}/commits?per_page=1"
    raw, status, final = get(api)
    commit = json.loads(raw)[0]["sha"]
    downloads = []
    for upstream, local in [(path, f"sources/{family}/{path}"), (license_path, f"licenses/{family}/{license_path}")]:
        url = f"https://raw.githubusercontent.com/{repo}/{commit}/{upstream}"
        content, status, final = get(url)
        target = ROOT / local
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        downloads.append(dict(family=family, repository=repo, commit=commit,
                              upstream_path=upstream, local_path=local, url=url,
                              status=status, final_url=final, bytes=len(content),
                              sha256=hashlib.sha256(content).hexdigest()))
    return dict(id=family, repo=repo, commit=commit, paths=[path],
                downloads=downloads, elapsed_seconds=time.monotonic()-started)

if __name__ == "__main__":
    if (ROOT / "source-manifest.json").exists():
        raise SystemExit("Refusing to reacquire frozen sources")
    with ThreadPoolExecutor(max_workers=4) as pool:
        families = list(pool.map(acquire, SPECS))
    def save(name, value):
        (ROOT / name).write_text(json.dumps(value, indent=2) + "\n")
    save("source_plan.json", dict(schema_version=1, families=[
        {k: v for k, v in f.items() if k not in ("downloads", "elapsed_seconds")} for f in families]))
    save("source-manifest.json", dict(schema_version=1, acquired_at_utc=datetime.now(timezone.utc).isoformat(),
        boundary="read-only upstream HTTP; no product/model calls", download_attempts=12,
        families=families))
