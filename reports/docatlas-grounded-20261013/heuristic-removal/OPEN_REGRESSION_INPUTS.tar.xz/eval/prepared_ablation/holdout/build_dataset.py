"""Independent authoring, using only the acquired original source bytes.

This script does not import product code, historical gold, or any result packet.
It writes annotations, never source documents.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PATHS = {"ruff": "docs/configuration.md", "uv": "docs/concepts/configuration-files.md",
         "mkdocs": "docs/user-guide/configuration.md", "typer": "docs/tutorial/parameter-types/bool.md"}
cases, gold, rubrics = [], [], []

def add(identifier, group, kind, family, question, facts, unavailable=(), forbidden=()):
    """facts: (ID, independently read meaning, alternative lists of line ranges)."""
    cases.append(dict(id=identifier, project_group=group, question=question,
                      answerability=kind, family=family, split="holdout", source_kind="real_upstream"))
    claims, facets = [], []
    for name, meaning, alternatives in facts:
        sets = []
        for ranges in alternatives:
            parts = []
            for start, end in ranges:
                path = PATHS[group]
                lines = (ROOT / "sources" / group / path).read_text().splitlines(keepends=True)
                assert 1 <= start <= end <= len(lines)
                quote = "".join(lines[start - 1:end])
                assert quote.strip()
                parts.append(dict(path=path, line_start=start, line_end=end))
            sets.append(dict(parts=parts))
        claims.append(dict(id=name, witness_sets=sets))
        facets.append(dict(id=name, kind="documented", required_meaning=meaning,
                           acceptable_source_witnesses=sets,
                           alternate_policy="Any verified snippet in this case's entire pinned family may qualify after explicit human review; token overlap is not a verdict."))
    for name, meaning in unavailable:
        claims.append(dict(id=name, witness_sets=[]))
        facets.append(dict(id=name, kind="unavailable", required_meaning=meaning,
                           absence_boundary="All and only the complete pinned documents for this project_group; linked documents are not indexed or authorized evidence."))
    response = {"within_budget": "grounded_answer", "partial": "partial_with_explicit_gap",
                "unanswerable": "abstention_or_clarification"}[kind]
    gold.append(dict(id=identifier, required_claims=claims, expected_response=response,
                     forbidden_inferences=["Do not infer facts outside the closed pinned source snapshot.", *forbidden]))
    rubrics.append(dict(id=identifier, expected_response=response, facets=facets,
                        relations_conditions_negation=list(forbidden),
                        assessment="needs_review", answer_generation="not_measured"))

add("H20-R01", "ruff", "within_budget", "default_vs_example",
    "In Ruff's configuration guide, what is the default string quote style, and does the example that sets single quotes change that default?",
    [("default", 'The unspecified formatter configuration uses quote-style = "double".', [[(12,12),(66,68)],[(12,12),(145,147)]]),
     ("example", 'The later single-quote configuration is an example override, not the default.', [[(173,173),(193,196)],[(173,173),(216,219)]])],
    forbidden=["Do not promote the single-quote example into a default."])
add("H20-R02", "ruff", "within_budget", "cross_section_precedence",
    "How do relative paths and command-line overrides work for Ruff's closest discovered config versus a config file supplied with --config?",
    [("discovered_paths", "Closest per-file config; relative paths resolve against its containing directory.", [[(253,257)]]),
     ("explicit_paths", "An explicit --config file applies to all analyzed files; its relative paths use the current working directory.", [[(263,265)]]),
     ("cli_precedence", "Config-supported CLI settings override every resolved config; a dedicated flag beats a simultaneous --config setting override.", [[(271,272),(497,504)]])],
    forbidden=["Do not apply the discovered-directory base to explicit --config files."])
add("H20-R03", "ruff", "partial", "known_patterns_missing_retention",
    "Which file patterns does Ruff discover by default (including the preview-only addition), and after exactly how many hours are its cache entries expired?",
    [("patterns", "Discover *.py, *.pyi, *.ipynb, pyproject.toml; *.pyw is an additional preview-mode default.", [[(348,351)]])],
    [("cache_expiry", "The selected guide does not specify an exact cache-entry expiration in hours.")],
    ["Do not strip '*' or the preview-only condition; do not invent cache lifetime."])
add("H20-R04", "ruff", "unanswerable", "missing_numeric_limit",
    "What is Ruff's documented maximum resident-memory limit in megabytes for ruff format?", [],
    [("memory_limit", "No formatter resident-memory limit is specified in the pinned configuration guide.")])
add("H20-R05", "ruff", "unanswerable", "missing_exit_contract",
    "What exact numeric exit status does Ruff return when its cache database is corrupted?", [],
    [("corrupt_cache_exit", "The pinned guide does not document a corrupted-cache-specific exit status.")],
    ["Do not substitute the diagnostics exit code mentioned for --silent."])

add("H20-U01", "uv", "within_budget", "merge_relations_precedence",
    "When uv project and user configuration both define a scalar and an array setting, how are they merged, and where do environment variables and CLI settings fit in precedence?",
    [("scalar", "The project scalar value wins over the user value.", [[(61,63)]]),
     ("arrays", "Arrays concatenate with project entries earlier.", [[(63,64)]]),
     ("overrides", "Environment variables override persistent config, and CLI overrides both.", [[(66,67)]])],
    forbidden=["Do not describe arrays as scalar replacement; preserve ordering."])
add("H20-U02", "uv", "within_budget", "command_role_workspace_boundary",
    "Does uv use member-local configuration in a workspace, and do uv tool commands use project-local configuration? Explain the configuration locations for each boundary.",
    [("workspace", "Workspace search begins at workspace root, ignores member config, and shares config across members.", [[(14,16)]]),
     ("tool", "User-level tool commands ignore local configuration and exclusively read user/system configuration.", [[(8,12)]])],
    forbidden=["Do not apply workspace project discovery to tool commands."])
add("H20-U03", "uv", "partial", "dotenv_order_missing_default",
    "For uv run with repeated --env-file arguments, which file wins for duplicate variables and how do existing environment variables compare; what is the default network retry count?",
    [("dotenv_order", "Subsequent dotenv files override earlier files.", [[(96,98)]]),
     ("environment", "Existing environment values take precedence over dotenv values.", [[(104,105)]])],
    [("retry_count", "No default network retry count is specified in this configuration-file snapshot.")])
add("H20-U04", "uv", "partial", "namespace_missing_lifetime",
    "Does index-url under [tool.uv.pip] affect uv sync as well as uv pip install, and for how many days is uv's HTTP cache retained by default?",
    [("namespace", "The example [tool.uv.pip] index-url affects uv pip install, not uv sync, uv lock or uv run.", [[(119,126)],[(109,113),(119,121)]])],
    [("http_cache_retention", "The selected file specifies no default HTTP-cache retention in days.")],
    ["Do not extend pip-only settings to uv sync."])
add("H20-U05", "uv", "unanswerable", "missing_pinning_algorithm",
    "Which certificate-pinning algorithm does uv use for the test.pypi.org index shown in the configuration example?", [],
    [("pinning", "The index URL example does not specify a certificate-pinning algorithm.")],
    ["An example HTTPS URL is not an algorithm specification."])

add("H20-M01", "mkdocs", "within_budget", "draft_vs_exclusion_condition",
    "In MkDocs 1.6 configuration, how do draft_docs and exclude_docs differ between serve and build, and what does mkdocs serve --clean do to drafts?",
    [("exclude", "exclude_docs no longer implements serve-only drafts; use draft_docs for that behavior.", [[(298,302)]]),
     ("draft", "Drafts are available during serve with a DRAFT mark, absent from build; serve --clean makes serve behave like build.", [[(341,345)]])],
    forbidden=["Do not claim exclude_docs still exposes drafts during serve in version 1.6."])
add("H20-M02", "mkdocs", "within_budget", "table_default_conditional_url",
    "For MkDocs api-guide.md, compare the generated file and URL with use_directory_urls true versus false, state the default, and name the documented hosting conditions that require false.",
    [("false_table", "False maps api-guide.md to api-guide.html and /api-guide.html.", [[(682,682),(690,694)]]),
     ("true_table", "True maps api-guide.md to /api-guide/index.html and /api-guide/.", [[(701,701),(706,710)]]),
     ("conditions_default", "True is default; false is required when opening from the filesystem or publishing to a static S3 website.", [[(696,699),(712,712)]])],
    forbidden=["Do not merge columns or treat a false-setting table as the default."])
add("H20-M03", "mkdocs", "partial", "paired_directories_missing_backup",
    "What are MkDocs' default docs_dir and site_dir, how are their relative paths resolved, and what is the default automatic backup interval in hours?",
    [("docs_dir", "docs is the docs_dir default; relative paths resolve against the configuration-file directory.", [[(546,553)]]),
     ("site_dir", "site is the site_dir default; relative paths resolve against the configuration-file directory.", [[(555,562)]])],
    [("backup_interval", "The pinned guide specifies no automatic backup interval.")])
add("H20-M04", "mkdocs", "partial", "example_mapping_missing_integrity",
    "How does MkDocs extra_javascript treat a plain .mjs string versus a mapping with a .mjs path regarding type=module, and which integrity hash algorithm is automatically applied?",
    [("module_condition", "Only the plain-string form auto-detects .mjs and adds type=module; the mapping requires an explicit type: module regardless of extension.", [[(616,621)]]),
     ("example", "The examples show both implicit plain-string and explicit mapping module forms.", [[(601,608)]])],
    [("integrity", "The pinned guide does not specify automatically applied integrity hashing.")],
    ["Do not claim all .mjs mapping paths automatically acquire type=module."])
add("H20-M05", "mkdocs", "unanswerable", "missing_server_workers",
    "What is the default number of worker processes used by the MkDocs development server?", [],
    [("workers", "The server address and watch settings do not specify a default worker process count.")])
add("H20-M06", "mkdocs", "unanswerable", "missing_database_backend",
    "Which SQL database engine is the default storage backend for MkDocs' search index?", [],
    [("sql_backend", "The pinned search configuration does not name a default SQL storage backend.")])

add("H20-T01", "typer", "within_budget", "case_sensitive_flag_roles",
    "In Typer's short-name boolean example, what do -f and -F mean and what is the default; how does that differ from the earlier only --force example's treatment of --no-force?",
    [("short_names", "-f is --force; -F is --no-force; the displayed default is no-force.", [[(100,100),(112,127)]]),
     ("only_force", "The only --force example deliberately removes --no-force, which raises No such option.", [[(7,15),(40,46)]])],
    forbidden=["Case-folding -f and -F destroys the documented opposite roles."])
add("H20-T02", "typer", "within_budget", "literal_space_negative_role",
    "For Typer's boolean options with only False names, what exact leading-space/slash convention is required, and what do the default and --demo do in the shown example?",
    [("literal", 'A preceding space then / is required; " /-S" is correct, "/-S" is not.', [[(132,146)]]),
     ("roles", "The shown default is True and runs production; --demo selects the False-named behavior and runs demo.", [[(156,171)]])],
    forbidden=["Do not strip the significant space inside the quoted name; do not invert the False role."])
add("H20-T03", "typer", "partial", "dual_names_missing_delay",
    "How do you specify Typer's --accept and --reject names for a boolean option, and what is the default retry delay in milliseconds after --reject?",
    [("names", "Pass one string with the two bool option names separated by /.", [[(51,59)]]),
     ("behavior", "The example accepts with --accept and rejects with --reject.", [[(83,91)]])],
    [("delay", "The pinned boolean-option tutorial does not document a default retry delay.")])
add("H20-T04", "typer", "unanswerable", "missing_repeated_flag_policy",
    "What documented conflict-resolution rule applies when --accept and --reject are both passed in the same Typer invocation?", [],
    [("conflict", "The pinned tutorial demonstrates separate invocations only; it specifies no simultaneous-conflict rule.")],
    ["Do not infer last-wins or error behavior from separate console examples."])

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

if __name__ == "__main__":
    if (ROOT / "FREEZE_MANIFEST.json").exists():
        raise SystemExit("Dataset already frozen; annotations cannot be regenerated")
    assert len(cases) == 20 and len({c["id"] for c in cases}) == 20
    assert [sum(c["answerability"] == k for c in cases) for k in ("within_budget", "partial", "unanswerable")] == [8,6,6]
    save("questions.json", dict(schema_version=1, state="closed_new_holdout", cases=cases))
    save("gold_spans.json", dict(schema_version=1, state="sealed_not_for_retrieval", cases=gold))
    save("semantic_rubric.json", dict(schema_version=1, state="sealed_independent_review_rubric", cases=rubrics))
    audit = []
    for case, oracle in zip(cases, gold):
        for claim in oracle["required_claims"]:
            for alternative in claim["witness_sets"]:
                for part in alternative["parts"]:
                    raw = (ROOT / "sources" / case["project_group"] / part["path"]).read_bytes()
                    text = raw.decode("utf-8").splitlines(keepends=True)
                    quote = "".join(text[part["line_start"]-1:part["line_end"]])
                    audit.append(dict(case_id=case["id"], claim_id=claim["id"], **part,
                                      source_sha256=hashlib.sha256(raw).hexdigest(),
                                      raw_quote_sha256=hashlib.sha256(quote.encode()).hexdigest()))
    save("gold-span-audit.json", dict(schema_version=1, witnesses=audit))
