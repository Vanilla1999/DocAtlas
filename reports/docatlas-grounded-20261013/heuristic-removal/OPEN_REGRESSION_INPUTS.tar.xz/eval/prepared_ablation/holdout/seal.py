"""One-time data integrity validation/sealing; no runtime or benchmark calls."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
REPORT = REPO / "reports/admission-experiments/prepared-retrieval/multiagent-20261013/D"

if __name__ == "__main__":
    if (ROOT / "FREEZE_MANIFEST.json").exists():
        raise SystemExit("Already sealed; never overwrite")
    sha = lambda raw: hashlib.sha256(raw).hexdigest()
    load = lambda name: json.loads((ROOT / name).read_bytes())
    cases = load("questions.json")["cases"]
    gold = load("gold_spans.json")["cases"]
    rubric = load("semantic_rubric.json")["cases"]
    plan = load("source_plan.json")["families"]
    historical = json.loads((REPO / "eval/prepared_model_comparison40/source_plan.json").read_bytes())["families"]
    assert len(cases) == 20 and len({c["id"] for c in cases}) == 20
    assert Counter(c["answerability"] for c in cases) == {"within_budget": 8, "partial": 6, "unanswerable": 6}
    assert {f["id"] for f in plan}.isdisjoint({f["id"] for f in historical})
    assert {f["repo"] for f in plan}.isdisjoint({f["repo"] for f in historical})
    assert len(plan) == 4
    assert [c["id"] for c in cases] == [c["id"] for c in gold] == [c["id"] for c in rubric]
    by_id = {c["id"]: c for c in cases}
    witnesses = load("gold-span-audit.json")["witnesses"]
    for entry in witnesses:
        path = ROOT / "sources" / by_id[entry["case_id"]]["project_group"] / entry["path"]
        raw = path.read_bytes()
        assert sha(raw) == entry["source_sha256"]
        lines = raw.decode("utf-8").splitlines(keepends=True)
        assert 1 <= entry["line_start"] <= entry["line_end"] <= len(lines)
        quote = "".join(lines[entry["line_start"]-1:entry["line_end"]])
        assert quote.strip() and sha(quote.encode("utf-8")) == entry["raw_quote_sha256"]
    receipt = load("source-manifest.json")
    for family in receipt["families"]:
        assert len(family["commit"]) == 40
        for download in family["downloads"]:
            raw = (ROOT / download["local_path"]).read_bytes()
            assert download["status"] == 200 and sha(raw) == download["sha256"]
            assert len(raw) == download["bytes"]
            assert family["commit"] in download["url"]
    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    files += [REPO / "eval/prepared_ablation/evaluation.py",
              REPO / "eval/prepared_model_comparison40/evaluate.py",
              REPORT / "EVALUATION_PROTOCOL.md"]
    for path in files:
        if path.suffix == ".py":
            ast.parse(path.read_text(), filename=str(path))
    manifest = dict(schema_version=1, state="frozen_before_new_outputs",
                    frozen_at_utc=datetime.now(timezone.utc).isoformat(), outputs_seen=False,
                    question_count=20, design=dict(positive=8, partial=6, negative=6, new_families=4),
                    independent_gold=True, no_gold_supplied_to_runtime=True,
                    files_sha256={p.relative_to(REPO).as_posix(): sha(p.read_bytes()) for p in files},
                    validation=dict(boundary="data-only serialization, source receipt/hash/range checks and Python AST parsing",
                                    source_downloads=8, commit_resolution_requests=4,
                                    source_bytes=sum(d["bytes"] for f in receipt["families"] for d in f["downloads"]),
                                    witness_parts_checked=len(witnesses), product_calls=0, model_calls=0,
                                    pytest_runs=0, benchmark_runs=0, static_checks="pass"))
    data = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    (ROOT / "FREEZE_MANIFEST.json").write_text(data, encoding="utf-8")
    interface = dict(schema_version=1, owner="D", state="sealed_private_until_coordinator_code_freeze",
                     directory="eval/prepared_ablation/holdout/",
                     evaluator="eval/prepared_ablation/evaluation.py",
                     protocol="reports/admission-experiments/prepared-retrieval/multiagent-20261013/D/EVALUATION_PROTOCOL.md",
                     question_count=20, design=manifest["design"],
                     freeze_manifest_sha256=sha(data.encode("utf-8")),
                     file_sha256={name: sha((ROOT / name).read_bytes()) for name in
                                  ("questions.json", "gold_spans.json", "semantic_rubric.json", "source_plan.json", "source-manifest.json", "gold-span-audit.json")},
                     corpus_hash_method="SHA256 of canonical sorted relative-path/raw-file-SHA map, sources only",
                     corpus_sha256=sha(json.dumps({p.relative_to(ROOT / "sources").as_posix(): sha(p.read_bytes()) for p in sorted((ROOT / "sources").rglob("*")) if p.is_file()}, sort_keys=True, separators=(",", ":")).encode()),
                     evaluation_api="evaluate(run_dir, corpus_dir=DEFAULT_CORPUS, modes=None, review_path=None)",
                     required_runner_manifest_fields=["question_count=20", "arms", "final_json_cap", "holdout_freeze_manifest_sha256"],
                     runtime_artifacts="historical preparation/<group>.json and calls/<case_id>/<arm>/{public-payload,metadata,selection}.json",
                     semantic_default="needs_review", historical_exact_evaluator="unchanged",
                     cost=manifest["validation"], blockers=["Runtime/results require coordinator code freeze; semantic PASS requires independent review."])
    (REPORT / "INTERFACE.json").write_text(json.dumps(interface, indent=2) + "\n")
    print(json.dumps(dict(freeze_manifest_sha256=interface["freeze_manifest_sha256"],
                         corpus_sha256=interface["corpus_sha256"], question_count=20,
                         validation=manifest["validation"]), indent=2))
