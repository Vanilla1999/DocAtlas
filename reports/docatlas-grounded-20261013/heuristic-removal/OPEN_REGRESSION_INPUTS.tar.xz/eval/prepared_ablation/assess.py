"""Offline reuse of frozen exact scoring, independent native-stage diagnostics."""
import argparse
from collections import Counter
import csv
import json
from pathlib import Path

from eval.prepared_ablation.evaluation import evaluate as evaluate_holdout
from eval.prepared_ablation.run import REPO, save
from eval.prepared_ablation.stages import analyze
from eval.prepared_model_comparison40 import evaluate as historical


def assess(run_dir, manifest_path, output):
    manifest = json.loads(manifest_path.read_text())
    variants = list(manifest['config']['variants'])
    all_rows, stages = [], []
    for index, relative in enumerate(manifest['config']['datasets']):
        dataset = REPO / relative
        cases = json.loads((dataset / 'questions.json').read_text())['cases']
        oracle = {c['id']: c for c in json.loads((dataset / 'gold_spans.json').read_text())['cases']}
        if index == 1:
            view = output / 'holdout-view'
            view.mkdir(parents=True)
            for name in ('calls', 'preparation'):
                (view / name).symlink_to((run_dir / name).resolve(), target_is_directory=True)
            save(view / 'RUN_MANIFEST.json', dict(question_count=20, arms=variants, final_json_cap=12000,
                parent_frozen_manifest=str(manifest_path), subset_view=True,
                holdout_freeze_manifest_sha256=manifest['config']['holdout_freeze_manifest_sha256']))
            result = evaluate_holdout(view, dataset)
            save(output / 'H20_RESULTS.json', result)
            rows = result['cases']
        else:
            prepared = {group: historical._prepare(group, run_dir, dataset)
                        for group in {c['project_group'] for c in cases}}
            rows = [historical._case(case, oracle[case['id']], variant, run_dir,
                     prepared[case['project_group']], 12000) for case in cases for variant in variants]
            save(output / 'V40_RESULTS.json', dict(cases=rows,
                historical_functions_unchanged=True, global_manifest=str(manifest_path)))
        all_rows.extend(dict(row, split='H20' if index else 'V40') for row in rows)
        for case in cases:
            preparation = json.loads((run_dir / 'preparation' / f'{case["project_group"]}.json').read_text())
            for variant in variants:
                call_path = run_dir / 'calls' / case['id'] / variant
                if (call_path / 'public-payload.json').exists():
                    stages.append(analyze(call_path, preparation, dataset, case, oracle[case['id']]))
    summary = {}
    for split in ('V40', 'H20'):
        summary[split] = {}
        for variant in variants:
            rows = [r for r in all_rows if r['split']==split and r['mode']==variant]
            summary[split][variant] = dict(cases=len(rows), integrity_pass=sum(r['valid_public_call_and_integrity'] for r in rows),
                positive=sum(r['strict_positive_pass'] is True for r in rows),
                partial=sum(r['strict_partial_documented_pass'] is True for r in rows),
                negative=sum(r['strict_empty_source_pass'] is True for r in rows),
                semantic=Counter(r.get('semantic_review', {}).get('verdict', 'NOT_MEASURED') for r in rows))
    save(output / 'EXACT_SUMMARY.json', summary)
    save(output / 'STAGE_RESULTS.json', dict(measure='raw witness chars, not entailment', cases=stages))
    fields = ['split', 'case_id', 'mode', 'answerability', 'valid_public_call_and_integrity',
              'strict_positive_pass', 'strict_partial_documented_pass', 'strict_empty_source_pass',
              'public_source_count', 'codec_o200k_base', 'elapsed_seconds']
    with (output / 'CASE_RESULTS.csv').open('w') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(all_rows)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', required=True, type=Path)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    assess(args.run_dir, args.manifest, args.output)
