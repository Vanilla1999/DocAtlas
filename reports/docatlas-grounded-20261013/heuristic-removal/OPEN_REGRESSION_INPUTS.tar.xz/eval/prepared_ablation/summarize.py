"""Offline cost, packet and acquisition-universe accounting; no quality inference."""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import statistics


def digest(data):
    return hashlib.sha256(data).hexdigest()


def summarize(run_dir, output):
    records = json.loads((run_dir / 'SUMMARY.json').read_text())
    costs, pairs, manifest = defaultdict(list), defaultdict(dict), []
    for metadata in records['records']:
        path = run_dir / 'calls' / metadata['case_id'] / metadata['variant']
        payload_path = path / 'public-payload.json'
        if not payload_path.exists():
            costs[metadata['variant']].append(metadata)
            continue
        payload = json.loads(payload_path.read_text())
        sources = payload.get('sources') or []
        units = [(r.get('path_or_url'), r.get('line_start'), r.get('line_end'), r.get('snippet'))
                 for r in sources]
        unique = set(units)
        item = dict(metadata, duplicate_sources=len(units)-len(unique),
                    source_characters=sum(len(r.get('snippet', '')) for r in sources),
                    unique_source_characters=sum(len(unit[3] or '') for unit in unique),
                    authority_false=not any(payload.get(k) is True
                        for k in ('answer_supported', 'answer_available', 'edit_ready')))
        receipts = json.loads((path / 'selection.json').read_text())
        # Identity only, no qualification/mode-dependent metadata in universe check.
        universe = [(r.get('path'), tuple(r.get('span', [])), r.get('text_sha256'))
                    for receipt in receipts for r in receipt.get('complete_candidates', [])]
        item['upstream_universe_hash'] = digest(json.dumps(sorted(universe, key=repr)).encode())
        item['upstream_unique_universe_hash'] = digest(json.dumps(sorted(set(universe), key=repr)).encode())
        item['complete_records'] = len(universe)
        item['unique_complete_records'] = len(set(universe))
        pairs[metadata['case_id']][metadata['variant']] = item
        costs[metadata['variant']].append(item)
    aggregates = {}
    for variant, rows in costs.items():
        aggregates[variant] = dict(calls=len(rows), returned=sum(r['status']=='returned' for r in rows),
            duplicate_sources=sum(r.get('duplicate_sources', 0) for r in rows),
            source_characters=sum(r.get('source_characters', 0) for r in rows),
            unique_source_characters=sum(r.get('unique_source_characters', 0) for r in rows),
            context_cpu_seconds=sum(r.get('cpu_seconds', 0) for r in rows),
            context_wall_seconds=sum(r.get('seconds', 0) for r in rows),
            latency_median_seconds=statistics.median(r['seconds'] for r in rows),
            serialized_tokens=sum(r.get('tokens', 0) for r in rows),
            max_serialized_tokens=max(r.get('tokens', 0) for r in rows),
            authority_false=all(r.get('authority_false', False) for r in rows),
            state_unchanged=all(r['database_unchanged'] and r['files_unchanged'] for r in rows))
    upstream = []
    for case_id, variants in pairs.items():
        baseline = variants.get('V0', {})
        for variant, row in variants.items():
            upstream.append(dict(case_id=case_id, variant=variant,
                same_multiset_as_V0=row['upstream_universe_hash']==baseline.get('upstream_universe_hash'),
                same_unique_set_as_V0=row['upstream_unique_universe_hash']==baseline.get('upstream_unique_universe_hash')))
    for path in sorted(run_dir.rglob('*')):
        if path.is_file():
            raw = path.read_bytes()
            manifest.append(dict(path=str(path), bytes=len(raw), sha256=digest(raw)))
    output.mkdir(parents=True, exist_ok=True)
    for name, value in [('COSTS.json', dict(variants=aggregates, preparations=records['preparations'],
        process_wall_seconds=records['seconds'], peak_rss_kib=records['peak_rss_kib'],
        model_calls=records['model_calls'], answer_calls=records['answer_calls'],
        monetary_cost='NOT MEASURED', answer_quality='NOT MEASURED',
        timing_boundary='traced installed-editable in-process public MCP, not stdio/startup/answer')),
        ('UPSTREAM_PARITY.json', upstream), ('RAW_MANIFEST.json', dict(artifacts=manifest)),
        ('PACKET_ACCOUNTING.json', dict(pairs))]:
        (output / name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    summarize(args.run_dir, args.output)
