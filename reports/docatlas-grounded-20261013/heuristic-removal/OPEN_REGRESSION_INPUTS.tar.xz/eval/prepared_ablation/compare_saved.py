"""Post-run exact-quote diagnostic and real common-budget costs, not semantics."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
from urllib.parse import unquote, urlparse

from eval.prepared_ablation.comparator import OfflineTokenizer
from eval.prepared_ablation.run import REPO, REPORT, load_dataset, save


def quote_delivery(case, oracle, source_root, rows):
    claims = []
    for claim in oracle.get('required_claims', []):
        alternatives = []
        for witness in claim.get('witness_sets', []):
            parts = []
            for part in witness['parts']:
                quote = ''.join((source_root / part['path']).read_text().splitlines(keepends=True)
                                [part['line_start']-1:part['line_end']]).strip()
                matched = [i for i, row in enumerate(rows)
                           if row['relative_path']==part['path'] and quote in row['content']]
                parts.append(dict(path=part['path'], line_start=part['line_start'], line_end=part['line_end'],
                    quote_sha256=hashlib.sha256(quote.encode()).hexdigest(), present=bool(matched), rows=matched))
            alternatives.append(dict(parts=parts, present=bool(parts) and all(p['present'] for p in parts)))
        claims.append(dict(id=claim['id'], documented=bool(alternatives),
                           present=any(a['present'] for a in alternatives), alternatives=alternatives))
    documented = [c for c in claims if c['documented']]
    return dict(claims=claims, all_documented_quotes_present=bool(documented) and all(c['present'] for c in documented))


def compare(grounded, output):
    tokenizer = OfflineTokenizer(REPORT / 'E/raw/o200k_base.tiktoken')
    config = json.loads((REPORT / 'RUN_CONFIG.json').read_text())
    results, costs = [], []
    for index, relative in enumerate(config['datasets']):
        dataset = REPO / relative
        cases, families = load_dataset(dataset)
        oracle = {c['id']: c for c in json.loads((dataset / 'gold_spans.json').read_text())['cases']}
        for case in cases:
            source_root = dataset / 'sources' / case['project_group']
            native_path = grounded / 'calls' / case['id'] / 'native.json'
            native = json.loads(native_path.read_text())
            for engine in ['Grounded', *config['variants']]:
                path = ((grounded / 'calls' / case['id'] / 'packed.json') if engine=='Grounded'
                        else grounded / 'docatlas-packed' / case['id'] / f'{engine}.json')
                packed = json.loads(path.read_text())
                rows = []
                errors = []
                for row in packed['payload']['sources']:
                    attribution = row['attribution']
                    if engine=='Grounded':
                        url = attribution.get('url', '')
                        absolute = Path(unquote(urlparse(url).path))
                        expected = grounded / 'families' / f'{index}-{case["project_group"]}' / 'corpus'
                        try:
                            relative_path = absolute.relative_to(expected.resolve()).as_posix()
                        except ValueError:
                            relative_path = None
                            errors.append('outside_copied_corpus')
                    else:
                        original = Path(attribution['path_or_url'])
                        if original.is_absolute():
                            # Lexical original runtime root available from saved metadata.
                            meta = json.loads((REPORT / 'attempt-01/calls' / case['id'] / engine / 'metadata.json').read_text())
                            relative_path = original.relative_to(meta['project_root']).as_posix()
                        else:
                            relative_path = original.as_posix()
                    if relative_path is None or not (source_root / relative_path).is_file():
                        errors.append('unknown_source')
                    rows.append(dict(relative_path=relative_path, content=row['content']))
                result = dict(split='H20' if index else 'V40', case_id=case['id'], engine=engine,
                    answerability=case['answerability'], errors=errors, source_count=len(rows),
                    strict_empty_source=not rows if case['answerability']=='unanswerable' else None,
                    exact_quote_diagnostic=quote_delivery(case, oracle[case['id']], source_root, rows))
                results.append(result)
                units = {(row['relative_path'], row['content']) for row in rows}
                costs.append(dict(split=result['split'], case_id=case['id'], engine=engine,
                    tokens=packed['packed_evidence_tokens'], native_tokens=packed['native_evidence_tokens'],
                    prefix_omitted=packed['omitted_suffix_results'], chars=sum(len(r['content']) for r in rows),
                    exact_unique_chars=sum(len(text) for _, text in units),
                    source_text_tokens=sum(tokenizer.count(r['content']) for r in rows),
                    exact_duplicate_results=len(rows)-len(units), source_count=len(rows)))
    aggregates, diagnostic = {}, {}
    for split in ('V40', 'H20'):
        aggregates[split], diagnostic[split] = {}, {}
        for engine in ['Grounded', *config['variants']]:
            rows = [r for r in costs if r['split']==split and r['engine']==engine]
            aggregates[split][engine] = dict(cases=len(rows), total_tokens=sum(r['tokens'] for r in rows),
                median_tokens=statistics.median(r['tokens'] for r in rows), max_tokens=max(r['tokens'] for r in rows),
                native_total_tokens=sum(r['native_tokens'] for r in rows),
                total_omitted_results=sum(r['prefix_omitted'] for r in rows),
                duplicate_results=sum(r['exact_duplicate_results'] for r in rows),
                source_characters=sum(r['chars'] for r in rows), exact_unique_characters=sum(r['exact_unique_chars'] for r in rows))
            items = [r for r in results if r['split']==split and r['engine']==engine]
            diagnostic[split][engine] = dict(positive_quotes=sum(r['answerability']=='within_budget' and
                r['exact_quote_diagnostic']['all_documented_quotes_present'] for r in items),
                partial_quotes=sum(r['answerability']=='partial' and r['exact_quote_diagnostic']['all_documented_quotes_present'] for r in items),
                negative_empty=sum(r['strict_empty_source'] is True for r in items), source_path_errors=sum(bool(r['errors']) for r in items))
    save(output / 'COMMON_BUDGET_COSTS.json', dict(cap=12000, tokenizer='offline o200k_base tiktoken0.11.0',
        budget_is_equal_ceiling_not_equal_spend=True, summary=aggregates, cases=costs,
        useful_vs_irrelevant_tokens='NOT MEASURED; text authenticity does not classify usefulness',
        actual_generator_prompt='NOT SENT', provider_usage=None, cost_usd=None))
    save(output / 'EXACT_QUOTE_DIAGNOSTIC_V1.json', dict(summary=diagnostic, cases=results,
        measurement='complete frozen part raw quote in one same-source packed result, outer whitespace trim only',
        limitations=['NOT exact span coverage or semantic sufficiency', 'false negatives from native Markdown parsing or split quotes',
                     'Grounded does not provide native raw-file hash/span; path inventory is separate',
                     'No stripping of meaningful Markdown/operators/identifiers/case']))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--grounded-dir', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    compare(args.grounded_dir.resolve(), args.output)
