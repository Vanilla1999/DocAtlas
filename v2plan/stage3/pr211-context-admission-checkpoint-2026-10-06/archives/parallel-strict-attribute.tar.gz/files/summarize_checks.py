"""Local diagnostic artifact summary, not a CI acceptance gate."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def roster(path):
    root = ET.parse(path).getroot()
    rows = {}
    for case in root.iter("testcase"):
        name = case.get("classname", "") + "::" + case.get("name", "")
        state = "pass"
        if case.find("failure") is not None or case.find("error") is not None:
            state = "fail"
        elif case.find("skipped") is not None:
            state = "skip"
        rows[name] = state
    return rows


baseline = roster("baseline-core.xml")
candidate = roster("candidate-core-v3.xml")
existing = {name: candidate[name] for name in baseline if name in candidate}
added = {name: state for name, state in candidate.items() if name not in baseline}
summary = {
    "baseline_sha": "37bfd0668f819935dd9e027bd9d8bf767fcd185a",
    "candidate_kind": "uncommitted_real_patch",
    "evidence_kind": "local_paired_diagnostic_not_full_ci",
    "baseline_counts": {state: list(baseline.values()).count(state) for state in ("pass", "fail", "skip")},
    "candidate_existing_counts": {state: list(existing.values()).count(state) for state in ("pass", "fail", "skip")},
    "missing_baseline_nodes": sorted(set(baseline) - set(candidate)),
    "new_existing_failure_ids": sorted(name for name in existing if existing[name] == "fail" and baseline[name] != "fail"),
    "removed_existing_failure_ids": sorted(name for name in existing if existing[name] != "fail" and baseline[name] == "fail"),
    "existing_failure_ids": sorted(name for name in existing if existing[name] == "fail"),
    "new_tests": added,
    "merge_ready": False,
}
Path("paired-core-comparison.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
