"""The late context route must retain the existing numeric-attribute boundary."""
from copy import deepcopy
from pathlib import Path
import shutil
from unittest.mock import patch

import pytest

from docmancer.docs.application.docs_context_projection import project_docs_context
from docmancer.docs.application import need_context_projection
from docmancer.docs.application.model_visible_projection import validate_model_visible_projection
from tests.docs._reference_binding_fixtures import capture_reference_case, visible
from eval.evidence_quality_v2.runtime import isolated_service, index_project
from eval.project_context_quality.capture_public_context import capture_public_call


QUESTION = "How many retry attempts does ProjectRetryPolicy allow?"
ANSWER = "ProjectRetryPolicy allows at most two retry attempts."


def _read_only(payload):
    assert payload["answer_supported"] is False
    assert payload["answer_available"] is False
    assert payload["edit_ready"] is False


@pytest.mark.parametrize("body", [
    ANSWER,
    "# Retry policy\n\n## ProjectRetryPolicy\n\n" + ANSWER,
    "# Retry policy\n\n" + ANSWER + "\n\nOtherWorker allows nine retry attempts.",
])
def test_numeric_value_is_delivered_in_final_citation(tmp_path, body):
    capture = capture_reference_case(tmp_path, {"Guide.md": body}, QUESTION)
    payload = capture["public_payload"]
    assert payload["status"] == "ok"
    assert payload["context_available"] is True
    assert ANSWER in visible(capture)
    assert {row["path_or_url"] for row in payload["sources"]} == {"Guide.md"}
    assert all(row["project_identity"] for row in payload["sources"])
    _read_only(payload)


@pytest.mark.parametrize("body", [
    "OrderSubmission validates a draft and delegates network retry decisions to ProjectRetryPolicy.",
    "ProjectRetryPolicy delegates retry decisions.\n\nOtherWorker allows nine retry attempts.",
    "ProjectRetryPolicy.\n\nAn unrelated worker has retry telemetry.",
])
def test_missing_subject_value_cannot_reenter_through_late_fallback(tmp_path, body):
    with patch.object(need_context_projection, "project_need_context_fallback",
                      wraps=need_context_projection.project_need_context_fallback) as late_fallback:
        capture = capture_reference_case(tmp_path, {"Guide.md": body}, QUESTION)
    assert late_fallback.call_count == 0
    payload = capture["public_payload"]
    assert payload["status"] == "insufficient_evidence"
    assert payload["context_available"] is False
    assert not payload.get("sources")
    _read_only(payload)
    attempts = capture["projection_attempts"]
    assert attempts
    diagnostics = attempts[-1]["after_projection"]["retrieval_diagnostics"]["docs_context_projection"]
    assert diagnostics["decision_trace"]["counts"]["candidate:missing_attribute"] >= 1
    assert diagnostics["final_visible_evidence_ids"] == []


def test_unknown_partial_context_remains_available(tmp_path):
    question = ("Please explain the documented retry scheduling behavior of RelayClient "
                "and its interaction with worker pressure.")
    body = "RelayClient retry scheduling uses a bounded queue."
    capture = capture_reference_case(tmp_path, {"Guide.md": body}, question)
    payload = capture["public_payload"]
    assert payload["status"] == "ok"
    assert payload["context_available"] is True
    assert body in visible(capture)
    assert payload["retrieval_coverage"] == "partial"
    assert "query-original" not in payload["covered_query_ids"]
    assert "query-original" in payload["missing_query_ids"]
    _read_only(payload)
    attempt = capture["projection_attempts"][-1]
    assert attempt["before_projection"]["documentation_query_plan"]["component_scope_complete"] is False
    diagnostics = attempt["after_projection"]["retrieval_diagnostics"]["docs_context_projection"]
    assert diagnostics["need_context_fallback"]


@pytest.mark.parametrize("local_value", [False, True])
def test_module_scope_cannot_borrow_project_numeric_policy(tmp_path, local_value):
    root = tmp_path / "project"
    fixture = (Path(__file__).resolve().parents[2] / "eval" / "agent_developer_v1"
               / "projects" / "explicit_manifest_monorepo")
    shutil.copytree(fixture, root)
    if local_value:
        local_doc = root / "packages/orders/README.md"
        local_doc.write_text(local_doc.read_text(encoding="utf-8") + "\n\n" + ANSWER + "\n",
                             encoding="utf-8")
    with isolated_service(tmp_path / "state") as (service, config):
        index_project(service, config, root)
        capture = capture_public_call(service, {
            "project_path": str(root), "question": QUESTION,
            "scope": "module", "module_path": "packages/orders",
        })
    payload = capture["public_payload"]
    if local_value:
        assert payload["status"] == "ok"
        assert payload["context_available"] is True
        assert ANSWER in visible(capture)
        assert {row["path_or_url"] for row in payload["sources"]} == {"packages/orders/README.md"}
    else:
        assert payload["status"] == "insufficient_evidence"
        assert payload["context_available"] is False
        assert not payload.get("sources")
    _read_only(payload)


@pytest.mark.parametrize("corruption", ["identity", "stale", "unsafe", "unsynchronized"])
def test_numeric_witness_does_not_override_source_policy(tmp_path, corruption):
    capture = capture_reference_case(tmp_path, {"Guide.md": ANSWER}, QUESTION)
    retrieval = deepcopy(capture["projection_attempts"][0]["before_projection"])
    # Keep the real query contract, trusted request identity and prepared spans;
    # corrupt only the candidate, not the qualification implementation.
    for source in retrieval["context_pack"]:
        if corruption == "identity":
            source["project_identity"] = "local:foreign-project"
        elif corruption == "stale":
            source["freshness"] = "stale"
        elif corruption == "unsafe":
            source["risk_flags"] = ["prompt_injection"]
        else:
            source["index_freshness"] = "unsynchronized"
    payload, snapshot = project_docs_context(retrieval=retrieval)
    assert payload["status"] == "insufficient_evidence"
    assert payload["context_available"] is False
    assert not payload.get("sources")
    _read_only(payload)
    assert validate_model_visible_projection(payload, snapshot=snapshot, max_tokens=800) == []
