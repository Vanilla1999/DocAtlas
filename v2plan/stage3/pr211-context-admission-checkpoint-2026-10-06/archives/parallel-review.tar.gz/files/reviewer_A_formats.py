"""Native public-pipeline numeric formatting probes, not acceptance gold."""
import json
import hashlib
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from tests.docs._reference_binding_fixtures import capture_reference_case, visible
from docmancer.docs.application import _docs_context_projection_core as core

QUESTION = 'How many retry attempts does ProjectRetryPolicy allow?'
CASES = {
    'digits': 'ProjectRetryPolicy allows at most 2 retry attempts.',
    'heading_attribute': '# ProjectRetryPolicy\n\nRetry attempts: 2.',
    'table': '# ProjectRetryPolicy\n\n| Setting | Value |\n| --- | --- |\n| Retry attempts | 2 |',
    'code': '# ProjectRetryPolicy\n\nRetry attempts are configured as follows:\n\n```json\n{"retry_attempts": 2}\n```',
    'twice': 'ProjectRetryPolicy allows the operation to be retried twice.',
    'heading_prose': '# ProjectRetryPolicy\n\nThe retry policy allows at most two attempts.',
    'other_subject_same_sentence': 'ProjectRetryPolicy delegates retry decisions to OtherWorker, which allows nine retry attempts.',
    'useful_lookup': 'ProjectRetryPolicy delegates retry decisions.\n\nThe diagnostic command is `inspect-retries`.',
}
rows = []
for name, body in CASES.items():
    with TemporaryDirectory(dir=Path(__file__).parent, prefix='.reviewer-A-') as tmp:
        capture = capture_reference_case(Path(tmp), {'Guide.md': body}, QUESTION,
                                         lookups=('What diagnostic command is documented for ProjectRetryPolicy?',) if name == 'useful_lookup' else ())
    payload = capture['public_payload']
    row = {'case': name, 'body': body, 'capture': capture,
           'python': sys.executable, 'version': sys.version,
           'product_sha256': hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest()}
    rows.append(row)
    print(name, payload['status'], repr(visible(capture)), flush=True)
Path(sys.argv[1]).write_text(json.dumps(rows, indent=2))
