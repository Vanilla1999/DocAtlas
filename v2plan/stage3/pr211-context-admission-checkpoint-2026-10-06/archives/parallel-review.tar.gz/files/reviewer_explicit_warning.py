"""Independent request-relevance control; only local diagnostic code changes."""
from pathlib import Path

path = Path(__file__).with_name('authority_diagnostic.py')
source = path.read_text()
source = source.replace("rows = []", "fixture_source = fixture_source.replace('EvidenceRequirementSet, SupportDecision, and decision_hash?', 'EvidenceRequirementSet, SupportDecision, and decision_hash? What warning is shown when the hash changes?')\nrows = []")
source = source.replace("authority-paired-evidence.json", "reviewer-explicit-warning-evidence.json")
exec(compile(source, str(path), 'exec'), {'__file__': str(path), '__name__': '__main__'})
