"""Read-only independent verification of author's XML and local numeric captures."""
from collections import Counter
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path('/tmp/opencode/pr211-parallel-strict-attribute')
def roster(name):
    rows = []
    for case in ET.parse(root / name).getroot().iter('testcase'):
        key = case.get('classname', '') + '::' + case.get('name', '')
        state = 'fail' if case.find('failure') is not None or case.find('error') is not None else 'skip' if case.find('skipped') is not None else 'pass'
        rows.append((key, state))
    assert len(rows) == len(dict(rows)), 'duplicate node would invalidate dict comparison'
    return dict(rows)
b = roster('baseline-core.xml')
c = roster('candidate-core-v3.xml')
summary = {
    'baseline': dict(Counter(b.values())), 'candidate': dict(Counter(c.values())),
    'missing': sorted(set(b) - set(c)),
    'existing_status_changes': [k for k in b if c.get(k) != b[k]],
    'added': {k: c[k] for k in c.keys() - b.keys()},
    'advanced': dict(Counter(roster('candidate-final-advanced.xml').values())),
}
rows_b = {r['case']: r for r in json.loads(Path('reviewer-A-formats-baseline.json').read_text())}
rows_c = {r['case']: r for r in json.loads(Path('reviewer-A-formats-candidate.json').read_text())}
summary['numeric_probes'] = []
for name, before in rows_b.items():
    after = rows_c[name]
    cap_b, cap_c = before['capture'], after['capture']
    plans = [cap['projection_attempts'][0]['before_projection']['documentation_query_plan'] for cap in (cap_b, cap_c)]
    summary['numeric_probes'].append({
        'case': name, 'statuses': [cap['public_payload']['status'] for cap in (cap_b, cap_c)],
        'component_scope_complete': [p.get('component_scope_complete') for p in plans],
        'component_contract': [p.get('_component_contract') for p in plans],
        'product_hashes': [before['product_sha256'], after['product_sha256']],
        'python_equal': before['python'] == after['python'] and before['version'] == after['version'],
    })
Path('reviewer-A-evidence-audit.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
