"""Observe actual pre/post projection lengths; no replacement of product behavior."""
import json
from pathlib import Path
import pytest

class Observer:
    def pytest_collection_modifyitems(self, items):
        modules = {item.module for item in items if item.module.__name__.endswith('test_pr211_hint_public_audit')}
        for module in modules:
            real = module.capture_public_call
            def capture(service, request, real=real):
                result = real(service, request)
                Path('reviewer-crop-capture.json').write_text(json.dumps(result, indent=2))
                for attempt in result['projection_attempts']:
                    pack = attempt['before_projection'].get('context_pack', [])
                    print('BEFORE_CONTENT_LENGTHS', [len(s.get('content', '')) for s in pack])
                    print('BEFORE_CONTENT', [s.get('content', '') for s in pack])
                print('FINAL_LENGTHS', [len(s.get('snippet', '')) for s in result['public_payload'].get('sources', [])])
                return result
            module.capture_public_call = capture

raise SystemExit(pytest.main(['tests/docs/test_pr211_hint_public_audit.py', '-k', 'crop', '-q', '-s'], plugins=[Observer()]))
