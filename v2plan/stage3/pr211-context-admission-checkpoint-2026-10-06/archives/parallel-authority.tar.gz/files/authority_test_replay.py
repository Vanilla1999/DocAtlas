"""Run unchanged targeted tests on baseline or the isolated B counterfactual."""
import inspect
import os
import sys
from types import FunctionType
import pytest
from docmancer.docs.application import _docs_context_projection_core as core

if os.environ.get('AUTHORITY_CANDIDATE') == '1':
    original = core.project_docs_context
    source = inspect.getsource(original)
    needle = '            and query_plan.get("component_scope_complete", True)\n'
    assert source.count(needle) == 1
    scope = dict(core.__dict__)
    exec(compile(source.replace(needle, ''), '<authority-counterfactual>', 'exec'), scope)
    template = scope['project_docs_context']
    candidate = FunctionType(template.__code__, core.__dict__, template.__name__, template.__defaults__)
    candidate.__kwdefaults__ = template.__kwdefaults__
    core.project_docs_context = candidate
sys.exit(pytest.main(sys.argv[1:]))
