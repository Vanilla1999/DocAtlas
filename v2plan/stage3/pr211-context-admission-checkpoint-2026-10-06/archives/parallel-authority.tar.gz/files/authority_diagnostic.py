"""Isolated paired Task B diagnostic; no production patch or changed gold."""
import copy
import inspect
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from types import FunctionType

import pytest
from tests import test_docs_service_part03 as fixture
from docmancer.docs.application import _docs_context_projection_core as core

ROOT = Path(__file__).resolve().parent
original = core.project_docs_context
source = inspect.getsource(original)
needle = '            and query_plan.get("component_scope_complete", True)\n'
assert source.count(needle) == 1
namespace = dict(core.__dict__)
exec(compile(source.replace(needle, ''), '<authority-counterfactual>', 'exec'), namespace)
template = namespace['project_docs_context']
candidate = FunctionType(template.__code__, core.__dict__, template.__name__, template.__defaults__)
candidate.__kwdefaults__ = template.__kwdefaults__

fact = 'A changed hash produces a red warning.'
fixture_source = inspect.getsource(fixture.test_project_query_does_not_return_non_project_docs_with_same_terms)
fixture_source = fixture_source.split('    assert payload is not None')[0] + '    return payload\n'
rows = []
for case in ('distractor', 'useful', 'independent', 'same_source'):
    text = fixture_source
    if case in ('useful', 'independent'):
        start = text.index('    distractor = (')
        end = text.index('    for index', start)
        note = ('# Presentation plan notes\n\n'
                'Phase 2.3 presentation-only snippets mention EvidenceRequirementSet, '
                'SupportDecision, and decision_hash, but this supporting note does not '
                'define the acceptance contract.\n' + fact + '\n')
        text = text[:start] + '    distractor = ' + repr(note) + '\n' + text[end:]
    if case == 'independent':
        text = text.replace('"question": question,', '"question": question, "lookup_queries": ["When decision_hash changes, what warning is shown?"],')
    if case == 'same_source':
        text = text.replace('Every public mode preserves the same decision_hash and selected evidence IDs.',
                            'Every public mode preserves the same decision_hash and selected evidence IDs.\n\n' + fact)
    scope = dict(fixture.__dict__)
    exec(compile(text, '<paired-authority-fixture>', 'exec'), scope)
    for variant in ('baseline', 'candidate'):
        traces = []
        target = original if variant == 'baseline' else candidate
        def traced(**kwargs):
            result = target(**kwargs)
            retrieval = kwargs['retrieval']
            traces.append(copy.deepcopy({
                'plan': retrieval.get('documentation_query_plan'),
                'diagnostics': retrieval.get('retrieval_diagnostics'),
            }))
            return result
        core.project_docs_context = traced
        with TemporaryDirectory(dir=ROOT, prefix='.authority-probe-') as tmp:
            with pytest.MonkeyPatch.context() as mp:
                payload = scope['test_project_query_does_not_return_non_project_docs_with_same_terms'](Path(tmp), mp)
        row = {'case': case, 'variant': variant, 'payload': payload, 'traces': traces}
        rows.append(row)
        print(case, variant, payload['status'], [s['path_or_url'] for s in payload.get('sources', [])],
              'fact_visible=', fact in '\n'.join(s.get('snippet', '') for s in payload.get('sources', [])), flush=True)
core.project_docs_context = original
(ROOT / 'authority-paired-evidence.json').write_text(json.dumps(rows, indent=2, default=str))
indexed = {(row['case'], row['variant']): row for row in rows}
for case in ('distractor', 'useful', 'same_source'):
    for variant in ('baseline', 'candidate'):
        row = indexed[case, variant]
        assert row['payload']['sources'][0]['path_or_url'] == 'zz-authoritative-plan.md'
        assert row['traces'][0]['plan']['component_scope_complete'] is False
for case in ('useful', 'independent', 'same_source'):
    assert fact in '\n'.join(s['snippet'] for s in indexed[case, 'baseline']['payload']['sources'])
assert fact not in '\n'.join(s['snippet'] for s in indexed['useful', 'candidate']['payload']['sources'])
assert indexed['useful', 'candidate']['traces'][0]['diagnostics']['docs_context_projection']['decision_trace']['counts']['selection:authority_duplicate'] > 0
for case in ('independent', 'same_source'):
    assert fact in '\n'.join(s['snippet'] for s in indexed[case, 'candidate']['payload']['sources'])
for row in rows:
    assert row['payload']['answer_supported'] is False
    assert row['payload']['edit_ready'] is False
print('PASS diagnostic assertions: paired authoritative-first loss reproduced; REJECT B')
