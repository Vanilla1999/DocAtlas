"""Read-only production audit; native fixtures, no replacement decision functions."""
import hashlib
import json
from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory

from docmancer.docs.application import _docs_context_projection_core as core
from docmancer.docs.application.context_selection import component_witnesses
from docmancer.docs.domain.project_answer_contract import build_project_answer_contract
from tests.docs._reference_binding_fixtures import capture_reference_case, visible


QUESTION = "How many retry attempts does ProjectRetryPolicy allow?"
CASES = {
    "no_value": "OrderSubmission validates a draft and delegates network retry decisions to ProjectRetryPolicy.",
    "literal_value": "ProjectRetryPolicy allows at most two retry attempts.",
    "split_attribute": "ProjectRetryPolicy retry policy allows at most two attempts.",
    "heading_value": "# ProjectRetryPolicy\n\nThe retry policy allows at most two attempts.",
    "foreign_value_same_sentence": "ProjectRetryPolicy delegates retry decisions to OtherWorker, which allows nine retry attempts.",
    "explicit_lookup": "ProjectRetryPolicy delegates retry decisions.\n\nThe diagnostic command is `inspect-retries`.",
}


def main():
    root = Path(__file__).resolve().parent
    contract = build_project_answer_contract(QUESTION)
    results = []
    for name, text in CASES.items():
        # This is a separate unit probe, not a claim about pipeline metadata.
        source = {
            "source_class": "project_doc", "project_identity": "probe-project",
            "authority": "source_of_truth", "path": "Guide.md", "snippet": text,
        }
        witnesses = component_witnesses(source, contract.proof_obligations)
        lookups = ("What diagnostic command is documented for ProjectRetryPolicy?",) if name == "explicit_lookup" else ()
        with TemporaryDirectory(dir=root, prefix=".decision-probe-") as directory:
            capture = capture_reference_case(Path(directory), {"Guide.md": text}, QUESTION, lookups=lookups)
        payload = capture["public_payload"]
        results.append({
            "name": name, "body": text, "lookups": lookups,
            "unit_component_witnesses": witnesses, "capture": capture,
        })
        print(json.dumps({
            "name": name, "unit_witness": bool(witnesses), "status": payload["status"],
            "visible": visible(capture), "covered": payload.get("covered_query_ids"),
            "missing": payload.get("missing_query_ids"),
        }, ensure_ascii=False), flush=True)
    result = {
        "question": QUESTION, "obligations": [asdict(o) for o in contract.proof_obligations],
        "projection_sha256": hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest(),
        "rows": results,
    }
    (root / "decision_probe.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
