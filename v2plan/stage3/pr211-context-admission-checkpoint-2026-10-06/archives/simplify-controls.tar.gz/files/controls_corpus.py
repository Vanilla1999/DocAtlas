"""Ten synthetic controls; expectations come from question/source, not proof verdicts."""

QUESTION = "How many retry attempts does ProjectRetryPolicy allow?"
EXACT = "ProjectRetryPolicy allows at most two retry attempts."
OWN_CLAUSE = "ProjectRetryPolicy allows at most two retry attempts"
SPLIT = "ProjectRetryPolicy retry policy allows at most two attempts."
HEADING_EXACT = "# ProjectRetryPolicy\n\nThe policy allows at most two retry attempts."
HEADING_SPLIT = "# ProjectRetryPolicy\n\nThe retry policy allows at most two attempts."
DELEGATION = "ProjectRetryPolicy delegates retry decisions to OtherWorker."
OTHER = "ProjectRetryPolicy delegates retry decisions to OtherWorker, which allows nine retry attempts."
COMMAND = "The diagnostic command for ProjectRetryPolicy is `inspect-retries`."


def numeric(name, text, *, required=(), absent=False, admission="deliver_fact", lookups=()):
    return {
        "id": name, "question": QUESTION, "documents": {"Guide.md": text},
        "lookups": list(lookups), "required_visible": list(required),
        "numeric_answer_absent_in_source": absent,
        "desired_admission": admission,
        "fact_basis": (
            "Source explicitly binds at most two attempts to ProjectRetryPolicy; retain the quoted fact and its subject."
            if not absent else
            "No count for ProjectRetryPolicy is stated; delegation does not transfer another subject's count."
        ),
        "forbidden_claims": [
            "Answer/edit authority from retrieval alone.",
            *(["A numeric answer for ProjectRetryPolicy, including nine inherited from OtherWorker."] if absent else []),
        ],
        "unresolved_contract": (
            "Strict no-value refusal versus safe partial read-context requires owner agreement; no source-count gold."
            if absent else "No unresolved recall tradeoff: this short safe source states the requested fact."
        ),
    }


CASES = [
    numeric("A0_no_value", DELEGATION, absent=True, admission="prefer_refusal"),
    numeric("A1_inline_exact", OWN_CLAUSE + ", while OtherWorker allows nine retry attempts.",
            required=(OWN_CLAUSE,)),
    numeric("A2_heading_exact", HEADING_EXACT,
            required=("# ProjectRetryPolicy", "The policy allows at most two retry attempts.")),
    numeric("A3_inline_split", SPLIT, required=(SPLIT,)),
    numeric("A4_heading_split", HEADING_SPLIT,
            required=("# ProjectRetryPolicy", "The retry policy allows at most two attempts.")),
    numeric("A5_other_subject_same_sentence", OTHER, absent=True, admission="prefer_refusal"),
    numeric("A6_independent_lookup", DELEGATION + "\n\n" + COMMAND,
            required=(COMMAND,), absent=True, admission="deliver_lookup_only",
            lookups=("What diagnostic command is documented for ProjectRetryPolicy?",)),
]
CASES[-1]["fact_basis"] += " The explicit host lookup requests the documented diagnostic command, inspect-retries."
CASES[-1]["unresolved_contract"] = (
    "Desired: retain the independent command as retrieval-only context. Whether strict numeric refusal may veto "
    "a useful explicit lookup is unresolved; lookup coverage never supplies the missing numeric obligation."
)

# Source text and 24-note layout from tests/test_docs_service_part03.py:5-83.
# Explicit question extension makes the supporting fact relevant BEFORE observing ranking.
AUTHORITY = """# Approved retrieval plan

## Phase 2.3: presentation-only snippets

EvidenceRequirementSet and SupportDecision are canonical selector inputs.
Presentation cannot determine support or drop a mandatory-facet witness.
Every public mode preserves the same decision_hash and selected evidence IDs.

## Phase 3.1: dispatcher reuse

Library lexical retrieval invokes RetrievalDispatcher with the raw topic unchanged.
EvidenceRequirementSet supplies recall hints but never a second support decision.
The first production mode remains lexical and must not call vectors or embeddings.

## Phase 3.1: index-witness retrieval-miss classification

Files:

- docmancer/docs/application/library_docs_service.py
- docmancer/docs/infrastructure/agent_index_gateway.py

Classify retrieval_miss only when the complete same-library, exact-version corpus
contains mandatory-requirement witnesses confirmed by a bounded index-level probe
outside the selected candidates. Never infer retrieval_miss from an empty candidate
list. Keep the default lexical path provider-free: it makes no vector, embedding,
or provider calls.
"""
NOTE = (
    "# Presentation plan notes\n\nPhase 2.3 presentation-only snippets mention EvidenceRequirementSet, "
    "SupportDecision, and decision_hash, but this supporting note does not define the acceptance contract.\n"
)
WARNING = "When decision_hash changes, the presentation shows the red warning `Decision changed`."
B_QUESTION = (
    "What exact Phase 2.3 presentation-only snippet contract governs EvidenceRequirementSet, "
    "SupportDecision, and decision_hash? What warning is shown when decision_hash changes?"
)
for name, note in (("B0_distractor", NOTE), ("B1_requested_supporting_fact", NOTE + WARNING + "\n")):
    CASES.append({
        "id": name, "question": B_QUESTION,
        "documents": {
            "zz-authoritative-plan.md": AUTHORITY,
            "README.md": "# Project overview\n\nThis repository owns the approved retrieval plan.\n",
            **{f"docs/note-{i:02d}.md": note for i in range(24)},
        },
        "authority_fixture": True, "lookups": [],
        "required_visible": ["Every public mode preserves the same decision_hash and selected evidence IDs."]
                            + ([WARNING] if name.startswith("B1") else []),
        "desired_admission": "retain_authoritative_and_requested_support_only",
        "fact_basis": "Question explicitly requests both the contract and warning. The plan states the contract; only B1 states the warning.",
        "forbidden_claims": ["Supporting note defines the normative acceptance contract.",
                             "A mention of decision_hash proves the warning or completes the contract.",
                             "Answer/edit authority from retrieval alone."],
        "unresolved_contract": "B branch discriminator requires naturally authoritative-first selection and incomplete component scope. Otherwise reject this control for B, regardless of fact delivery.",
    })

# One continuous paragraph prevents an unrelated heading section from being removed
# by ingestion before it can reach projection. Actual pre/post bytes decide usefulness.
CROP_TAIL = "The diagnostic archive stores completed request logs for later operator inspection."
CROP = EXACT + " " + " ".join([
    "A failed request is recorded in the local diagnostic journal before the worker is scheduled again.",
    "The scheduler maintains a separate queue for each active worker and releases completed entries promptly.",
    "Operators can inspect the request journal while background workers continue processing queued entries.",
    "Each journal entry includes the original request identifier and the most recent completion timestamp.",
    "The request journal is copied into the diagnostic archive after the worker finishes its cleanup procedure.",
    "Archive records include the final worker state so operators can distinguish a completed request from an abandoned one.",
    CROP_TAIL,
])
CASES.append(numeric("C0_real_projection_crop", CROP, required=(EXACT,)))
CASES[-1]["crop_probe"] = {"non_required_tail": CROP_TAIL}
CASES[-1]["unresolved_contract"] = (
    "Count as a crop control only if an actual incoming projection window containing the requested numeric fact "
    "loses a complete non-required proposition in final bytes. No anchor-only attribution or heterogeneous merge claim."
)
