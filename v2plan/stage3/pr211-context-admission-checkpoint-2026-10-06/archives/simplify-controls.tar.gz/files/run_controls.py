"""Standalone native public-pipeline diagnostic; exit 0 means capture, not acceptance.

Run in this worktree with its PYTHONPATH and the offline environment in REPORT_RU.md.
No candidate patch, replacement retrieval, ranking changes, or fabricated final packet.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

from controls_corpus import CASES
from docmancer.docs.domain import _answer_units_part02 as proof_module
from docmancer.docs.application import _docs_context_projection_core as core
from docmancer.docs.application.model_visible_projection import validate_model_visible_projection
from docmancer.docs.application.model_visible_projection_helpers import docs_context_budget_tokens
from docmancer.docs.application.projection_decision_trace import _key as trace_key
from eval.evidence_quality_v2.runtime import write_project, isolated_service, index_project
from eval.project_context_quality.capture_public_context import capture_public_call
from tests.docs._reference_binding_fixtures import capture_reference_case

ROOT = Path(__file__).resolve().parent
BASELINE = "37bfd0668f819935dd9e027bd9d8bf767fcd185a"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@contextmanager
def observe_proofs():
    """Delegate unchanged and record actual local decisions, never assert their truth."""
    real = proof_module.local_proof_for_obligation
    rows = {}

    def observe(obligation, unit, *, source=None):
        result = real(obligation, unit, source=source)
        row = {"obligation": asdict(obligation), "unit": asdict(unit),
               "source": dict(source or {}), "observed_local_proof": asdict(result)}
        key = json.dumps(row, sort_keys=True, default=str)
        rows.setdefault(key, {**row, "calls": 0})["calls"] += 1
        return result

    with patch.object(proof_module, "local_proof_for_obligation", observe):
        yield rows


def capture_case(tmp, case):
    if not case.get("authority_fixture"):
        return capture_reference_case(tmp, case["documents"], case["question"],
                                      lookups=tuple(case["lookups"]))
    # Native runtime with the original B fixture's authority manifest, written only
    # in this run's temporary corpus. No rank/parser/dispatcher overrides.
    import yaml
    root = tmp / "corpus"
    write_project(root, case["documents"])
    manifest = {
        "schema_version": 1,
        "documents": [
            dict(path="zz-authoritative-plan.md", role="development", scope="project",
                 description="Approved implementation plan and acceptance contract.",
                 authority="source_of_truth", status="active", impact="track"),
            dict(path="README.md", role="overview", scope="project", description="Project overview.",
                 authority="supporting", status="active", impact="track"),
        ],
        "roots": [dict(path="docs", scope="project", authority="supporting")],
    }
    (root / "docatlas.project-docs.yaml").write_text(yaml.safe_dump(manifest), encoding="utf-8")
    with isolated_service(tmp / "state") as (service, config):
        index_project(service, config, root)
        return capture_public_call(service, {
            "project_path": str(root), "scope": "project", "question": case["question"],
        })


def validate_capture(capture, case):
    """Infrastructure checks only, independent of desired selection/proof verdicts."""
    payload = capture["public_payload"]
    assert docs_context_budget_tokens(payload) <= 800
    assert len(payload.get("sources") or []) <= 3
    for source in payload.get("sources") or []:
        text = case["documents"][source["path_or_url"]]
        start, end = source["line_start"], source["line_end"]
        assert type(start) is int and type(end) is int
        assert 1 <= start <= end <= len(text.splitlines())
        assert source["snippet"] in "\n".join(text.splitlines()[start - 1:end])
    for attempt in capture["projection_attempts"]:
        assert validate_model_visible_projection(
            attempt["projected_payload"], snapshot=attempt["snapshot"], max_tokens=800,
        ) == []


def summarize(capture, case):
    payload = capture["public_payload"]
    sources = payload.get("sources") or []
    snippets = [s["snippet"] for s in sources]
    # Require subject + answer to coexist in one visible source, not separate docs.
    delivered = all(any(fact in snippet for snippet in snippets) for fact in case["required_visible"])
    bound_delivery = any(all(fact in snippet for fact in case["required_visible"]) for snippet in snippets)
    attempts = capture["projection_attempts"]
    plans = [a["before_projection"].get("documentation_query_plan", {}) for a in attempts]
    counts = [a["after_projection"].get("retrieval_diagnostics", {}).get(
        "docs_context_projection", {}).get("decision_trace", {}).get("counts", {}) for a in attempts]
    summary = {
        "status": payload.get("status"), "kind": payload.get("kind"),
        "source_paths": [s["path_or_url"] for s in sources],
        "required_facts_delivered": delivered if case["required_visible"] else None,
        "required_facts_same_source": bound_delivery if case["required_visible"] and not case.get("authority_fixture") else None,
        "authority_flags": {k: payload.get(k) for k in ("answer_supported", "answer_available", "edit_ready")},
        "forbidden_authority_observed": any(payload.get(k) is True for k in ("answer_supported", "answer_available", "edit_ready")),
        "facet_coverage": payload.get("facet_coverage"), "facets": payload.get("facets"),
        "covered_query_ids": payload.get("covered_query_ids"),
        "missing_query_ids": payload.get("missing_query_ids"),
        "component_scope_complete": [p.get("component_scope_complete") for p in plans],
        "component_contracts": [p.get("_component_contract") for p in plans],
        "decision_counts": counts,
        "desired_admission": case["desired_admission"],
        "refusal_preference_met": not sources if case["desired_admission"] == "prefer_refusal" else None,
    }
    if case.get("authority_fixture"):
        before = attempts[0]["before_projection"]
        identities = {
            trace_key(s.get("project_identity"), s.get("stable_id") or s.get("stable_chunk_id")
                      or s.get("evidence_id") or s.get("path") or s.get("source")):
            {"path": s.get("path"), "authority": s.get("authority")}
            for s in before.get("context_pack") or []
        }
        trace = attempts[0]["after_projection"]["retrieval_diagnostics"]["docs_context_projection"]["decision_trace"]
        accepted = [identities.get(e["candidate_key"], {"unmapped": e["candidate_key"]})
                    for e in trace["events"] if e["stage"] == "selection" and e["decision"] == "accepted"]
        summary["B_observed_acceptance_order"] = accepted
        summary["B_discriminator_preconditions"] = {
            "naturally_authoritative_first": bool(accepted and accepted[0].get("authority") == "source_of_truth"
                                                   and not trace.get("selection_events_omitted")),
            "incomplete_plan": bool(plans and plans[0].get("component_scope_complete") is False),
            "supporting_visible": any(s["authority"] == "supporting" for s in sources),
        }
    if case.get("crop_probe"):
        tail = case["crop_probe"]["non_required_tail"]
        crops = []
        for index, attempt in enumerate(attempts):
            for incoming in attempt["before_projection"].get("context_pack") or []:
                before = incoming.get("content") or incoming.get("display_text") or incoming.get("snippet") or ""
                for final in sources:
                    if incoming.get("path") != final["path_or_url"]:
                        continue
                    after = final["snippet"]
                    crops.append({
                        "attempt": index, "path": final["path_or_url"],
                        "incoming_stable_chunk_id": incoming.get("stable_chunk_id"),
                        "incoming_source_snapshot_sha256": incoming.get("_source_snapshot_sha256"),
                        "final_evidence_id": final.get("evidence_id"),
                        "before": before, "after": after,
                        "before_chars": len(before), "after_chars": len(after),
                        "meaningful_crop": tail in before and tail not in after and after in before
                            and incoming.get("project_identity") == final.get("project_identity")
                            and all(fact in before and fact in after for fact in case["required_visible"]),
                    })
        summary["crop_windows"] = crops
        summary["crop_control_valid"] = any(row["meaningful_crop"] for row in crops)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="controls-baseline.json")
    parser.add_argument("--case", action="append", help="Exact case ID; repeat to select a subset")
    parser.add_argument("--label", default="baseline", help="Capture label; candidate never modifies product")
    args = parser.parse_args()
    assert Path.cwd().resolve() == ROOT, "Run only from this worktree"
    assert git("branch", "--show-current") == "diagnostic/pr211-simplify-controls-20261006"
    assert git("rev-parse", "HEAD") == BASELINE
    for key in ("DOCATLAS_OFFLINE", "HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE"):
        assert os.environ.get(key) == "1", key
    assert Path(core.__file__).resolve().is_relative_to(ROOT)
    if args.label == "baseline":
        assert not git("diff", "HEAD", "--", "docmancer", "tests", "eval"), "Baseline must be unmodified"
    selected = [case for case in CASES if not args.case or case["id"] in args.case]
    assert selected and (not args.case or set(args.case) <= {c["id"] for c in CASES})
    output = (ROOT / args.output).resolve()
    assert output.is_relative_to(ROOT)
    record = {
        "label": args.label, "head": git("rev-parse", "HEAD"), "python": sys.executable,
        "python_version": sys.version, "corpus_sha256": sha(ROOT / "controls_corpus.py"),
        "runner_sha256": sha(__file__), "lock_sha256": sha(ROOT / "uv.lock"),
        "projection_sha256": sha(core.__file__), "proof_sha256": sha(proof_module.__file__),
        "tracked_diff": git("diff", "HEAD", "--"), "rows": [],
        "meaning": "Observed public packets and source-derived desired acceptance; no local proof verdict is gold.",
    }
    for case in selected:
        with TemporaryDirectory(dir=ROOT, prefix=".controls-") as tmp, observe_proofs() as proofs:
            capture = capture_case(Path(tmp), case)
            validate_capture(capture, case)
        summary = summarize(capture, case)
        record["rows"].append({"case": case, "observations": summary,
                               "local_proof_observations": list(proofs.values()), "capture": capture})
        output.write_text(json.dumps(record, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
        print(case["id"], json.dumps(summary, ensure_ascii=False), flush=True)
    print(f"CAPTURED {len(selected)} cases; no aggregate acceptance/PASS count. {output.name}")


if __name__ == "__main__":
    main()
