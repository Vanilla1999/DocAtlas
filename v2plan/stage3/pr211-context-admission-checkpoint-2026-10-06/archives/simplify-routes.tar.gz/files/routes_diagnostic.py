"""Offline read-only audit; in-memory local-expression prototype, no file patch."""
from collections import Counter
from contextlib import ExitStack
from copy import deepcopy
from dataclasses import asdict
from hashlib import sha256
import inspect
import json
from pathlib import Path
import sys
from types import CodeType, FunctionType
from unittest.mock import patch

from docmancer.docs.application import context_query_probes as probes
from docmancer.docs.application import _docs_context_projection_core as core
from docmancer.docs.application import need_context_projection as need_projection
from docmancer.docs.application import need_context_disposition as disposition
from docmancer.docs.application.docs_context_projection import project_docs_context
from docmancer.docs.application.evidence_requirements import build_requirements
from docmancer.docs.application.source_dependency_preparation import compact_dependency_record
from docmancer.docs.domain.documentation_query_plan import build_documentation_query_plan
from docmancer.docs.domain.need_contracts import compile_need_contracts
from tests.docs.test_docs_context_compound_projection import _host_lookup_context_retrieval
from tests.docs.test_evidence_set_disposition import context_case


ROOT = Path(__file__).resolve().parent
assert Path(probes.__file__).resolve().is_relative_to(ROOT)
native = probes.independent_query_probes
text = inspect.getsource(native)
old = "        text = str(query.get('text') or '')\n        probe = {"
assert text.count(old) == 1
changed = text.replace(old, "        text = str(query.get('text') or '')\n        roles = query_constraint_roles(text)\n        probe = {")
for field in ('hard_exact', 'bound_subjects', 'retrieval_anchors'):
    old = f'query_constraint_roles(text).{field}'
    assert changed.count(old) == 1
    changed = changed.replace(old, f'roles.{field}')
compiled = compile(changed, '<local-expression-prototype>', 'exec')
code = next(c for c in compiled.co_consts if isinstance(c, CodeType) and c.co_name == native.__name__)
prototype = FunctionType(code, native.__globals__, native.__name__)
assert prototype.__globals__ is native.__globals__


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, default=str)


def measure(fn, implementation):
    counts = Counter()
    roles = probes.query_constraint_roles

    def counted(name, func):
        def wrapped(*args, **kwargs):
            counts[name] += 1
            return func(*args, **kwargs)
        return wrapped

    with ExitStack() as stack:
        stack.enter_context(patch.object(probes, 'query_constraint_roles', counted('probe_roles_calls', roles)))
        stack.enter_context(patch.object(core, 'independent_query_probes', implementation))
        for module, name, label in (
            (need_projection, 'compile_need_contracts', 'iterator_compile'),
            (disposition, 'compile_need_contracts', 'classifier_compile'),
            (need_projection, 'classify_need_context', 'classify'),
            (need_projection, 'iter_need_context_variants', 'iterators'),
            (need_projection, 'project_need_context_fallback', 'late_fallback'),
        ):
            stack.enter_context(patch.object(module, name, counted(label, getattr(module, name))))
        value = fn(implementation)
    return value, dict(counts)


def compare(label, fn):
    baseline, bcount = measure(fn, native)
    candidate, ccount = measure(fn, prototype)
    assert baseline == candidate, label
    assert bcount.get('probe_roles_calls', 0) == 3 * ccount.get('probe_roles_calls', 0), (label, bcount, ccount)
    for key in bcount.keys() | ccount.keys():
        if key != 'probe_roles_calls':
            assert bcount.get(key, 0) == ccount.get(key, 0), (label, key)
    return {'case': label, 'equal': True, 'baseline': bcount, 'prototype': ccount,
            'output_sha256': sha256(canonical(baseline).encode()).hexdigest()}, baseline


def source(body):
    return {'snippet': body, 'path_or_url': 'Guide.md', 'section': 'Guide',
            'source_class': 'project_doc', 'project_identity': 'repo',
            '_expected_project_identity': 'repo', 'retrieval_query_matches': {}}


def query_plan(q, origin):
    return {'queries': [{'query_id': 'query-original' if origin == 'original' else 'query-test',
                         'text': q, 'origin': origin}]}


pairs = [
    ('storage persists records', 'Storage persists records on disk.'),
    ('How does `EXACT_KEY` select storage?', 'EXACT_KEY selects local storage.'),
    ('How does `EXACT_KEY` select storage?', 'OTHER_KEY selects local storage.'),
    ('Explain class RelayClient retry scheduling.', 'RelayClient retry scheduling uses a bounded queue.'),
    ('What is RelayClient default timeout?', 'RelayClient default timeout is 7 seconds.'),
    ('What is RelayClient default timeout when preview is disabled?',
     'When preview is enabled, RelayClient default timeout is 7 seconds.'),
    ('Как устроено хранение записей?', 'Хранение записей использует локальную базу.'),
    ('Read docs/Guide.md about ALPHA_KEY.', 'ALPHA_KEY enables durable storage.'),
    ('contributor overview', 'Contributor configuration is stored locally.'),
    ('', 'Unrelated text.'),
]
inputs = [(f'{i}-{origin}', source(body), query_plan(q, origin))
          for i, (q, body) in enumerate(pairs)
          for origin in ('original', 'host_lookup', 'retrieval_need')]
for name, changes in (
    ('foreign', {'project_identity': 'foreign'}),
    ('stale', {'freshness': 'stale'}),
    ('unsafe', {'risk_flags': ['unsafe']}),
    ('already_traced', {'retrieval_query_matches': {'query-original': {'query_text': 'storage persists records', 'qualified': True}}}),
):
    src = source(pairs[0][1]); src.update(changes)
    inputs.append((name, src, query_plan(pairs[0][0], 'original')))
for name, changes in (
    ('derived', {'public_parent_query_id': 'query-parent'}),
    ('alias', {'origin': 'canonical_intent'}),
    ('no_id', {'query_id': ''}),
):
    plan = query_plan(pairs[0][0], 'original'); plan['queries'][0].update(changes)
    inputs.append((name, source(pairs[0][1]), plan))
inputs.append(('distinctive-hosts', source('Project architecture documentation describes the layers.'),
               {'queries': [{'query_id': f'host-{i}', 'origin': 'host_lookup', 'text': q}
                            for i, q in enumerate(('project architecture documentation', 'project testing documentation'))]}))

results = []
for label, src, plan in inputs:
    def direct(impl, src=src, plan=plan):
        s, p = deepcopy(src), deepcopy(plan)
        value = impl(s, p)
        assert s == src and p == plan
        return value
    row, _ = compare('direct:' + label, direct); results.append(row)

    def requalify(impl, src=src, plan=plan):
        s = {**deepcopy(src), '_independent_query_plan': deepcopy(plan)}
        return core._requalify_visible_source(s, query_text={q['query_id']: q['text'] for q in plan['queries']})
    row, _ = compare('visible:' + label, requalify); results.append(row)

for case in ('existing-traces', 'absent-traces', 'foreign'):
    retrieval = _host_lookup_context_retrieval()
    if case == 'absent-traces':
        for item in retrieval['context_pack']:
            item['retrieval_query_matches'] = {}
    if case == 'foreign':
        retrieval['project_identity'] = 'foreign'
    def project(impl, retrieval=retrieval):
        copied = deepcopy(retrieval)
        packet, snapshot = project_docs_context(retrieval=copied)
        return {'packet': packet, 'snapshot': snapshot, 'retrieval': copied}
    row, _ = compare('facade:' + case, project); results.append(row)

numeric = []
question = 'How many retry attempts does ProjectRetryPolicy allow?'
for label, body in (
    ('literal', '# ProjectRetryPolicy\n\nProjectRetryPolicy allows at most two retry attempts.\n'),
    ('heading-prose', '# ProjectRetryPolicy\n\nThe retry policy allows at most two attempts.\n'),
    ('delegation', '# ProjectRetryPolicy\n\nProjectRetryPolicy delegates retry scheduling decisions to OtherWorker.\n'),
):
    contract, args = context_case(question, body)
    reqs = build_requirements(question, profile='project_docs_answer')
    plan = build_documentation_query_plan(question, requirements=reqs).as_payload()
    original = args['candidate']
    original.update(path='Guide.md', content=body, line_start=1,
        _evidence_sets=[compact_dependency_record(b) for b in args['bundles']],
        retrieval_query_matches={'query-original': {'query_text': question, 'query_origin': 'original'}})
    retrieval = {'context_pack': [original], 'documentation_query_plan': plan, 'project_identity': 'project'}

    def project_numeric(impl, retrieval=retrieval):
        copied = deepcopy(retrieval)
        packet, snapshot = core.project_docs_context(retrieval=copied)
        return {'packet': packet, 'snapshot': snapshot, 'retrieval': copied}
    row, value = compare('core-numeric:' + label, project_numeric); results.append(row)
    packet = value['packet']
    numeric.append({'case': label, 'component_scope_complete': plan['component_scope_complete'],
        'component_contract': plan['_component_contract'],
        'need_contracts': [asdict(c) for c in compile_need_contracts(question, args['reference_plan'])],
        'counts': row['baseline'], 'status': packet.get('status'),
        'snippets': [s['snippet'] for s in packet.get('sources', ())],
        'answer_supported': packet.get('answer_supported'), 'edit_ready': packet.get('edit_ready'),
        'diagnostics': value['retrieval']['retrieval_diagnostics']['docs_context_projection']})

totals = {side: dict(sum((Counter(r[side]) for r in results), Counter())) for side in ('baseline', 'prototype')}
report = {'python': sys.executable, 'source': str(Path(probes.__file__).resolve()),
          'source_sha256': sha256(Path(probes.__file__).read_bytes()).hexdigest(),
          'comparison_count': len(results), 'totals': totals,
          'comparisons': results, 'numeric_route_observations': numeric}
path = ROOT / 'routes_evidence.json'
path.write_text(json.dumps(report, ensure_ascii=False, separators=(',', ':')) + '\n')
print(json.dumps({'comparisons': len(results), 'all_equal': True, 'totals': totals,
                 'numeric': [{k: row[k] for k in ('case', 'status', 'counts', 'snippets')} for row in numeric]}, ensure_ascii=False, indent=2))
