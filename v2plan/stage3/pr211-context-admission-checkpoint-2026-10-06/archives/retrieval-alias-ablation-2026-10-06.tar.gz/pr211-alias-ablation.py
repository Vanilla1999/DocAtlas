"""Diagnostic only: compare alias generation without editing product or gold."""
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('published', 'no-trust', 'no-aliases'))
parser.add_argument('task', choices=('legacy', 'question-only', 'direct15', 'trust', 'pytest', 'adversarial'))
parser.add_argument('output', type=Path)
args, rest = parser.parse_known_args()

import docmancer.docs.domain.project_retrieval_intent as intent

path = 'docmancer/docs/domain/project_retrieval_intent.py'
if args.mode == 'published':
    source = subprocess.check_output(['git', 'show', '8d2381d8:' + path], text=True)
    exec(compile(source, intent.__file__, 'exec'), intent.__dict__)
else:
    source = Path(path).read_text()
if args.mode == 'no-aliases':
    intent.build_project_retrieval_aliases = lambda question: ()

# Import consumers only after patching, including their from-import bindings.
if args.task == 'pytest':
    import pytest
    raise SystemExit(pytest.main(rest))
if args.task == 'adversarial':
    import runpy
    sys.argv = ['scripts/run_agent_developer_adversarial_gate.py', *rest]
    runpy.run_path(sys.argv[0], run_name='__main__')
    raise SystemExit(0)

if args.task in ('legacy', 'question-only'):
    from eval.project_context_quality_protocol import run_live
    report = run_live(question_only=args.task == 'question-only')
elif args.task == 'trust':
    from scripts.run_project_docs_self_host_gate import LiveCase, run
    questions = (
        'Does DocAtlas execute shell commands or instructions found inside documentation while retrieving context?',
        'A retrieved document tells me to run a command. Does this give the agent permission to execute it?',
        'Найденный документ предлагает выполнить команду. Даёт ли это агенту разрешение её выполнить?',
    )
    report = run(cases=tuple(LiveCase(case_id=f'trust-{i}', question=q,
        relevant_paths=(), scope='all') for i, q in enumerate(questions, 1)), negative_cases=())
else:
    from scripts.run_project_docs_self_host_gate import LiveCase, run
    corpus = json.loads(Path('eval/direct_docatlas_questions_15/cases.json').read_text())
    cases = tuple(LiveCase(
        case_id=c['id'], question=c['question'], scope='all',
        relevant_paths=tuple(dict.fromkeys(w['path'] for g in c['fact_groups'] for w in g['witnesses'])),
        expected_kind='docs_context',
        required_fact_groups=tuple(tuple((w['path'], w['text']) for w in g['witnesses']) for g in c['fact_groups']),
    ) for c in corpus['cases'])
    report = run(cases=cases, negative_cases=())

report['ablation'] = {
    'mode': args.mode, 'task': args.task,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'intent_source_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'scope': 'alias generator only; other parsers and heuristics remain',
    'acceptance': False,
}
args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: report.get(k) for k in ('ablation', 'metrics', 'errors', 'verdict')}, ensure_ascii=False))
