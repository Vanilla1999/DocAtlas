"""Supplemental public-boundary audit; existing hint expectations are untouched."""
import json
from dataclasses import replace
from copy import deepcopy

import pytest

from tests._shared_test_docs_service import _service_with_real_agent
from eval.project_context_quality.capture_public_context import capture_public_call


QUESTION = "How are NebulaLedger orbital telemetry snapshots persisted?"
BODY = "NebulaLedger persists orbital telemetry snapshots in SQLite."


@pytest.mark.parametrize("variant", ["normal", "crop", "merge", "foreign", "unrelated", "forged"])
def test_anchor_only_discovery_final_public_boundary(tmp_path, monkeypatch, variant):
    project = tmp_path / "project"
    project.mkdir()
    text = "# Storage\n\n" + BODY + "\n"
    if variant == "crop":
        text += "\n" + ("Background prose about routine housekeeping. " * 200)
    (project / "README.md").write_text(text)
    service = _service_with_real_agent(tmp_path, monkeypatch)
    result = service.ingest_project_docs(str(project), with_vectors=False)
    assert result.status == "success", result.message
    agent = service._agent_instance()
    dispatcher = service.agent_gateway.dispatcher_for(agent, mode="lexical")
    native = type(dispatcher).run

    def anchor_only(self, query, **kwargs):
        if query != "NebulaLedger":
            return replace(native(self, query, **kwargs), chunks=[])
        result = native(self, query, **kwargs)
        chunks = result.chunks
        if variant == "merge":
            result = replace(result, chunks=[*chunks, *deepcopy(chunks)])
        for chunk in chunks:
            if variant == "foreign":
                chunk.metadata["project_identity"] = "foreign-project"
            if variant in {"unrelated", "forged"}:
                chunk.text = "AnotherWorker exports weather reports to a remote dashboard."
            if variant == "forged":
                chunk.metadata["retrieval_query_matches"] = {
                    "query-original": {"qualified": True, "query_text": QUESTION,
                                       "match_ratio": 1.0, "lexical_score": 99},
                }
                chunk.metadata["retrieval_query_ids"] = ("query-original",)
        return result

    monkeypatch.setattr(type(dispatcher), "run", anchor_only)
    capture = capture_public_call(service, {
        "question": QUESTION, "project_path": str(project), "scope": "project",
    })
    payload = capture["public_payload"]
    assert payload is not None
    print("FINAL_PACKET", variant, json.dumps(payload, ensure_ascii=False, default=str))
    assert payload["answer_supported"] is False
    assert payload.get("edit_ready", False) is False
    assert "query-original" not in payload.get("covered_query_ids", [])
    if variant in {"normal", "crop", "merge"}:
        assert payload["status"] == "ok"
        assert any("SQLite" in source["snippet"] for source in payload["sources"])
        if variant == "crop":
            assert len(payload["sources"][0]["snippet"]) < len(text)
        if variant == "merge":
            assert len(payload["sources"]) == 1
        from docmancer.docs.application._docs_context_projection_core import _requalify_visible_source
        from docmancer.docs.application.context_selection import attributable_query_ids, merge_query_matches
        source = deepcopy(capture["projection_attempts"][0]["before_projection"]["context_pack"][0])
        source["snippet"] = BODY
        qualified = _requalify_visible_source(source, query_text={"query-original": QUESTION, "query-anchor-1": "NebulaLedger"})
        assert qualified["retrieval_query_matches"]["query-original"]["admission_only"] is True
        # Same-window merge must not promote independently checked root admission.
        qualified["retrieval_query_matches"] = merge_query_matches(
            qualified["retrieval_query_matches"], qualified["retrieval_query_matches"])
        assert "query-original" not in attributable_query_ids([qualified])
        qualified["snippet"] = "AnotherWorker exports weather reports."
        cropped = _requalify_visible_source(qualified, query_text={"query-original": QUESTION, "query-anchor-1": "NebulaLedger"})
        assert not attributable_query_ids([cropped])
    else:
        assert payload["status"] == "insufficient_evidence"
        assert not payload.get("sources")
