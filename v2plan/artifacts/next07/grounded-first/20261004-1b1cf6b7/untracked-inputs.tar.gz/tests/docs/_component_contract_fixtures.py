"""Explicit proof-owner input for component unit tests, not native retrieval."""
from dataclasses import asdict

from docmancer.docs.domain.documentation_query_plan import build_documentation_query_plan
from docmancer.docs.domain.project_answer_contract import build_project_answer_contract


def component_plan(question):
    contract = build_project_answer_contract(question)
    plan = build_documentation_query_plan(question).as_payload()
    plan["_component_contract"] = [
        {**asdict(obligation), "component_id": obligation.obligation_id,
         "obligation_kind": obligation.kind}
        for obligation in contract.proof_obligations if obligation.mandatory
    ]
    plan["unresolved_parts"] = list(contract.unresolved_parts)
    plan["component_scope_complete"] = contract.component_scope_complete
    return plan
