import json
import subprocess
from unittest.mock import patch

import pytest

from eval.task_level.runners.base import AgentRunRequest
from eval.task_level.runners.opencode import OpenCodeRunner, _normalize_events


def request(tmp_path):
    return AgentRunRequest(
        task_id="canary", condition_id="candidate", workspace=tmp_path,
        prompt="Test prompt", model="provider/model", timeout_seconds=10,
        max_turns=2, environment={}, mcp_config_path=None,
        tool_policy_path=tmp_path / "policy.json", output_dir=tmp_path / "output",
    )


def test_complete_text_and_tool_output_survive_normalization():
    text = "evidence " * 200
    events = _normalize_events("\n".join([
        json.dumps({"type": "text", "part": {"text": text}}),
        json.dumps({"type": "tool_use", "part": {"tool": "mcp", "state": {"output": text}}}),
    ]))
    assert [event["result_summary"] for event in events] == [text, text]


@pytest.mark.parametrize("stdout,expected", [
    (json.dumps({"type": "error", "error": "denied"}), "runner_failed"),
    (json.dumps({"type": "text", "part": {"text": "OK"}}), "completed"),
], ids=["error", "text"])
def test_private_server_cwd_and_structured_error_detection(tmp_path, stdout, expected):
    runner = OpenCodeRunner()
    with patch.object(runner, "_version", return_value="test"), patch(
        "eval.task_level.runners.opencode.subprocess.run",
        return_value=subprocess.CompletedProcess([], 0, stdout, ""),
    ) as run:
        result = runner.run(request(tmp_path))
    command = run.call_args.args[0]
    assert "--standalone" in command
    assert "--pure" not in command and "--dir" not in command
    assert run.call_args.kwargs["cwd"] == tmp_path
    assert result.status == expected


def test_timeout_preserves_partial_byte_events(tmp_path):
    runner = OpenCodeRunner()
    stdout = json.dumps({"type": "text", "part": {"text": "partial"}}).encode()
    with patch.object(runner, "_version", return_value="test"), patch(
        "eval.task_level.runners.opencode.subprocess.run",
        side_effect=subprocess.TimeoutExpired([], 10, output=stdout, stderr=b"timeout"),
    ):
        result = runner.run(request(tmp_path))
    assert result.status == "timeout"
    assert (tmp_path / "output" / "stdout.log").read_text() == stdout.decode()
    assert (tmp_path / "output" / "stderr.log").read_text() == "timeout"


def test_cli_and_auth_do_not_certify_isolation():
    runner = OpenCodeRunner()
    with patch.object(runner, "_version", return_value="test"), patch(
        "eval.task_level.runners.opencode._auth_available", return_value=True,
    ):
        capabilities = runner.verify()
    assert not capabilities.verified
    assert not capabilities.tool_isolation and not capabilities.mcp_isolation
    assert not capabilities.patch_capture
