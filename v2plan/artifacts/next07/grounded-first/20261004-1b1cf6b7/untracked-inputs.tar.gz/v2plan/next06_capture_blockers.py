"""Observe existing native handlers without changing their decisions."""
import argparse
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.docs._global_evidence_fixtures import capture_fixture
import docmancer.docs.application.project_context_service as context
import scripts.run_agent_developer_adversarial_gate as adversarial


def capture(output):
    output.mkdir(parents=True, exist_ok=True)
    stages = []
    admission = []
    rerank = context.rerank_project_doc_chunks
    from docmancer.docs.application import read_context_admission as read_admission
    decide = read_admission.read_context_admission

    def observed_admission(candidate, **kwargs):
        result = decide(candidate, **kwargs)
        admission.append({
            "path": candidate.get("path"),
            "snippet": candidate.get("snippet"),
            "char_span": candidate.get("char_span"),
            "allowed": result.allowed, "reason": result.reason,
        })
        return result

    def observed_rerank(chunks, **kwargs):
        result = rerank(chunks, **kwargs)
        stages.append({
            "before": [{"path": c.path, "prefit_eligible": id(c) in kwargs["context_candidate_ids"],
                        "matches": c.metadata.get("retrieval_query_matches")} for c in chunks],
            "after": [c.path for c in result],
        })
        return result

    with TemporaryDirectory(dir="/tmp/opencode", prefix="next06-native-") as directory:
        with patch.object(context, "rerank_project_doc_chunks", observed_rerank), patch.object(
            read_admission, "read_context_admission", observed_admission,
        ):
            native = capture_fixture(Path(directory), {
                "default.md": "# LeaseClient\n\nThe default timeout is 17 seconds.\n",
                "error.md": "# LeaseClient\n\nAn expired operation raises `LeaseExpired`.\n",
                "overview.md": "# Overview\n\nLeaseClient default timeout duration requests exception operation behavior documentation.\n",
            }, "What is LeaseClient default timeout duration for requests and which exception is raised when an operation expires?")
    (output / "lease-prefit-trace.json").write_text(json.dumps({
        "stages": stages, "read_admission": admission,
        "public_payload": native["public_payload"],
    }, indent=2) + "\n")
    assert stages, "rerank observer was not reached"

    calls = []
    handler = adversarial.base.handle_context_tool

    def observed_handler(tool, arguments, service):
        payload = handler(tool, arguments, service)
        calls.append({"tool": tool, "arguments": arguments, "payload": payload})
        return payload

    case = next(c for c in adversarial._load_cases()["cases"]
                if c["id"] == "module_scope_rejects_project_policy_detail")
    with patch.object(adversarial.base, "handle_context_tool", observed_handler):
        result = adversarial._run_adversarial_case(case)
    (output / "adversarial-full-packet.json").write_text(json.dumps({
        "case": case, "result": result, "calls": calls,
    }, indent=2, default=str) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    capture(parser.parse_args().output)
