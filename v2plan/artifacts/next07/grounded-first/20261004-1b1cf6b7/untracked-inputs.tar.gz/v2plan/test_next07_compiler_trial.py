"""Compiler acceptance only; a rejected candidate must remain visibly red."""
import pytest

from docmancer.docs.domain.need_contracts import compile_need_contracts
from docmancer.docs.domain.query_reference_binding import ScopeKey, resolve_references
from v2plan.next07_compiler_trial import compile_preserved_needs


LEASE = ('What is LeaseClient default timeout duration for requests and '
         'which exception is raised when an operation expires?')


def compile_question(question, compiler):
    plan = resolve_references(question, catalog=(), scope=ScopeKey('syntax', '', 'g1'))
    return compiler(question, plan)


@pytest.fixture(params=[compile_need_contracts, compile_preserved_needs],
                ids=['native', 'preserved-candidate'])
def compiler(request):
    return request.param


def test_local_condition_does_not_attach_to_default(compiler):
    rows = compile_question(LEASE, compiler)
    assert len(rows) == 2
    default, exception = rows
    assert default.need.subject == exception.need.subject == 'LeaseClient'
    assert not default.constraint_spans
    assert [LEASE[s.start:s.end] for s in exception.constraint_spans] == [
        'when an operation expires?']
    assert all(r.interpretation == 'unresolved' and r.requirement == 'unknown' for r in rows)


@pytest.mark.parametrize('question', [
    'When preview is disabled, what is RelayClient default timeout and which exception is raised?',
    'What is RelayClient default timeout and which exception is raised, only for administrators?',
])
def test_global_or_ambiguous_constraints_are_not_discarded(question, compiler):
    rows = compile_question(question, compiler)
    assert rows
    assert all(r.constraint_spans for r in rows)
    assert all(r.interpretation == 'unresolved' for r in rows)
    assert all(question[r.need.query_span_start:r.need.query_span_end] == r.need.query_span_text
               for r in rows)


def test_existing_parts_are_preserved_without_proof(compiler):
    question = 'What is RelayClient default timeout and which exception is raised?'
    rows = compile_question(question, compiler)
    assert len(rows) == 2
    assert [r.need.relation for r in rows] == ['default', 'exception']
    assert all(r.interpretation == 'unresolved' and not r.constraint_spans for r in rows)


def test_root_exact_obligations_are_not_weakened(compiler):
    question = 'What is `RelayClient` default timeout and which exception is raised?'
    roots = compile_question(question, compile_need_contracts)
    rows = compile_question(question, compiler)
    assert roots[0].need.hard_exact
    assert all(set(roots[0].need.hard_exact) <= set(r.need.hard_exact) for r in rows)


def test_quoted_separator_does_not_create_parts(compiler):
    question = 'What is `RelayClient and which exception` default timeout?'
    assert compile_question(question, compiler) == compile_question(question, compile_need_contracts)


def test_changed_reference_question_cannot_enable_preservation(compiler):
    plan = resolve_references('Other request', catalog=(), scope=ScopeKey('syntax', '', 'g1'))
    assert compiler(LEASE, plan) == compile_need_contracts(LEASE, plan)
