"""Research observer and unsafe diagnostic arms; never a runtime candidate."""
import argparse
from contextlib import ExitStack
from dataclasses import asdict
import hashlib
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from eval.evidence_quality_v2.runtime import index_project, isolated_service, save_json, write_project
from eval.project_context_quality.capture_public_context import capture_public_call
from docmancer.docs.application import read_context_admission as admission
from docmancer.docs.application import project_context_service as context
from docmancer.docs.application.model_visible_projection import validate_model_visible_projection
from docmancer.docs.application.model_visible_projection_helpers import docs_context_budget_tokens
from docmancer.docs.application.projection_decision_trace import ProjectionDecisionTrace
from docmancer.docs.domain.need_contracts import compile_need_contracts
from docmancer.docs.domain.question_retrieval_needs import retrieval_needs


QUESTION = ('What is LeaseClient default timeout duration for requests and '
            'which exception is raised when an operation expires?')


def cases():
    rows = []
    for value, error in ((17, 'LeaseExpired'), (29, 'WaitExpired')):
        documents = {
            'default.md': f'# LeaseClient\n\nThe default timeout is {value} seconds.\n',
            'error.md': f'# LeaseClient\n\nAn expired operation raises `{error}`.\n',
            'overview.md': '# Overview\n\nLeaseClient default timeout duration requests '
                           'exception operation behavior documentation.\n',
        }
        rows.append((f'lease-{value}', QUESTION, documents))
    global_question = ('When preview is disabled, what is RelayClient default timeout '
                       'and which exception is raised?')
    documents = {
        'disabled.md': '# RelayClient\n\nWhen preview is disabled, RelayClient default '
                       'timeout is 17 seconds and RelayClient raises `DisabledExpired`.\n',
        'enabled.md': '# RelayClient\n\nWhen preview is enabled, RelayClient default '
                      'timeout is 29 seconds and RelayClient raises `EnabledExpired`.\n',
    }
    rows.append(('global-condition', global_question, documents))
    rows.append(('global-wrong-state', global_question, {'enabled.md': documents['enabled.md']}))
    rows.append(('global-missing-state', global_question, {
        'default.md': '# RelayClient\n\nRelayClient default timeout is 17 seconds.\n'}))
    unknown_question = ('What is RelayClient default timeout and which exception is '
                        'raised, only for administrators?')
    rows.append(('unknown-scope', unknown_question, {
        'default.md': '# RelayClient\n\nRelayClient default timeout is 17 seconds.\n'}))
    rows.append(('restriction-tail', unknown_question, {
        'default.md': '# RelayClient\n\nRelayClient default timeout is 17 seconds. '
                      'Only when preview is disabled.\n'}))
    rows.append(('lease-missing-error', QUESTION, {
        'default.md': rows[0][2]['default.md']}))
    rows.append(('lease-wrong-subject', QUESTION, {
        'default.md': '# NovaClient\n\nThe default timeout is 17 seconds.\n',
        'error.md': '# NovaClient\n\nAn expired operation raises `LeaseExpired`.\n'}))
    return rows


def run(output):
    output.mkdir(parents=True, exist_ok=False)
    summary = []
    for name, question, documents in cases():
        arms = ('native', 'bypass-condition', 'bypass-condition-locality', 'keep-rerank') \
            if name.startswith('lease-') and name in {'lease-17', 'lease-29'} else ('native',)
        with TemporaryDirectory(dir='/tmp/opencode', prefix='next07-') as directory:
            root = Path(directory) / 'corpus'
            write_project(root, documents)
            with isolated_service(Path(directory) / 'state') as (service, config):
                ingest = index_project(service, config, root)
                save_json(output / name / 'ingest.json', ingest)
                for arm in arms:
                    events = []
                    plans = []
                    request = {'project_path': str(root), 'scope': 'project', 'question': question}
                    request_hash = hashlib.sha256(question.encode()).hexdigest()

                    def identity(candidate):
                        evidence = candidate.get('_reference_evidence') or {}
                        return {'question_sha256': request_hash,
                                'path': candidate.get('path_or_url', candidate.get('path')),
                                'span': candidate.get('char_span', 'unknown'),
                                'source': evidence.get('source', 'unknown'),
                                'root_scope': (candidate.get('_reference_root_plan') or {}).get('scope'),
                                'snippet': candidate.get('snippet')}

                    real_read = admission.read_context_admission
                    real_applicable = admission._applicable_context
                    real_locality = admission.local_topic_witness
                    real_rank = context.rerank_project_doc_chunks
                    real_record = ProjectionDecisionTrace.record

                    def read(candidate, **kwargs):
                        root_plan = candidate.get('_reference_root_plan')
                        if root_plan:
                            plan = admission._current_plan(root_plan, question)
                            assert plan is not None
                            plans.append({'path': candidate.get('path'),
                                          'reference_plan': root_plan,
                                          'contracts': [asdict(c) for c in compile_need_contracts(question, plan)]})
                        result = real_read(candidate, **kwargs)
                        events.append({'stage': 'read', **identity(candidate), **asdict(result)})
                        return result

                    def applicable(contract, original_question, body):
                        native_result = real_applicable(contract, original_question, body)
                        result = True if arm.startswith('bypass-condition') else native_result
                        events.append({'stage': 'condition', 'contract': asdict(contract),
                                       'body': body, 'native_allowed': native_result, 'allowed': result})
                        return result

                    def locality(body, **kwargs):
                        native_result = real_locality(body, **kwargs)
                        result = True if arm == 'bypass-condition-locality' else native_result
                        events.append({'stage': 'locality', 'body': body,
                                       'terms': sorted(kwargs['terms']),
                                       'native_allowed': native_result, 'allowed': result})
                        return result

                    def rank(chunks, **kwargs):
                        if arm == 'keep-rerank':
                            kwargs['context_candidate_ids'] = frozenset(id(c) for c in chunks)
                        before = [asdict(c) for c in chunks]
                        after = real_rank(chunks, **kwargs)
                        events.append({'stage': 'rerank', 'before': before,
                                       'after': [asdict(c) for c in after]})
                        return after

                    def record(instance, stage, decision, reason, candidate, variant=None, **kwargs):
                        events.append({'stage': stage, 'decision': decision, 'reason': reason,
                                       **identity(candidate if isinstance(candidate, dict) else {}),
                                       'variant': variant})
                        return real_record(instance, stage, decision, reason, candidate, variant, **kwargs)

                    with ExitStack() as stack:
                        stack.enter_context(patch.object(admission, 'read_context_admission', read))
                        stack.enter_context(patch.object(admission, '_applicable_context', applicable))
                        stack.enter_context(patch.object(admission, 'local_topic_witness', locality))
                        stack.enter_context(patch.object(context, 'rerank_project_doc_chunks', rank))
                        stack.enter_context(patch.object(ProjectionDecisionTrace, 'record', record))
                        capture = capture_public_call(service, request)
                    assert any(e['stage'] == 'rerank' for e in events), 'observer not reached'
                    errors = [validate_model_visible_projection(
                        a['projected_payload'], snapshot=a['snapshot'], max_tokens=800)
                        for a in capture['projection_attempts']]
                    assert plans, 'prepared source observer not reached'
                    payload = capture['public_payload']
                    save_json(output / name / f'{arm}.json', {
                        'diagnostic_only': arm != 'native', 'documents': documents,
                        'capture': capture, 'events': events, 'actual_plans': plans,
                        'retrieval_needs': [asdict(n) for n in retrieval_needs(question)],
                        'validation_errors': errors})
                    summary.append({'case': name, 'arm': arm,
                                    'sources': payload.get('sources', []),
                                    'flags': {k: payload.get(k) for k in (
                                        'answer_supported', 'answer_available', 'edit_ready')},
                                    'tokens': docs_context_budget_tokens(payload),
                                    'validation_errors': errors,
                                    'selection_reasons': sorted({e['reason'] for e in events
                                                                if e['stage'] == 'selection'})})
    save_json(output / 'summary.json', summary)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    run(parser.parse_args().output)
