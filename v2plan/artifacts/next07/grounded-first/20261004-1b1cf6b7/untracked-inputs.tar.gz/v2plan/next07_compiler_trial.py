"""Isolated enrichment replacement; no runtime/default wiring or new grammar."""
from dataclasses import replace

from docmancer.docs.domain.need_contracts import compile_need_contracts
from docmancer.docs.domain.question_retrieval_needs import retrieval_needs


def compile_preserved_needs(question, references):
    """Preserve syntax proposals without narrowing unverified constraints."""
    roots = compile_need_contracts(question, references)
    if references.question != question:
        return roots
    rows = []
    for root in roots:
        needs = retrieval_needs(root.need.query_span_text)
        if root.interpretation != 'unresolved' or len(needs) < 2:
            rows.append(root)
            continue
        offset = root.need.query_span_start
        for number, need in enumerate(needs, 1):
            enriched = replace(
                need, need_id=f'{root.need.need_id}:part-{number}',
                query_span_start=offset + need.query_span_start,
                query_span_end=offset + need.query_span_end,
                hard_exact=tuple(dict.fromkeys((*root.need.hard_exact, *need.hard_exact))),
            )
            # The existing parser supplies no certified per-child scope here.
            # Retain constraints rather than treating unknown as permission.
            rows.append(replace(root, need=enriched, focus_spans=tuple(
                span for span in root.focus_spans
                if enriched.query_span_start <= span.start < span.end <= enriched.query_span_end)))
    return tuple(rows)
