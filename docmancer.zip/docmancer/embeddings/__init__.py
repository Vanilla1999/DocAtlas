"""Embeddings providers (dense + sparse).

Default provider is :mod:`docmancer.embeddings.fastembed_provider` (local,
no API key). Cloud provider stubs live alongside for future wiring.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from .base import EmbeddingsProvider, SparseEmbeddings

if TYPE_CHECKING:
    from docmancer.core.config import EmbeddingsConfig


def get_embeddings_provider(config: "EmbeddingsConfig") -> EmbeddingsProvider:
    """Factory for the configured embeddings provider."""
    name = (config.provider or "fastembed").lower()
    if name == "fastembed":
        from .fastembed_provider import FastEmbedProvider

        return FastEmbedProvider(config)
    if name == "voyage":
        from .voyage_provider import VoyageProvider

        return VoyageProvider(config)
    if name == "openai":
        from .openai_provider import OpenAIProvider

        return OpenAIProvider(config)
    if name == "cohere":
        from .cohere_provider import CohereProvider

        return CohereProvider(config)
    raise ValueError(f"Unknown embeddings provider: {config.provider!r}")


__all__ = ["EmbeddingsProvider", "SparseEmbeddings", "get_embeddings_provider"]
