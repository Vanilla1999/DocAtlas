"""CLI surface for `docmancer mcp ...` and `docmancer install-pack <pkg>@<ver>`."""
from __future__ import annotations

import json
import sys
from typing import Any

import click
import httpx

from docmancer.mcp import agent_config, doctor, installer, paths
from docmancer.mcp.installer import install_package, set_enabled, uninstall_package
from docmancer.mcp.manifest import Manifest
from docmancer.mcp.registry import UnsupportedSpecError, compile_pack_from_url


@click.group(name="mcp", hidden=True, help="Manage the local Docmancer MCP server and installed packs.")
def mcp_group() -> None:
    pass


@mcp_group.command("serve")
def mcp_serve_cmd() -> None:
    """Run the stdio MCP server. Agents launch this; humans usually do not."""
    from docmancer.mcp.serve import serve
    serve()


@mcp_group.command("docs-serve")
def mcp_docs_serve_cmd() -> None:
    """Run the stdio MCP documentation server."""
    from docmancer.mcp.docs_server import serve
    serve()


@mcp_group.command("doctor")
def mcp_doctor_cmd() -> None:
    """Health-check the local MCP setup."""
    results = doctor.run()
    failed = 0
    for r in results:
        mark = click.style("ok", fg="green") if r.ok else click.style("FAIL", fg="red")
        click.echo(f"[{mark}] {r.name}: {r.detail}")
        if not r.ok:
            failed += 1
    click.echo()
    if failed:
        click.echo(click.style(f"{failed} check(s) failed", fg="red"))
        raise SystemExit(1)
    click.echo(click.style("All checks passed", fg="green"))


@mcp_group.command("list")
def mcp_list_cmd() -> None:
    """List installed packs and their per-package state."""
    manifest = Manifest.load()
    if not manifest.packages:
        click.echo("No packs installed. Try `docmancer install-pack <pkg>@<version>`.")
        return
    for p in manifest.packages:
        try:
            curated = len(p.tools()) if not p.expanded else "n/a"
            full_count = "?"
            full_path = p.directory / "tools.full.json"
            if full_path.exists():
                full_data = json.loads(full_path.read_text())
                full_count = len(full_data.get("tools", [])) if isinstance(full_data, dict) else len(full_data)
        except FileNotFoundError:
            curated, full_count = "missing", "missing"
        state = "enabled" if p.enabled else "disabled"
        mode = "expanded" if p.expanded else "curated"
        destructive = "ALLOW" if p.allow_destructive else "block"
        click.echo(
            f"{p.package}@{p.version}  [{state}] mode={mode} curated={curated} full={full_count} destructive={destructive}"
        )


@mcp_group.command("enable")
@click.argument("package")
@click.option("--version", default=None, help="Specific version; default is all installed versions.")
def mcp_enable_cmd(package: str, version: str | None) -> None:
    n = set_enabled(package, version, True)
    click.echo(f"Enabled {n} package(s).")


@mcp_group.command("disable")
@click.argument("package")
@click.option("--version", default=None, help="Specific version; default is all installed versions.")
def mcp_disable_cmd(package: str, version: str | None) -> None:
    n = set_enabled(package, version, False)
    click.echo(f"Disabled {n} package(s).")


@mcp_group.command("remove", help="Remove an installed pack: `docmancer mcp remove <package>[@<version>]`.")
@click.argument("spec")
def mcp_remove_cmd(spec: str) -> None:
    package, version = _parse_pack_spec(spec, require_version=False)
    n = uninstall_package(package, version)
    target = f"{package}@{version}" if version else package
    click.echo(f"Removed {n} package entry/entries for {target}.")


@click.command("install-pack", help="Install an API pack: `docmancer install-pack <package>@<version>`.")
@click.argument("spec")
@click.option("--expanded", is_flag=True, default=False, help="Activate the full tool surface (not the curated subset).")
@click.option("--allow-destructive", is_flag=True, default=False, help="Permit destructive calls for this pack.")
@click.option("--allow-execute", is_flag=True, default=False, help="Permit executor types like python_import (subprocess execution).")
@click.option("--from-url", "from_url", default=None, help="OpenAPI 3.x / Swagger 2.0 spec URL. Compiles the pack locally and skips the prompt on miss.")
def install_pack_cmd(spec: str, expanded: bool, allow_destructive: bool, allow_execute: bool, from_url: str | None) -> None:
    package, version = _parse_pack_spec(spec, require_version=True)
    if from_url:
        _compile_from_url_or_die(package, version, from_url)
    try:
        result = install_package(
            package, version,
            expanded=expanded, allow_destructive=allow_destructive,
            allow_execute=allow_execute,
        )
    except RuntimeError as exc:
        raise click.ClickException(str(exc)) from exc
    except FileNotFoundError as exc:
        url = _prompt_for_spec_url(package, version, str(exc))
        if url is None:
            raise click.ClickException(str(exc)) from exc
        _compile_from_url_or_die(package, version, url)
        try:
            result = install_package(
                package, version,
                expanded=expanded, allow_destructive=allow_destructive,
                allow_execute=allow_execute,
            )
        except (RuntimeError, FileNotFoundError) as inner:
            raise click.ClickException(str(inner)) from inner

    click.echo(f"Installed {package}@{version} to {result.package.directory}")
    mode = "expanded" if expanded else "curated"
    click.echo(f"Active tool surface: {result.curated_count} (mode={mode}; full={result.full_count})")
    if result.auth_envs:
        click.echo(f"Required credentials: {', '.join(result.auth_envs)}")
    if result.required_headers:
        for k, v in result.required_headers.items():
            click.echo(f"Wire-pinned header: {k}: {v}")
    click.echo(f"Destructive endpoints: {result.destructive_count} ({'allowed' if allow_destructive else 'gated'})")
    if not allow_destructive and result.destructive_count:
        click.echo(f"To enable: docmancer install-pack {spec} --allow-destructive")


@click.command("uninstall", help="Remove an installed pack: `docmancer uninstall <package>[@<version>]`.")
@click.argument("spec")
def uninstall_pack_cmd(spec: str) -> None:
    package, version = _parse_pack_spec(spec, require_version=False)
    n = uninstall_package(package, version)
    click.echo(f"Removed {n} package entry/entries.")


def _parse_pack_spec(spec: str, *, require_version: bool) -> tuple[str, str | None]:
    """Split `<package>@<version>` from the rightmost `@` so scoped names like
    `@scope/pkg@1.2.3` parse correctly.
    """
    idx = spec.rfind("@")
    # Treat a leading `@` (npm scope) as part of the package, not a separator.
    if idx <= 0:
        if require_version:
            raise click.UsageError(
                "Spec must be `<package>@<version>`, e.g. `open-meteo@v1`."
            )
        return spec, None
    package, version = spec[:idx], spec[idx + 1 :]
    if not version:
        if require_version:
            raise click.UsageError(
                "Spec must be `<package>@<version>`, e.g. `open-meteo@v1`."
            )
        return package, None
    return package, version


def _prompt_for_spec_url(package: str, version: str, miss_message: str) -> str | None:
    """Show the resolver miss, then prompt for a user-supplied OpenAPI spec URL.
    Returns the URL, or None when stdin is not a TTY (non-interactive caller should
    fall through to the original error).
    """
    if not sys.stdin.isatty():
        return None
    click.echo(click.style(f"Notice: {miss_message}", fg="yellow"))
    click.echo(
        f"\nDocmancer can compile {package}@{version} locally if you point it at a public "
        "OpenAPI 3.x or Swagger 2.0 spec URL."
    )
    try:
        url = click.prompt("OpenAPI spec URL (leave blank to abort)", default="", show_default=False)
    except click.Abort:
        return None
    url = (url or "").strip()
    return url or None


def _compile_from_url_or_die(package: str, version: str, url: str) -> None:
    try:
        pkg_dir = compile_pack_from_url(package, version, url)
    except UnsupportedSpecError as exc:
        raise click.ClickException(str(exc)) from exc
    except httpx.HTTPError as exc:
        raise click.ClickException(f"Could not fetch {url}: {exc}") from exc
    click.echo(f"Compiled {package}@{version} from {url} into {pkg_dir}")


def register_docmancer_mcp_in_agent(agent_name: str) -> str | None:
    """Helper for the existing `docmancer install <agent>` to also register MCP. Returns message or None."""
    target = agent_config.find_agent(agent_name)
    if target is None:
        return None
    try:
        _, message = agent_config.register_server(target)
        return message
    except ValueError as exc:
        return f"warning: {exc}"
